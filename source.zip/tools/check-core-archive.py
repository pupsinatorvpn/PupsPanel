"""Recovery fault tests in a private fake root, never the installed core."""
import argparse,hashlib,importlib.util,json,pathlib,shlex,sys
p=argparse.ArgumentParser();p.add_argument('--ssh-helper',required=True,type=pathlib.Path);p.add_argument('--output',required=True,type=pathlib.Path)
a=p.parse_args();sys.path.insert(0,str(a.ssh_helper.resolve().parent));spec=importlib.util.spec_from_file_location('router_ssh',a.ssh_helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=m.connect();stage='/tmp/pupspanel-archive-check';created=False;report={}
def run(cmd,data=None):
 i,o,e=c.exec_command(cmd,timeout=45)
 if data is not None:i.write(data)
 i.channel.shutdown_write();out=o.read().decode(errors='replace')+e.read().decode(errors='replace');return o.channel.recv_exit_status(),out
def checked(cmd,data=None):
 code,out=run(cmd,data)
 if code:raise RuntimeError(out)
 return out
state='pidof pupsinator-xray; sha256sum /etc/pupsinator/settings.json /etc/pupsinator/nodes.json /etc/pupsinator/xray.json /usr/lib/nodewatch/nodewatch-tachyon-core'
before=checked(state)
try:
 checked(f'test ! -e {stage} && mkdir -m 700 {stage}');created=True
 checked(f'mkdir {stage}/bin {stage}/recovery {stage}/transactions {stage}/transactions/txn.test')
 script=(pathlib.Path(__file__).resolve().parents[1]/'backend/core-archive.sh').read_text()
 script=script.replace('/usr/bin/pupsinator-xray',stage+'/bin/main').replace('/usr/bin',stage+'/bin').replace('/etc/pupspanel-core-rollback',stage+'/recovery').replace('/etc/pupsinator-rollback',stage+'/transactions').replace('pidof pupsinator-xray','pidof pupsarchivefixture')
 checked(f'cat > {stage}/helper.sh',script);checked(f'sh -n {stage}/helper.sh')
 old=b"#!/bin/sh\nprintf 'Xray 26.11.9 (test fixture)\\n'\n"
 checked(f'cat > {stage}/bin/main',old);checked(f'chmod 755 {stage}/bin/main')
 archive=stage+'/recovery/go-xray.gz';call=f'sh {stage}/helper.sh'
 checked(call+' save '+archive);checked(call+' verify '+archive)
 report['saveAndVerify']=True
 report['immutable']=run(call+' save '+archive)[0]!=0
 checked(f'cp {archive} {archive}.saved')
 for suffix in ['sha256','bytes','version','metadata.sha256']:checked(f'cp {archive}.{suffix} {archive}.{suffix}.saved')
 new=b"#!/bin/sh\nprintf 'Xray-rust 0.10.1 (test fixture)\\n'\n"
 checked(f'cat > {stage}/bin/main',new);checked(f'chmod 755 {stage}/bin/main')
 wanted=hashlib.sha256(new).hexdigest()
 def unchanged():return checked(f'sha256sum {stage}/bin/main').split()[0]==wanted
 checked(f'printf broken > {archive}')
 report['corruptArchiveRefused']=run(call+' restore '+archive)[0]!=0 and unchanged()
 checked(f'cp {archive}.saved {archive}')
 for suffix in ['sha256','bytes','version','metadata.sha256']:
  checked(f'printf broken > {archive}.{suffix}')
  report['corrupt_'+suffix]=run(call+' restore '+archive)[0]!=0 and unchanged()
  checked(f'cp {archive}.{suffix}.saved {archive}.{suffix}')
 report['outsidePathRefused']=run(call+' restore '+stage+'/outside.gz')[0]!=0 and unchanged()
 checked(f'mv {archive} {archive}.real; ln -s {archive}.real {archive}')
 report['symlinkRefused']=run(call+' restore '+archive)[0]!=0 and unchanged()
 checked(f'rm {archive}; mv {archive}.real {archive}')
 checked(call+' restore '+archive)
 report['restoredExactBytes']=checked(f'sha256sum {stage}/bin/main').split()[0]==hashlib.sha256(old).hexdigest()
 report['restoredExecutable']=run(f'test -x {stage}/bin/main')[0]==0
 checked(f'rm {stage}/bin/main');checked(call+' restore '+archive)
 report['missingExecutableRecovered']=checked(f'sha256sum {stage}/bin/main').split()[0]==hashlib.sha256(old).hexdigest()
 # Rust-to-Rust transactions retain the original inode without a second gzip.
 checked(f'cat > {stage}/bin/main',new);checked(f'chmod 755 {stage}/bin/main')
 linked=stage+'/transactions/txn.test/core.previous.gz'
 checked(call+' save-link '+linked);checked(call+' verify '+linked);checked(f'touch {stage}/transactions/txn.test/core-saved')
 report['linkHasNoGzip']=run(f'test ! -e {linked}')[0]==0
 inodes=[line.split()[0] for line in checked(f'ls -1i {stage}/bin/main {stage}/transactions/txn.test/core.previous.bin').splitlines()]
 report['linkSharesInode']=len(inodes)==2 and inodes[0]==inodes[1]
 report['linkImmutable']=run(call+' save-link '+linked)[0]!=0
 candidate=b"#!/bin/sh\nprintf 'Xray-rust 0.10.1 (candidate fixture)\\n'\n"
 checked(f'cat > {stage}/bin/candidate',candidate);checked(f'chmod 755 {stage}/bin/candidate; mv {stage}/bin/candidate {stage}/bin/main');wanted=hashlib.sha256(candidate).hexdigest()
 for suffix in ['sha256','bytes','version','metadata.sha256','format']:
  checked(f'cp {linked}.{suffix} {linked}.{suffix}.saved');checked(f'printf broken > {linked}.{suffix}')
  report['linkCorrupt_'+suffix]=run(call+' restore '+linked)[0]!=0 and unchanged()
  checked(f'cp {linked}.{suffix}.saved {linked}.{suffix}')
 previous=stage+'/transactions/txn.test/core.previous.bin'
 checked(f'mv {previous} {previous}.saved; cp {stage}/bin/main {previous}')
 report['linkCorruptBinaryRefused']=run(call+' restore '+linked)[0]!=0 and unchanged()
 checked(f'rm {previous}; ln -s {previous}.saved {previous}')
 report['linkSymlinkRefused']=run(call+' restore '+linked)[0]!=0 and unchanged()
 checked(f'rm {previous}')
 report['linkMissingSourceRefused']=run(call+' restore '+linked)[0]!=0 and unchanged()
 checked(f'mv {previous}.saved {previous}; cp {archive} {linked}')
 report['linkMixedFormatRefused']=run(call+' restore '+linked)[0]!=0 and unchanged()
 checked(f'rm {linked}');report['linkCorruptKeepsRollbackMarker']=run(f'test -f {stage}/transactions/txn.test/core-saved')[0]==0;checked(call+' restore '+linked);report['linkClearsLegacyRollbackMarker']=run(f'test ! -e {stage}/transactions/txn.test/core-saved')[0]==0
 report['linkRestoredExactBytes']=checked(f'sha256sum {stage}/bin/main').split()[0]==hashlib.sha256(new).hexdigest()
 report['linkRestoreIdempotent']=run(call+' restore '+linked)[0]==0
 checked(f'cp {archive} {linked}')
 report['linkMixedAfterRenameRefused']=run(call+' restore '+linked)[0]!=0
 checked(f'rm {linked}; mkdir {stage}/transactions/txn.missing');missing=stage+'/transactions/txn.missing/core.previous.gz'
 checked(call+' save-link '+missing);checked(f'rm {stage}/bin/main');checked(call+' restore '+missing)
 report['linkMissingCurrentRecovered']=checked(f'sha256sum {stage}/bin/main').split()[0]==hashlib.sha256(new).hexdigest()
 report['permanentGoArchiveUnchanged']=run(call+' verify '+archive)[0]==0
 print('CORE_ARCHIVE',json.dumps(report));assert all(report.values())
finally:
 if created:run(f'rm -rf {stage}')
 (a.output/'core-archive-results.json').write_text(json.dumps(report,indent=2))
 assert before==checked(state),'Live router changed'
 c.close()
