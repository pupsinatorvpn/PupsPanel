#!/bin/sh
# Isolated cross build; run under a bounded systemd unit, never on the router.
set -eu
umask 077
lab=/root/pupsinator-rust-lab
export CARGO_HOME="$lab/cargo" RUSTUP_HOME="$lab/rustup"
export ZIG_GLOBAL_CACHE_DIR="$lab/zig-cache" ZIG_LOCAL_CACHE_DIR="$lab/zig-local-cache"
export PATH="$CARGO_HOME/bin:$lab/zig-x86_64-linux-0.15.2:$lab/cargo-zigbuild-x86_64-unknown-linux-musl:$lab/cmake-3.31.10-linux-x86_64/bin:$lab/bin:$PATH"
mkdir -p "$lab/bin"
printf '#!/bin/sh\nexec zig cc "$@"\n' > "$lab/bin/cc"
printf '#!/bin/sh\nexec zig c++ "$@"\n' > "$lab/bin/c++"
printf '#!/bin/sh\nexec zig ar "$@"\n' > "$lab/bin/ar"
chmod 700 "$lab/bin/cc" "$lab/bin/c++" "$lab/bin/ar"
export CC=cc CXX=c++ AR=ar CARGO_BUILD_JOBS=1
export CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER="$lab/bin/cc"
export CMAKE_GENERATOR=Ninja
export CARGO_PROFILE_RELEASE_LTO=false CARGO_PROFILE_RELEASE_CODEGEN_UNITS=8
cd "$lab"
if [ ! -d upstream/.git ]; then git clone --filter=blob:none --no-checkout https://github.com/aimalygin/xray-rust.git upstream; fi
cd upstream
git checkout --detach 3cef7c42c2fd296afd27ab0b6435c632842e1a26
test "$(git rev-parse HEAD)" = 3cef7c42c2fd296afd27ab0b6435c632842e1a26
echo "9818c150c42c29d8a9f97a69f0c2728237ff723caed8c80f22d6a3c9f7a6aba8  $lab/arm64-musl.patch" | sha256sum -c -
if ! git apply --reverse --check "$lab/arm64-musl.patch" 2>/dev/null; then
 git apply --check "$lab/arm64-musl.patch"
 git apply "$lab/arm64-musl.patch"
fi
echo "1952d4f6f93cdda20f8bc0ab4b51b980a7b07b7d8a496628d805ea297c8326ce  $lab/upstream-310.diff" | sha256sum -c -
if ! git apply --reverse --check --include=crates/xray-core-rs/src/outbound.rs --include=crates/xray-core-rs/src/tun.rs --include=crates/xray-core-rs/tests/runtime_data_path_tests.rs "$lab/upstream-310.diff" 2>/dev/null; then
 git apply --check --include=crates/xray-core-rs/src/outbound.rs --include=crates/xray-core-rs/src/tun.rs --include=crates/xray-core-rs/tests/runtime_data_path_tests.rs "$lab/upstream-310.diff"
 git apply --include=crates/xray-core-rs/src/outbound.rs --include=crates/xray-core-rs/src/tun.rs --include=crates/xray-core-rs/tests/runtime_data_path_tests.rs "$lab/upstream-310.diff"
fi
for entry in 'xhttp-empty-header-body.patch 5071e523f998f3e9759bf35db7a700ee188281ff8afc66659f10f85e9de08708' 'bounded-host-logging.patch ce14eeb973ccb66024b1894976457d58d087d191611f1a3f5895cd2be559e2b3' 'dns-ad-request.patch 40787fd26bd78e2c853cb41c11c95fa44d05c709bee82f064a2acb7a9706ab33'; do
 set -- $entry
 echo "$2  $lab/$1" | sha256sum -c -
 if ! git apply --reverse --check "$lab/$1" 2>/dev/null; then git apply --check "$lab/$1"; git apply "$lab/$1"; fi
done
if [ "${PUPS_BUILD_UPSTREAM_CLI:-0}" = 1 ]; then
 cargo +1.96.0 zigbuild --locked --release --target aarch64-unknown-linux-musl -p xray-cli
 sha256sum target/aarch64-unknown-linux-musl/release/xray-rust
 echo ARM64_BUILD_READY
fi
adapter="$lab/pupsinator-router/experimental/rust/adapter"
# Build inside the pinned workspace: identical feature/profile resolution and
# one SDK compilation for the upstream CLI and the Pupsinator adapter.
python3 - "$adapter" <<'PY'
import pathlib,shutil,sys
src=pathlib.Path(sys.argv[1]); dst=pathlib.Path('crates/pupsinator-rust')
(dst/'src').mkdir(parents=True,exist_ok=True)
manifest=(src/'Cargo.toml').read_text()
manifest=manifest.split('[patch.crates-io]')[0]
manifest=manifest.replace('../../../../xray-rust-upstream/crates/','../').replace('../../../../upstream/crates/','../')
(dst/'Cargo.toml').write_text(manifest)
for p in (src/'src').glob('*.rs'): shutil.copyfile(p,dst/'src'/p.name)
root=pathlib.Path('Cargo.toml'); text=root.read_text()
if '"crates/pupsinator-rust"' not in text:
 root.write_text(text.replace('members = [','members = [\n    "crates/pupsinator-rust",',1))
PY
cargo +1.96.0 zigbuild --offline --release --target aarch64-unknown-linux-musl -p pupsinator-rust
sha256sum target/aarch64-unknown-linux-musl/release/pupsinator-rust
echo ARM64_ADAPTER_READY
