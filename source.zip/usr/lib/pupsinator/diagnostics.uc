let fs=require('fs');
let descriptions={
 engine:['Ядро VPN','Ядро запущено.','Ядро остановлено. Нажмите «Включить VPN».'],
 routing:['Маршрутизация устройств','Правила обработки трафика установлены.','VPN выключен: устройства выходят напрямую.'],
 intercept:['Подключение устройств к VPN','Сетевой интерфейс и маршрут готовы.','Маршрут не готов. Попробуйте перезапустить VPN.'],
 dns:['DNS роутера','Роутер успешно определяет адреса сайтов.','DNS не отвечает. Проверьте настройки DNS или верните автоматические.'],
 direct:['Интернет без VPN','Проверочный сайт доступен напрямую.','Прямой HTTPS-запрос не прошёл. Возможны ограничения провайдера или недоступность сайта.'],
 tunnel:['Интернет через выбранный сервер','HTTPS-запрос прошёл через VPN, получен ответ 204.','Выбранный сервер не передаёт HTTPS-трафик. Выберите другой сервер и повторите проверку.'],
 youtube:['YouTube через VPN','YouTube ответил через VPN.','YouTube не ответил ожидаемым кодом. Проверьте другой сервер; это отдельный тест, а не проверка всех сайтов.'],
 lists:['Локальные списки','Все выбранные списки загружены. Интернет для их чтения не нужен.','Часть выбранных списков не загружена. Нажмите «Загрузить выбранные» в разделе списков.'],
 config:['Настройки ядра','Ядро проверило настройки: ошибок нет.','Ядро отклонило настройки. Верните предыдущие параметры или используйте резервное подключение.']
};
let checks=[],samples=[],attempted=0;
for(let line in split(trim(fs.readfile('/tmp/pupsinator/diagnostic.tsv')||''),'\n')){
 let p=split(line,'\t');
 if(p[0]=='tunnel_sample'){
  attempted++;
  if(match(p[1]||'',/^[0-9]+\.[0-9]+$/))push(samples,int(+p[1]*1000));
  continue;
 }
 let d=descriptions[p[0]];
 if(d)push(checks,{id:p[0],status:p[1],title:d[0],detail:p[1]=='ok'?d[1]:p[1]=='off'?'PupsPanel выключен. Проверка его маршрута не требуется.':d[2]});
}
let summary={checked:time(),checks};
if(attempted)summary.https={attempted,failed:attempted-length(samples),samples};
fs.writefile('/tmp/pupsinator/diagnostic.json.new',sprintf('%J',summary));fs.rename('/tmp/pupsinator/diagnostic.json.new','/tmp/pupsinator/diagnostic.json');
