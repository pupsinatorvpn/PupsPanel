#!/bin/sh
set -eu
ready() {
    count=0
    while [ "$count" -lt 45 ]; do
        pid=$(cat /tmp/pupsinator/engine-ready 2>/dev/null || true)
        case "$pid" in ''|*[!0-9]*) ;; *) if kill -0 "$pid" 2>/dev/null && [ "$pid" != "$old_pid" ]; then return 0; fi;; esac
        count=$((count+1)); sleep 1
    done
    return 1
}
old_pid=$(cat /tmp/pupsinator/engine-ready 2>/dev/null || pidof pupsinator-xray || true)
rm -f /tmp/pupsinator/api-ready /tmp/pupsinator/engine-selection /tmp/pupsinator/engine-ready
if /etc/init.d/pupspanel-engine restart && ready && /usr/lib/pupsinator/engine-sync.sh && /usr/lib/pupsinator/rebind-tun.sh; then /usr/lib/pupsinator/device-policy.sh; exit 0; fi
echo 'New engine failed; restoring previous configuration' >&2
if [ -s /etc/pupsinator/xray.previous.json ]; then
    cp /etc/pupsinator/xray.previous.json /etc/pupsinator/xray.json
    /etc/init.d/pupspanel-engine restart || true
    if ready; then /usr/lib/pupsinator/engine-sync.sh || true; /usr/lib/pupsinator/rebind-tun.sh || true; fi
fi
exit 1
