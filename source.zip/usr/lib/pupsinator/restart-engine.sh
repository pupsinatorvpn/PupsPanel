#!/bin/sh
set -eu
ready() {
    count=0
    while [ "$count" -lt 45 ]; do
        if netstat -lnt 2>/dev/null | grep -q '127.0.0.1:15434 ' && netstat -lnt 2>/dev/null | grep -q '127.0.0.1:15457 '; then return 0; fi
        count=$((count+1)); sleep 1
    done
    return 1
}
rm -f /tmp/pupsinator/api-ready /tmp/pupsinator/engine-selection
if /etc/init.d/pupsinator-engine restart && ready && /usr/lib/pupsinator/engine-sync.sh && /usr/lib/pupsinator/rebind-tun.sh; then /usr/lib/pupsinator/device-policy.sh; exit 0; fi
echo 'New engine failed; restoring previous configuration' >&2
if [ -s /etc/pupsinator/xray.previous.json ]; then
    cp /etc/pupsinator/xray.previous.json /etc/pupsinator/xray.json
    /etc/init.d/pupsinator-engine restart || true
    if ready; then /usr/lib/pupsinator/engine-sync.sh || true; /usr/lib/pupsinator/rebind-tun.sh || true; fi
fi
exit 1
