#!/bin/sh
# Compressed recovery copies only; never another running or selectable engine.
set -eu
umask 077
core=/usr/bin/pupsinator-xray
action=${1:-}
archive=${2:-}
fail() { echo "Core recovery: $*" >&2; exit 1; }
case "$archive" in
 /etc/pupspanel-core-rollback/go-xray.gz|/etc/pupsinator-rollback/txn.*/core.previous.gz) ;;
 *) fail 'Invalid recovery path';;
esac
case "$archive" in *..*|*//*) fail 'Invalid recovery path';; esac
parent=$(dirname "$archive")
[ -d "$parent" ] && [ ! -L "$parent" ] || fail 'Recovery directory is missing or unsafe'
for file in "$archive" "$archive.sha256" "$archive.bytes" "$archive.version" "$archive.metadata.sha256" "$archive.new" "$archive.sha256.new" "$archive.bytes.new" "$archive.version.new" "$archive.metadata.sha256.new"; do
 [ ! -L "$file" ] || fail 'Recovery symlinks are not allowed'
done
verify() {
 [ -s "$archive" ] && [ -s "$archive.sha256" ] && [ -s "$archive.bytes" ] && [ -s "$archive.version" ] || fail 'Incomplete recovery copy'
 [ -s "$archive.metadata.sha256" ] || fail 'Incomplete recovery metadata'
 metadata=$(cat "$archive.sha256" "$archive.bytes" "$archive.version" | sha256sum | awk '{print $1}')
 [ "$metadata" = "$(cat "$archive.metadata.sha256")" ] || fail 'Recovery metadata checksum mismatch'
 grep -Eq '^[a-f0-9]{64}$' "$archive.sha256" || fail 'Invalid recovery checksum'
 bytes=$(cat "$archive.bytes")
 case "$bytes" in ''|*[!0-9]*) fail 'Invalid recovery size';; esac
 [ "$bytes" -gt 0 ] && [ "$bytes" -le 134217728 ] || fail 'Invalid recovery size'
 gzip -t "$archive" || fail 'Damaged recovery archive'
 actual=$(gzip -dc "$archive" | sha256sum | awk '{print $1}')
 [ "$actual" = "$(cat "$archive.sha256")" ] || fail 'Recovery checksum mismatch'
 [ "$(gzip -dc "$archive" | wc -c)" -eq "$bytes" ] || fail 'Recovery size mismatch'
}
case "$action" in
save)
 [ -x "$core" ] && [ -s "$core" ] && [ ! -L "$core" ] || fail 'Main engine is missing or unsafe'
 [ ! -e "$archive" ] || fail 'Recovery copies are immutable; use a new transaction'
 version=$("$core" version | head -n 1)
 case "$version" in 'Xray '*|'Xray-rust '*) ;; *) fail 'Unknown main engine';; esac
 case "$archive:$version" in /etc/pupspanel-core-rollback/go-xray.gz:Xray-rust*) fail 'Go recovery copy must contain Go Xray';; esac
 trap 'rm -f "$archive.new" "$archive.sha256.new" "$archive.bytes.new" "$archive.version.new" "$archive.metadata.sha256.new"' EXIT
 sha256sum "$core" | awk '{print $1}' > "$archive.sha256.new"
 wc -c < "$core" | tr -d '[:space:]' > "$archive.bytes.new"
 printf '\n' >> "$archive.bytes.new"
 printf '%s\n' "$version" > "$archive.version.new"
 cat "$archive.sha256.new" "$archive.bytes.new" "$archive.version.new" | sha256sum | awk '{print $1}' > "$archive.metadata.sha256.new"
 gzip -c "$core" > "$archive.new"
 gzip -t "$archive.new"
 actual=$(gzip -dc "$archive.new" | sha256sum | awk '{print $1}')
 [ "$actual" = "$(cat "$archive.sha256.new")" ] || fail 'Engine changed while saving recovery copy'
 mv "$archive.new" "$archive"
 for suffix in sha256 bytes version metadata.sha256; do mv "$archive.$suffix.new" "$archive.$suffix"; done
 verify
 ;;
verify) verify ;;
restore)
 attempts=0
 while [ -n "$(pidof pupsinator-xray 2>/dev/null || true)" ] && [ "$attempts" -lt 15 ]; do sleep 1; attempts=$((attempts+1)); done
 [ -z "$(pidof pupsinator-xray 2>/dev/null || true)" ] || fail 'Stop the main engine before recovery'
 verify
 [ ! -L "$core" ] && [ ! -L "$core.new" ] || fail 'Unsafe main engine path'
 if [ -s "$core" ] && [ "$(sha256sum "$core" | awk '{print $1}')" = "$(cat "$archive.sha256")" ]; then exit 0; fi
 # During an update the old inode is retained by a private hard link, so
 # restoring it requires no second ELF allocation on nearly-full flash.
 case "$archive" in /etc/pupsinator-rollback/txn.*/core.previous.gz)
  previous="$parent/core.previous.bin"
  [ ! -L "$previous" ] || fail 'Unsafe transaction recovery file'
  if [ -f "$previous" ]; then
   [ "$(sha256sum "$previous" | awk '{print $1}')" = "$(cat "$archive.sha256")" ] || fail 'Transaction engine checksum mismatch'
   [ "$("$previous" version | head -n 1)" = "$(cat "$archive.version")" ] || fail 'Transaction engine version mismatch'
   mv "$previous" "$core"
   sync
   exit 0
  fi
 ;; esac
 # The inactive candidate is ours; the current executable stays untouched
 # until a complete, verified recovery file can replace it atomically.
 rm -f "$core.new"
 available=$(df -Pk /usr/bin | awk 'END {print $4}')
 needed=$(((bytes+1023)/1024+1024))
 filesystem=$(awk '$2 == "/overlay" {print $3; exit}' /proc/mounts)
 case "$filesystem" in ubifs|jffs2)
  compressed=$(wc -c < "$archive")
  # Measured UBIFS allocation for this ELF is below 1.75 times its gzip size.
  # The old executable remains intact if the actual staging write cannot fit.
  estimate=$(((compressed*7/4+1023)/1024+1024))
  [ "$estimate" -ge "$needed" ] || needed=$estimate
 ;; esac
 [ "$available" -ge "$needed" ] || fail 'Insufficient flash for atomic recovery; current engine retained'
 trap 'rm -f "$core.new"' EXIT
 gzip -dc "$archive" > "$core.new"
 [ "$(sha256sum "$core.new" | awk '{print $1}')" = "$(cat "$archive.sha256")" ] || fail 'Recovered engine checksum mismatch'
 chmod 755 "$core.new"
 [ "$("$core.new" version | head -n 1)" = "$(cat "$archive.version")" ] || fail 'Recovered engine version mismatch'
 mv "$core.new" "$core"
 ;;
*) fail 'Expected save, verify or restore';;
esac
