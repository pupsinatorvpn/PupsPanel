// Native procfs/sysfs readings; no monitoring daemon or shell polling.
import * as fs from 'fs';
export function telemetry() {
 let mem={}, text=fs.readfile('/proc/meminfo')||'';
 for(let line in split(text,'\n')){let m=match(line,/^([^:]+):[[:space:]]+([0-9]+)/);if(m)mem[m[1]]=int(m[2]);}
 let cpu=null,cores=[], samples={}, old={};
 try{old=json(fs.readfile('/tmp/pupsinator/cpu-sample')||'{}')||{};}catch(e){}
 for(let line in split(fs.readfile('/proc/stat')||'','\n')){
  let row=match(line,/^(cpu[0-9]*)[[:space:]]+(.+)$/);
  if(!row)continue;
  let name=row[1],parts=split(trim(row[2]),/[[:space:]]+/),total=0;
  for(let i=0;i<8&&i<length(parts);i++)total+=int(parts[i]);
  let idle=int(parts[3])+int(parts[4]||0),previous=old[name],usage=null;
  if(previous&&total>previous.total){
   usage=int(100.0*(total-previous.total-idle+previous.idle)/(total-previous.total));
   if(usage<0)usage=0;
   if(usage>100)usage=100;
  }
  samples[name]={total,idle};
  if(name=='cpu')cpu=usage;else push(cores,{id:int(substr(name,3)),usage});
 }
 fs.mkdir('/tmp/pupsinator');
 fs.writefile('/tmp/pupsinator/cpu-sample',sprintf('%J',samples));
 let sockets={};
 for(let path in ['/proc/net/sockstat','/proc/net/sockstat6']){
  for(let line in split(fs.readfile(path)||'','\n')){
   let row=match(line,/^(TCP6?|UDP6?): inuse ([0-9]+)/);
   if(row){let protocol=lc(substr(row[1],0,3));sockets[protocol]=(sockets[protocol]||0)+int(row[2]);}
  }
 }
 let sensors=[];
 for(let path in fs.glob('/sys/class/thermal/thermal_zone*/temp')||[]){let value=int(trim(fs.readfile(path)||''))/1000.0;if(value>0&&value<150)push(sensors,{name:'Процессор',celsius:value});}
 if(!length(sensors))for(let path in fs.glob('/sys/class/hwmon/hwmon*/temp*_input')||[]){let value=int(trim(fs.readfile(path)||''))/1000.0;if(value>0&&value<150)push(sensors,{name:'Датчик',celsius:value});}
 let uptime=+split(trim(fs.readfile('/proc/uptime')||'0'),' ')[0];
 let engine=null;for(let pid in split(split(fs.readfile('/tmp/pupsinator/engine-selection')||'','|')[0],' ')){if(!match(pid,/^[0-9]+$/)||index(fs.readfile('/proc/'+pid+'/cmdline')||'','/etc/pupsinator/xray.json')<0)continue;let text=fs.readfile('/proc/'+pid+'/status')||'',rss=match(text,/VmRSS:[[:space:]]+([0-9]+)/),swap=match(text,/VmSwap:[[:space:]]+([0-9]+)/);engine={rss:rss?int(rss[1]):0,swap:swap?int(swap[1]):0};break;}
 return {memory:{total:mem.MemTotal||0,available:mem.MemAvailable||mem.MemFree||0,cached:mem.Cached||0,swapTotal:mem.SwapTotal||0,swapFree:mem.SwapFree||0},engine,cpu,cores,sockets,sensors,uptime,load:split(trim(fs.readfile('/proc/loadavg')||''),' ')[0]};
};
