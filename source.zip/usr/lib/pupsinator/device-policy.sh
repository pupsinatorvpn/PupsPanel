#!/bin/sh
set -eu
[ -e /tmp/pupsinator/active ] || exit 0
lan=$(cat /tmp/pupsinator/lan-device)
case "$lan" in ''|*[!a-zA-Z0-9_.:-]*) exit 1;; esac
macs=$(ucode /usr/lib/pupsinator/app.uc favorite-macs)
direct_macs=$(ucode /usr/lib/pupsinator/app.uc favorite-macs direct)
nft 'add chain inet pupsinator full_devices' 2>/dev/null || true
nft 'add chain inet pupsinator device_dns { type nat hook prerouting priority dstnat; policy accept; }' 2>/dev/null || true
internet_mode=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.routeMode')
global_dns() {
 case "$internet_mode" in all|whitelist)
  printf 'add rule inet pupsinator device_dns iifname "%s" meta nfproto ipv4 ip daddr != { 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16 } meta l4proto { tcp, udp } th dport 53 counter redirect to :53 comment "pupsinator-global-dns"\n' "$lan"
 ;; esac
}
if [ -n "$macs" ]; then
 ip route replace unreachable default metric 32760 table 201
 if ! ip rule show | grep -q '^111:.*fwmark 0x40000000/0x40000000.*lookup 201'; then ip rule add pref 111 fwmark 0x40000000/0x40000000 lookup 201; fi
 ip route replace local default dev lo metric 10 table 201
fi
resolver=''
if [ -n "$direct_macs" ]; then
 resolver=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.dnsDirect' || true)
 if ! printf '%s\n' "$resolver" | awk -F . 'NF==4 {ok=1; for(i=1;i<=4;i++) if($i !~ /^[0-9]+$/ || $i>255 || ($i ~ /^0/ && length($i)>1)) ok=0} END {exit !ok}'; then
  resolver=77.88.8.8
 fi
fi
{
 printf 'flush chain inet pupsinator full_devices\nflush chain inet pupsinator device_dns\n'
 if [ -n "$direct_macs" ]; then
  printf 'add rule inet pupsinator full_devices ether saddr { %s } counter accept\n' "$direct_macs"
  # DNS addressed to this router would otherwise enter its VPN DNS forwarder.
  # DNS explicitly sent to other resolvers keeps the original destination.
  printf 'add rule inet pupsinator device_dns iifname "%s" meta nfproto ipv4 ether saddr { %s } fib daddr type local meta l4proto { tcp, udp } th dport 53 counter dnat ip to %s:53\n' "$lan" "$direct_macs" "$resolver"
  printf 'add rule inet pupsinator device_dns iifname "%s" meta nfproto ipv4 ether saddr { %s } return\n' "$lan" "$direct_macs"
 fi
 if [ -n "$macs" ]; then
  printf 'add rule inet pupsinator full_devices ether saddr { %s } meta l4proto { tcp, udp } th dport != 53 meta mark set 0x40000000 tproxy to :15456 accept\n' "$macs"
  printf 'add rule inet pupsinator device_dns iifname "%s" meta nfproto ipv4 ether saddr { %s } meta l4proto { tcp, udp } th dport 53 redirect to :15454\n' "$lan" "$macs"
 fi
 global_dns
} | nft -f -
if [ -z "$macs" ]; then
 ip rule del pref 111 fwmark 0x40000000/0x40000000 lookup 201 2>/dev/null || true
 ip route flush table 201 2>/dev/null || true
fi
