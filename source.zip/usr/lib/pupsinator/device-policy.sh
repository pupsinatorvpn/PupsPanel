#!/bin/sh
set -eu
[ -e /tmp/pupsinator/active ] || exit 0
mode=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.mode')
lan=$(cat /tmp/pupsinator/lan-device)
case "$lan" in ''|*[!a-zA-Z0-9_.:-]*) exit 1;; esac
macs=$(ucode /usr/lib/pupsinator/app.uc favorite-macs)
nft 'add chain inet pupsinator full_devices' 2>/dev/null || true
nft 'add chain inet pupsinator device_dns { type nat hook prerouting priority dstnat; policy accept; }' 2>/dev/null || true
if [ -z "$macs" ]; then
 printf 'flush chain inet pupsinator full_devices\nflush chain inet pupsinator device_dns\n' | nft -f -
 ip rule del pref 111 fwmark 0x40000000/0x40000000 lookup 201 2>/dev/null || true
 ip route flush table 201 2>/dev/null || true
 exit 0
fi
ip route replace unreachable default metric 32760 table 201
if ! ip rule show | grep -q '^111:.*fwmark 0x40000000/0x40000000.*lookup 201'; then ip rule add pref 111 fwmark 0x40000000/0x40000000 lookup 201; fi
ip route replace local default dev lo metric 10 table 201
action='meta mark set 0x40000000 tproxy to :15456 accept'
{
 printf 'flush chain inet pupsinator full_devices\nflush chain inet pupsinator device_dns\n'
 printf 'add rule inet pupsinator full_devices ether saddr { %s } meta l4proto { tcp, udp } th dport != 53 %s\n' "$macs" "$action"
 printf 'add rule inet pupsinator device_dns iifname "%s" meta nfproto ipv4 ether saddr { %s } udp dport 53 redirect to :15454\nadd rule inet pupsinator device_dns iifname "%s" meta nfproto ipv4 ether saddr { %s } tcp dport 53 redirect to :15454\n' "$lan" "$macs" "$lan" "$macs"
} | nft -f -
