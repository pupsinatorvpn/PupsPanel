#!/bin/sh
set -eu
umask 077
run=/tmp/pupsinator
mkdir -p "$run"
repo=$(cat /etc/pupsinator/repository)
mirror=https://download.pupsinator.ru
case "$repo" in pupsinatorvpn/pupsinator-router) ;; *) echo 'Не задан официальный репозиторий обновлений' >&2; exit 1;; esac
download() {
 if curl --proxy socks5h://127.0.0.1:15434 --proto '=https' --proto-redir '=https' -fLsS --connect-timeout 6 --max-time 45 --max-filesize 16777216 "$1" -o "$2"; then return; fi
 curl --proto '=https' --proto-redir '=https' -fLsS --connect-timeout 6 --max-time 45 --max-filesize 16777216 "$1" -o "$2"
}
case "${1:-check}" in
check)
 if ! download "$mirror/latest.json" "$run/release.json"; then download "https://api.github.com/repos/$repo/releases/latest" "$run/release.json"; fi
 ucode /usr/lib/pupsinator/updates.uc "$run/release.json"
 ;;
install)
 /bin/sh /usr/lib/pupsinator/updates.sh check
 available=$(jsonfilter -i "$run/update.json" -e '@.available')
 [ "$available" = true ] || { echo 'Установлена актуальная версия'; exit 0; }
 tag=$(jsonfilter -i "$run/update.json" -e '@.tag')
 case "$tag" in v[0-9]*.[0-9]*.[0-9]*) ;; *) exit 1;; esac
 stage=$(mktemp -d /tmp/pupsinator-update.XXXXXXXX)
 trap 'rm -rf "$stage"' EXIT
 url="https://github.com/$repo/releases/download/$tag"
 for file in SHA256SUMS install.sh pupsinator-files.tar.gz; do if ! download "$mirror/$tag/$file" "$stage/$file"; then download "$url/$file" "$stage/$file"; fi; done
 [ "$(grep -Ec '^[a-f0-9]{64}  (install.sh|pupsinator-files.tar.gz)$' "$stage/SHA256SUMS")" = 2 ] || exit 1
 [ "$(wc -l < "$stage/SHA256SUMS")" = 2 ] || exit 1
 (cd "$stage"; sha256sum -c SHA256SUMS)
 PUPS_IN_APP_UPDATE=1 sh "$stage/install.sh" --update-local "$stage/pupsinator-files.tar.gz"
 ;;
*) exit 2;;
esac
