#!/usr/bin/ucode
let fs=require('fs');
let before=json(fs.readfile(ARGV[0])),after=json(fs.readfile(ARGV[1]));
if(type(before)!='object'||type(after)!='object'||!before.routing||!after.routing)exit(1);
let previous=before.routing,next=after.routing;
delete before.routing;delete after.routing;
// DNS, listeners and transports must remain exactly the same.
if(sprintf('%J',before)!=sprintf('%J',after))exit(10);
if(!fs.writefile(ARGV[2],sprintf('%J',{routing:next})))exit(1);
if(!fs.writefile(ARGV[3],sprintf('%J',{routing:previous})))exit(1);
