#!/bin/sh
set -eu
umask 077
run=/tmp/pupsinator
root=/etc/pupsinator
[ -s "$run/engine-ready" ] && [ -e "$run/active" ] || exit 10
ucode /usr/lib/pupsinator/routing-config.uc "$root/xray.json" "$1" "$run/routing-next.json" "$run/routing-old.json"
# Xray validates the complete replacement before atomically publishing it.
/usr/bin/pupsinator-xray api adrules --server=127.0.0.1:15457 --timeout=15 "$run/routing-next.json" >/dev/null
rm -f "$run/engine-selection"
if ! /usr/lib/pupsinator/engine-sync.sh; then
 /usr/bin/pupsinator-xray api adrules --server=127.0.0.1:15457 --timeout=15 "$run/routing-old.json" >/dev/null || true
 rm -f "$run/engine-selection"
 /usr/lib/pupsinator/engine-sync.sh || true
 exit 1
fi
cp "$root/xray.json" "$root/xray.previous.json"
mv "$1" "$root/xray.json"
rm -f "$run/routing-next.json" "$run/routing-old.json"
echo 'Routing applied atomically; engine, DNS and TUN kept running'
