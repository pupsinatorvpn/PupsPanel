#!/bin/sh
set -eu
umask 077
run=/tmp/pupsinator
root=/etc/pupsinator
[ -s "$run/engine-ready" ] && [ -e "$run/active" ] || exit 10
ucode /usr/lib/pupsinator/routing-config.uc "$root/xray.json" "$1" "$run/routing-next.json" "$run/routing-old.json"
# Xray validates the complete replacement before atomically publishing it.
if ! /usr/bin/pupsinator-xray api adrules --server=127.0.0.1:15457 --timeout=90 "$run/routing-next.json" >"$run/routing-api.log" 2>&1; then
 # A timed-out RPC can still finish inside the server. Stop that generation
 # before returning an error, so rejected settings cannot become active later.
 cat "$run/routing-api.log" >&2
 /usr/lib/pupsinator/restart-engine.sh || true
 rm -f "$run/routing-next.json" "$run/routing-old.json"
 exit 1
fi
rm -f "$run/engine-selection"
if ! /usr/lib/pupsinator/engine-sync.sh; then
 if ! /usr/bin/pupsinator-xray api adrules --server=127.0.0.1:15457 --timeout=90 "$run/routing-old.json" >/dev/null; then /usr/lib/pupsinator/restart-engine.sh || true; fi
 rm -f "$run/engine-selection"
 /usr/lib/pupsinator/engine-sync.sh || true
 exit 1
fi
cp "$root/xray.json" "$root/xray.previous.json"
mv "$1" "$root/xray.json"
rm -f "$run/routing-next.json" "$run/routing-old.json"
echo 'Routing applied atomically; engine, DNS and TUN kept running'
