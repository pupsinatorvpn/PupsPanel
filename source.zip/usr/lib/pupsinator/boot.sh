#!/bin/sh
set -eu
[ -e /etc/pupsinator/enabled ] || exit 0
if [ ! -e /etc/pupsinator-rollback/active ] && [ ! -d /tmp/pupsinator-installer.lock ]; then
 for orphan in /etc/pupsinator-core-stage.*; do [ ! -d "$orphan" ] || rm -rf "$orphan"; done
fi
# Restore the system DNS snapshot left by an unclean shutdown before starting.
ucode /usr/lib/pupsinator/app.uc dns-restore
/etc/init.d/dnsmasq restart
count=0
until ip route get 1.1.1.1 >/dev/null 2>&1; do count=$((count+1)); [ "$count" -lt 60 ] || exit 1; sleep 2; done
while [ -e /etc/pupsinator/enabled ]; do
 if /usr/lib/pupsinator/control.sh boot; then exit 0; fi
 # WAN/DNS may become available after the interface gets its default route.
 # Retry infrequently, keeping ordinary Internet available between attempts.
 sleep 60
done
