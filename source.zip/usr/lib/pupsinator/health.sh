#!/bin/sh
mkdir -p /tmp/pupsinator
last_manual=0
last_selected=''
while :; do
    if [ ! -e /tmp/pupsinator/busy ] && [ ! -e /tmp/pupsinator/queued ] && [ ! -e /tmp/pupsinator-installer.lock ] && netstat -lnt 2>/dev/null | grep -q '127.0.0.1:15434 '; then
        /usr/lib/pupsinator/engine-sync.sh || true
        ucode /usr/lib/pupsinator/app.uc health-plan > /tmp/pupsinator/health-plan
        cp /tmp/pupsinator/health-plan /tmp/pupsinator/health-plan-full
        strategy=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.strategy')
        selected=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.selected')
        probe_state=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.probeMethod' -e '@.probeTarget' -e '@.probeTimeout' || true)
        partial=''
        if [ "$strategy" = manual ]; then
            now=$(date +%s)
            if [ "$selected|$probe_state" = "$last_selected" ] && [ $((now-last_manual)) -lt 300 ]; then sleep 30; continue; fi
            awk -F '\t' -v selected="$selected" '$1==selected' /tmp/pupsinator/health-plan-full > /tmp/pupsinator/health-plan
            last_manual=$now;last_selected="$selected|$probe_state";partial=partial
        fi
        /usr/lib/pupsinator/probe-batch.sh /tmp/pupsinator/health-plan /tmp/pupsinator/health.tsv.new
        current_probe=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.probeMethod' -e '@.probeTarget' -e '@.probeTimeout' || true)
        if [ "$probe_state" != "$current_probe" ]; then rm -f /tmp/pupsinator/health.tsv.new;continue;fi
        mv /tmp/pupsinator/health.tsv.new /tmp/pupsinator/health.tsv
        # Serialize selection and config switches against user operations.
        if mkdir /tmp/pupsinator/lock 2>/dev/null; then
            ucode /usr/lib/pupsinator/app.uc health-plan > /tmp/pupsinator/health-plan-current
            if ! cmp -s /tmp/pupsinator/health-plan-full /tmp/pupsinator/health-plan-current; then rmdir /tmp/pupsinator/lock; continue; fi
            cp /etc/pupsinator/settings.json /tmp/pupsinator/settings-before-health.json
            method=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.probeMethod' || true)
            if [ "$method" = tcp ]; then
                ucode /usr/lib/pupsinator/app.uc tcp-results /tmp/pupsinator/health.tsv "$partial"
                change=$(ucode /usr/lib/pupsinator/app.uc auto-select)
            else change=$(ucode /usr/lib/pupsinator/app.uc health-pick "$partial");fi
            if [ "$change" = switch ]; then
                if ! /usr/lib/pupsinator/engine-sync.sh; then cp /tmp/pupsinator/settings-before-health.json /etc/pupsinator/settings.json; /usr/lib/pupsinator/engine-sync.sh || true; fi
            fi
            rmdir /tmp/pupsinator/lock 2>/dev/null || true
        fi
    fi
    sleep 60
done
