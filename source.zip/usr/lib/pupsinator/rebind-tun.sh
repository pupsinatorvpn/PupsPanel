#!/bin/sh
set -eu
if [ -e /tmp/pupsinator/active ] && [ "$(jsonfilter -i /etc/pupsinator/settings.json -e '@.mode')" = tun ]; then
    count=0
    while [ "$count" -lt 35 ]; do
        if ip link show pups0 >/dev/null 2>&1; then
            ip route replace default dev pups0 metric 10 table 200
            lan=$(cat /tmp/pupsinator/lan-device 2>/dev/null || echo br-lan)
            case "$lan" in ''|*[!a-zA-Z0-9_.:-]*) exit 1;; esac
            if ! nft list chain inet fw4 forward | grep -q 'comment "pupsinator"'; then
                printf 'insert rule inet fw4 forward iifname "%s" oifname "pups0" accept comment "pupsinator"\ninsert rule inet fw4 forward iifname "pups0" oifname "%s" accept comment "pupsinator"\n' "$lan" "$lan" | nft -f -
            fi
            exit 0
        fi
        count=$((count+1)); sleep 1
    done
    echo 'TUN did not return; unreachable route retained' >&2
    exit 1
fi
