#!/bin/sh
set -u
port=${1:-}
case "$port" in ''|*[!0-9]*) exit 2;; esac
[ "$port" -ge 1024 ] && [ "$port" -le 65535 ] || exit 2
target=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.probeTarget' 2>/dev/null || true)
timeout=${2:-$(jsonfilter -i /etc/pupsinator/settings.json -e '@.probeTimeout' 2>/dev/null || true)}
case "$timeout" in 8|15|25) ;; *) timeout=15;; esac
method=${3:-${PUPS_PROBE_METHOD:-$(jsonfilter -i /etc/pupsinator/settings.json -e '@.probeMethod' 2>/dev/null || true)}}
if [ "$method" = tcp ] && [ "$port" -ge 15600 ] && [ "$port" -lt 15700 ]; then exec /usr/lib/pupsinator/probe-tcp.sh "$port" "$timeout";fi
case "$target" in google|cloudflare) sites=$target;; *) sites='google cloudflare';; esac
for site in $sites; do
 case "$site" in google) url=https://www.gstatic.com/generate_204;; cloudflare) url=https://cp.cloudflare.com/generate_204;; esac
 result=$(curl --proxy "socks5h://127.0.0.1:$port" --proto '=https' --connect-timeout 10 --max-time "$timeout" --max-filesize 262144 -s -o /dev/null -w '%{http_code}\t%{time_total}' "$url" 2>/dev/null)
 error=$?
 code=${result%%[[:space:]]*}
 if [ "$error" = 0 ] && [ "$code" = 204 ]; then printf '%s\t%s\t0\n' "$result" "$site"; exit 0; fi
done
printf '%s\t%s\t%s\n' "$result" "$site" "$error"
