#!/bin/sh
set -eu
file=$1
binary=$(ucode -e 'let s=require("fs").stat("/usr/bin/pupsinator-xray");assert(s);print(s.mtime,":",s.size);')
fingerprint="$binary:$(sha256sum "$file" | cut -d' ' -f1)"
if [ "$(cat /tmp/pupsinator/validated-config 2>/dev/null || true)" = "$fingerprint" ]; then exit 0; fi
limit=48MiB
[ "$(awk '/MemTotal:/ {print $2}' /proc/meminfo)" -ge 180000 ] || limit=32MiB
GOMEMLIMIT="$limit" GOGC=50 /usr/bin/pupsinator-xray run -test -config "$file"
printf '%s' "$fingerprint" > /tmp/pupsinator/validated-config
