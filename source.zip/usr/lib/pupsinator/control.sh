#!/bin/sh
set -eu
umask 077
export GOMEMLIMIT=80MiB GOGC=75
root=/etc/pupsinator
run=/tmp/pupsinator
mkdir -p "$run"
cmd=${1:-status}
if [ "$cmd" != rollback ] && [ -d /tmp/pupsinator-installer.lock ] && [ "${PUPS_IN_APP_UPDATE:-0}" != 1 ]; then echo 'Выполняется установка обновления' >&2; exit 1; fi
finish() {
 result=$?
 if [ "${bootstrap_started:-0}" = 1 ]; then /etc/init.d/pupsinator-engine stop || true; fi
 if [ "$result" -ne 0 ]; then
  if [ "$cmd" = test ] || [ "$cmd" = connect ] || [ "$cmd" = boot ]; then rollback || true
  elif [ "$cmd" = refresh ] || [ "$cmd" = apply ]; then
   for name in settings nodes; do if [ -s "$run/transaction-$name.json" ]; then cp "$run/transaction-$name.json" "$root/$name.json"; fi; done
   if [ "${installed:-0}" = 1 ] && [ -s "$root/xray.previous.json" ]; then cp "$root/xray.previous.json" "$root/xray.json"; elif [ "${created_bootstrap:-0}" = 1 ]; then rm -f "$root/xray.json"; fi
   if [ "${installed:-0}" = 1 ] && [ "${was_running:-0}" = 1 ]; then /usr/lib/pupsinator/restart-engine.sh || true; fi
  fi
  if [ ! -s "$run/user-error" ]; then echo 'Не удалось применить изменения. Предыдущие настройки сохранены. Запустите диагностику или проверьте доступность подписки.' > "$run/user-error"; fi
 fi
 rm -f "$run/subscription.curl" "$run/subscription" "$run/subscription.headers" "$root/settings-pending.json" "$run/phase" "$run/transaction-xray.json" "$run/transaction-nodes.json" "$run/transaction-settings.json"
 if [ "$cmd" = refresh ]; then rm -f "$root/extra-links-pending"; fi
 echo "$result" > "$run/job-exit"; date +%s > "$run/job-finished"; rm -f "$run/busy"; rmdir "$run/queued" 2>/dev/null || true; rmdir "$run/lock" 2>/dev/null || true
}
remove_routes() {
    nft delete table inet pupsinator 2>/dev/null || true
    ip rule del pref 110 fwmark 0x20000000/0x20000000 lookup 200 2>/dev/null || true
    ip -6 rule del pref 110 fwmark 0x20000000/0x20000000 lookup 200 2>/dev/null || true
    ip rule del pref 111 fwmark 0x40000000/0x40000000 lookup 201 2>/dev/null || true
    ip route flush table 201 2>/dev/null || true
    ip route flush table 200 2>/dev/null || true
    ip -6 route flush table 200 2>/dev/null || true
    for handle in $(nft -a list chain inet fw4 forward 2>/dev/null | awk '/comment "pupsinator(-full)?"/ {print $NF}'); do
        case "$handle" in *[!0-9]*|'') continue;; esac
        nft delete rule inet fw4 forward handle "$handle" 2>/dev/null || true
    done
}
rollback() {
    remove_routes
    ucode /usr/lib/pupsinator/app.uc dns-restore
    /etc/init.d/dnsmasq restart
    /etc/init.d/pupsinator-engine stop || true
    rm -f "$run/active"
    rm -f "$run/test-token"
}
if [ "$cmd" = rollback ]; then rollback; exit; fi
tries=0
while ! mkdir "$run/lock" 2>/dev/null; do tries=$((tries+1)); [ "$tries" -lt 60 ] || { echo 'Предыдущая операция ещё выполняется. Повторите позже.' > "$run/user-error"; echo 1 > "$run/job-exit"; rmdir "$run/queued" 2>/dev/null || true; exit 1; }; sleep 1; done
trap finish EXIT
echo "$$" > "$run/busy"
echo "$cmd" > "$run/job"
rm -f "$run/job-exit" "$run/user-error"
rmdir "$run/queued" 2>/dev/null || true
installed=0
bootstrap_started=0
created_bootstrap=0
was_running=0
if /etc/init.d/pupsinator-engine status >/dev/null 2>&1; then was_running=1; fi
if [ "$cmd" = apply ] || [ "$cmd" = refresh ]; then
 for name in settings nodes; do if [ -f "$root/$name.json" ]; then cp "$root/$name.json" "$run/transaction-$name.json"; else rm -f "$run/transaction-$name.json"; fi; done
fi
case "$cmd" in
refresh)
    echo 'Скачиваем подписку' > "$run/phase"
    if [ -s "$root/settings-pending.json" ]; then cp "$root/settings.json" "$root/settings.previous.json"; mv "$root/settings-pending.json" "$root/settings.json"; fi
    : > "$run/subscription"
    : > "$run/subscription.headers"
    if [ -n "$(jsonfilter -i "$root/settings.json" -e '@.subscription' || true)" ]; then
    ucode /usr/lib/pupsinator/app.uc curl-config "$run/subscription.curl"
    if ! curl --config "$run/subscription.curl" --dump-header "$run/subscription.headers" --proxy socks5h://127.0.0.1:15434 --proto '=https' --proto-redir '=https' -fLsS --connect-timeout 7 --max-time 35 --max-filesize 2097152 -o "$run/subscription"; then
        if ! curl --config "$run/subscription.curl" --dump-header "$run/subscription.headers" --proto '=https' --proto-redir '=https' -fLsS --connect-timeout 7 --max-time 35 --max-filesize 2097152 -o "$run/subscription"; then echo 'Подписка не загрузилась через VPN и напрямую. Проверьте ссылку; прежняя подписка продолжает работать.' > "$run/user-error"; exit 1; fi
    fi
    if grep -Eqi '^x-hwid-(max-devices-reached|limit):[[:space:]]*true' "$run/subscription.headers"; then echo 'Достигнут лимит устройств подписки. Освободите место в списке устройств или увеличьте лимит в панели. Прежнее подключение сохранено.' > "$run/user-error"; exit 1; fi
    fi
    ucode /usr/lib/pupsinator/app.uc metadata "$run/subscription.headers" "$run/subscription-info.json"
    echo 'Читаем серверы новой подписки' > "$run/phase"
    if ! ucode /usr/lib/pupsinator/app.uc import "$run/subscription" "$root/nodes-candidate.json"; then echo 'Подписка скачалась, но её формат или параметры сервера не поддерживаются. Прежняя подписка сохранена.' > "$run/user-error"; exit 1; fi
    ucode /usr/lib/pupsinator/app.uc normalize "$root/nodes-candidate.json"
    ucode /usr/lib/pupsinator/app.uc list-plan > "$run/list-plan"
    ucode /usr/lib/pupsinator/app.uc list-plan missing > "$run/missing-lists"
    if cmp -s "$root/nodes-candidate.json" "$root/nodes.json" && [ ! -s "$run/missing-lists" ] && [ "$(ucode /usr/lib/pupsinator/app.uc change-kind "$run/transaction-settings.json")" != core ]; then
        if [ -e "$run/active" ]; then /usr/lib/pupsinator/engine-sync.sh; fi
        rm -f "$root/nodes-candidate.json"
        /usr/lib/pupsinator/set-update-schedules.sh
        ucode /usr/lib/pupsinator/app.uc subscription-stamp
        echo 'Subscription unchanged; no config rebuild or engine restart'
        exit 0
    fi
    if [ -s "$run/missing-lists" ]; then
        if [ ! -s "$root/xray.json" ]; then
            ucode /usr/lib/pupsinator/app.uc generate "$root/nodes-candidate.json" "$root/xray.json" bootstrap
            created_bootstrap=1
            /usr/lib/pupsinator/verify-config.sh "$root/xray.json"
            /etc/init.d/pupsinator-engine start
            bootstrap_started=1
            ready=0; until netstat -lnt 2>/dev/null | grep -q '127.0.0.1:15434 '; do ready=$((ready+1)); [ "$ready" -lt 45 ] || exit 1; sleep 1; done
            echo 'Ищем доступный сервер для первой загрузки списков' > "$run/phase"
            ucode /usr/lib/pupsinator/app.uc health-plan "$root/nodes-candidate.json" > "$run/bootstrap-plan"
            if initial=$( /usr/lib/pupsinator/bootstrap-pick.sh "$run/bootstrap-plan" ); then
                ucode /usr/lib/pupsinator/app.uc select "$initial"
                /usr/lib/pupsinator/engine-sync.sh
            fi
            echo 'socks5h://127.0.0.1:15434' > "$root/list-download-proxy"
        fi
        /usr/bin/pupsinator-lists preload $(cat "$run/list-plan")
        if [ "$bootstrap_started" = 1 ]; then /etc/init.d/pupsinator-engine stop; bootstrap_started=0; fi
    fi
    ucode /usr/lib/pupsinator/app.uc generate "$root/nodes-candidate.json" "$root/xray-candidate.json"
    echo 'Xray проверяет новые параметры' > "$run/phase"
    if cmp -s "$root/nodes-candidate.json" "$root/nodes.json" && cmp -s "$root/xray-candidate.json" "$root/xray.json"; then rm -f "$root/nodes-candidate.json" "$root/xray-candidate.json"; /usr/lib/pupsinator/set-update-schedules.sh; ucode /usr/lib/pupsinator/app.uc subscription-stamp; echo 'Subscription unchanged'; exit 0; fi
    /usr/lib/pupsinator/verify-config.sh "$root/xray-candidate.json"
    cp "$root/nodes.json" "$root/nodes.previous.json"
    if [ -s "$root/xray.json" ]; then cp "$root/xray.json" "$root/xray.previous.json"; fi
    mv "$root/nodes-candidate.json" "$root/nodes.json"
    mv "$root/xray-candidate.json" "$root/xray.json"
    rm -f "$run/subscription.curl" "$run/subscription"
    installed=1
    if [ "$was_running" = 1 ]; then echo 'Подключаем обновлённые серверы' > "$run/phase"; /usr/lib/pupsinator/restart-engine.sh; fi
    /usr/lib/pupsinator/set-update-schedules.sh
    ucode /usr/lib/pupsinator/app.uc subscription-stamp
    if [ -s "$root/extra-links-pending" ]; then mv "$root/extra-links-pending" "$root/extra-links"; fi
    rm -f "$run/health.json"
    ;;
apply)
    cp "$root/settings.json" "$root/settings.previous.json"
    if [ -s "$root/settings-pending.json" ]; then mv "$root/settings-pending.json" "$root/settings.json"; fi
    before_probe=$(jsonfilter -i "$root/settings.previous.json" -e '@.probeMethod' -e '@.probeTarget' -e '@.probeTimeout' || true)
    after_probe=$(jsonfilter -i "$root/settings.json" -e '@.probeMethod' -e '@.probeTarget' -e '@.probeTimeout' || true)
    if [ "$before_probe" != "$after_probe" ]; then rm -f "$run/tcp.json"; fi
    kind=$(ucode /usr/lib/pupsinator/app.uc change-kind)
    if [ "$kind" != core ]; then
        selection_changed=$(ucode /usr/lib/pupsinator/app.uc selection-changed "$root/settings.previous.json")
        if [ "$selection_changed" = 1 ]; then
            selection_result=$(ucode /usr/lib/pupsinator/app.uc auto-select force)
            if [ "$selection_result" = switch ] && [ -e "$run/active" ]; then /usr/lib/pupsinator/engine-sync.sh; fi
        fi
        if [ "$kind" = selection ] && [ -e "$run/active" ]; then
            if ! /usr/lib/pupsinator/engine-sync.sh; then cp "$root/settings.previous.json" "$root/settings.json"; /usr/lib/pupsinator/engine-sync.sh || true; exit 1; fi
        fi
        /usr/lib/pupsinator/set-update-schedules.sh
        if [ "$kind" = devices ]; then /usr/lib/pupsinator/device-policy.sh; fi
        echo 'Settings applied without restarting or validating the engine'
        exit 0
    fi
    ucode /usr/lib/pupsinator/app.uc list-plan > "$run/list-plan"
    ucode /usr/lib/pupsinator/app.uc list-plan missing > "$run/missing-lists"
    custom_changed=$(ucode -e 'let f=require("fs"),a=json(f.readfile("/etc/pupsinator/settings.previous.json")),b=json(f.readfile("/etc/pupsinator/settings.json"));print(sprintf("%J",a.customLists||[])!=sprintf("%J",b.customLists||[])?"1":"0");')
    if [ -s "$run/missing-lists" ] || { [ "$custom_changed" = 1 ] && [ -s "$run/list-plan" ]; }; then /usr/bin/pupsinator-lists preload $(cat "$run/list-plan"); fi
    ucode /usr/lib/pupsinator/app.uc generate "$root/nodes.json" "$root/xray-candidate.json"
    if cmp -s "$root/xray-candidate.json" "$root/xray.json"; then rm -f "$root/xray-candidate.json"; /usr/lib/pupsinator/set-update-schedules.sh; /usr/lib/pupsinator/device-policy.sh; echo 'Settings saved; engine configuration unchanged'; exit 0; fi
    /usr/lib/pupsinator/verify-config.sh "$root/xray-candidate.json"
    if [ -s "$root/xray.json" ]; then cp "$root/xray.json" "$root/xray.previous.json"; fi
    mv "$root/xray-candidate.json" "$root/xray.json"
    installed=1
    if [ "$was_running" = 1 ]; then /usr/lib/pupsinator/restart-engine.sh; fi
    /usr/lib/pupsinator/set-update-schedules.sh
    /usr/lib/pupsinator/device-policy.sh
    ;;
check)
    /usr/lib/pupsinator/probe-once.sh
    ;;
observe-on) ucode /usr/lib/pupsinator/observe.uc on; /etc/init.d/dnsmasq restart; /etc/init.d/pupsinator-observe enable; /etc/init.d/pupsinator-observe start ;;
observe-off) /etc/init.d/pupsinator-observe stop; /etc/init.d/pupsinator-observe disable; ucode /usr/lib/pupsinator/observe.uc off; /etc/init.d/dnsmasq restart ;;
observe-clear) ucode /usr/lib/pupsinator/observe.uc clear ;;
diagnose) /usr/lib/pupsinator/diagnose.sh ;;
checkupdates) if ! /usr/lib/pupsinator/updates.sh check; then echo 'GitHub не ответил или первый релиз ещё не опубликован. Повторите проверку позже.' > "$run/user-error"; exit 1; fi ;;
upgrade) /usr/lib/pupsinator/updates.sh install ;;
restart)
    [ -e "$run/active" ] || { echo 'VPN выключен. Сначала включите его на главной.' > "$run/user-error"; exit 1; }
    if [ -s "$root/xray.json" ]; then cp "$root/xray.json" "$root/xray.previous.json"; fi
    /usr/lib/pupsinator/restart-engine.sh
    ;;
disconnect|stop) rollback; rm -f "$root/enabled" ;;
connect|test|boot)
    [ ! -e "$run/active" ] || { echo 'VPN already active'; exit 0; }
    touch "$run/confirmed"
    lan_device=$(ubus call network.interface.lan status | jsonfilter -e '@.l3_device')
    case "$lan_device" in ''|*[!a-zA-Z0-9_.:-]*) echo 'Не найден LAN-интерфейс OpenWrt' > "$run/user-error"; exit 1;; esac
    echo "$lan_device" > "$run/lan-device"
    if [ -s "$root/xray.json" ]; then cp "$root/xray.json" "$root/xray.previous.json"; fi
    ucode /usr/lib/pupsinator/app.uc generate "$root/nodes.json" "$root/xray-candidate.json"
    /usr/lib/pupsinator/verify-config.sh "$root/xray-candidate.json"
    mv "$root/xray-candidate.json" "$root/xray.json"
    /usr/lib/pupsinator/restart-engine.sh
    # A selected upstream can be temporarily unavailable at boot. Keep the
    # engine and health worker alive so priority failover can recover it.
    # The installer verifies real HTTPS independently before accepting updates.
    if [ "$cmd" = test ]; then
    ready=0
    while [ "$ready" -lt 3 ]; do
        result=$(/usr/lib/pupsinator/probe-node.sh 15434)
        case "$result" in 204[[:space:]]*) break;; esac
        ready=$((ready+1)); sleep 1
    done
    [ "$ready" -lt 3 ] || { echo 'Туннель не ответил на HTTPS-проверку. Проверьте доступность выбранного сервера; автозапуск повторит попытку после восстановления сети.' > "$run/user-error"; exit 1; }
    fi
    nft list table inet pupsinator >/dev/null 2>&1 && { echo 'Routes already active'; exit 1; }
    mode=$(jsonfilter -i "$root/settings.json" -e '@.mode')
    ip rule add pref 110 fwmark 0x20000000/0x20000000 lookup 200
    if [ "$mode" = tun ]; then
        ip link show pups0 >/dev/null
        ip route add unreachable default metric 32760 table 200
        ip route add default dev pups0 metric 10 table 200
        printf 'insert rule inet fw4 forward iifname "%s" oifname "pups0" accept comment "pupsinator"\n' "$lan_device" | nft -f -
        printf 'insert rule inet fw4 forward iifname "pups0" oifname "%s" accept comment "pupsinator"\n' "$lan_device" | nft -f -
        action='meta mark set 0x20000000 accept'
    else
        ip route add local default dev lo table 200
        action='meta mark set 0x20000000 tproxy to :15435 accept'
    fi
    cat > "$run/rules.nft" <<EOF
table inet pupsinator {
 chain full_devices { }
 chain device_input { type filter hook input priority -1; policy accept; iifname != "$lan_device" iifname != "lo" meta l4proto { tcp, udp } th dport { 15435, 15454, 15456 } reject; }
 chain ipv6_guard {
  type filter hook forward priority -10; policy accept;
  iifname "$lan_device" meta nfproto ipv6 ip6 daddr != { fc00::/7, fe80::/10 } reject
 }
 chain prerouting {
  type filter hook prerouting priority -149; policy accept;
  iifname != "$lan_device" return
  meta nfproto ipv6 return
  fib daddr type local return
  ip daddr { 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16, 224.0.0.0/4, 255.255.255.255 } return
  jump full_devices
  udp dport { 53, 67, 68, 123 } return
  meta l4proto { tcp, udp } $action
 }
}
EOF
    nft -c -f "$run/rules.nft" && nft -f "$run/rules.nft" || { rollback; exit 1; }
    ucode /usr/lib/pupsinator/app.uc dns-save
    /etc/init.d/dnsmasq restart
    touch "$run/active"
    /usr/lib/pupsinator/device-policy.sh
    echo 'socks5h://127.0.0.1:15434' > "$root/list-download-proxy"
    touch "$root/enabled"
    /etc/init.d/pupsinator-network enable
    echo 'VPN enabled; automatic startup enabled.' 
    ;;
confirm) touch "$run/confirmed" ;;

preload|lists-update)
    if [ "$cmd" = preload ]; then ucode /usr/lib/pupsinator/app.uc list-plan > "$run/list-plan"; /usr/bin/pupsinator-lists preload $(cat "$run/list-plan"); else /usr/bin/pupsinator-lists update; fi
    ucode /usr/lib/pupsinator/app.uc generate "$root/nodes.json" "$root/xray-candidate.json"
    if ! cmp -s "$root/xray-candidate.json" "$root/xray.json"; then
        /usr/lib/pupsinator/verify-config.sh "$root/xray-candidate.json"
        if [ -s "$root/xray.json" ]; then cp "$root/xray.json" "$root/xray.previous.json"; fi
        mv "$root/xray-candidate.json" "$root/xray.json"
        if /etc/init.d/pupsinator-engine status >/dev/null 2>&1; then /usr/lib/pupsinator/restart-engine.sh; fi
    else rm -f "$root/xray-candidate.json"; fi
    ;;
*) echo 'Unknown action' >&2;exit 2 ;;
esac
