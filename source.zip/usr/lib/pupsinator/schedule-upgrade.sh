#!/bin/sh
set -eu
root=/etc/pupsinator
[ "$(jsonfilter -i "$root/settings.json" -e '@.autoUpgrade' || true)" = true ] || exit 0
desired=$(jsonfilter -i "$root/settings.json" -e '@.upgradeTime')
now=$(TZ=MSK-3 date +%H:%M)
[ "$now" = "$desired" ] || exit 0
day=$(TZ=MSK-3 date +%F)
[ "$(cat "$root/last-auto-upgrade-day" 2>/dev/null || true)" != "$day" ] || exit 0
[ ! -e /tmp/pupsinator/busy ] && [ ! -e /tmp/pupsinator/queued ] || exit 0
echo "$day" > "$root/last-auto-upgrade-day"
/usr/lib/pupsinator/control.sh upgrade >/tmp/pupsinator-auto-upgrade.log 2>&1
