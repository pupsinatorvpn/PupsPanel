#!/bin/sh
set -eu
root=/etc/pupsinator
run=/tmp/pupsinator
selected=$(jsonfilter -i "$root/settings.json" -e '@.selected')
case "$selected" in ''|*[!a-z0-9-]*) exit 1;; esac
mode=$(jsonfilter -i "$root/settings.json" -e '@.routeMode')
pids=$(pidof pupsinator-xray)
state="$pids|$selected|$mode"
previous=$(cat "$run/engine-selection" 2>/dev/null || true)
if [ "$previous" = "$state" ]; then exit 0; fi
# A failed second override must not skip restoration of the first on rollback.
rm -f "$run/engine-selection"
default="node-$selected"
[ "$mode" != selective ] || default=direct
/usr/bin/pupsinator-xray api bo --server=127.0.0.1:15457 -b vpn "node-$selected" >/dev/null
/usr/bin/pupsinator-xray api bo --server=127.0.0.1:15457 -b default-route "$default" >/dev/null
if /usr/bin/pupsinator-xray version | grep -q '^Xray-rust '; then
 snapshot=$(/usr/bin/pupsinator-xray api bi --server=127.0.0.1:15457)
 [ "$(jsonfilter -s "$snapshot" -e '@.result.groups[@.tag="vpn"].override')" = "node-$selected" ]
 [ "$(jsonfilter -s "$snapshot" -e '@.result.groups[@.tag="default-route"].override')" = "$default" ]
fi
if [ -e "$run/active" ]; then
 if [ "${previous%%|*}" != "$pids" ]; then /usr/lib/pupsinator/rebind-tun.sh; fi
 /usr/lib/pupsinator/device-policy.sh
fi
printf '%s' "$state" > "$run/engine-selection.$$"
mv "$run/engine-selection.$$" "$run/engine-selection"
touch "$run/api-ready"
