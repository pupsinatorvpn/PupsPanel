#!/bin/sh
set -eu
backup=$(cat /etc/pupsinator-rollback/active 2>/dev/null || true)
case "$backup" in /etc/pupsinator-rollback/txn.*) ;; *) exit 0;; esac
[ -s "$backup/backup.tgz" ] || exit 1
[ ! -x /etc/init.d/pupsinator-engine ] || /etc/init.d/pupsinator-engine stop || true
nft delete table inet pupsinator 2>/dev/null || true
ip rule del pref 110 fwmark 0x20000000/0x20000000 lookup 200 2>/dev/null || true
ip rule del pref 111 fwmark 0x40000000/0x40000000 lookup 201 2>/dev/null || true
if [ -e /tmp/pupsinator/active ] || [ -e "$backup/was-active" ]; then for table in 200 201; do ip route flush table "$table" 2>/dev/null || true; done; fi
tar -xzf "$backup/backup.tgz" -C /
if [ -f /usr/bin/pupsinator-xray.previous ]; then mv /usr/bin/pupsinator-xray.previous /usr/bin/pupsinator-xray; fi
if [ -f "$backup/core-was-missing" ]; then rm -f /usr/bin/pupsinator-xray; fi
while IFS= read -r file; do
 case "$file" in usr/lib/pupsinator/rollback-update.sh|etc/init.d/pupsinator-rollback) continue;; esac
 case "$file" in usr/lib/pupsinator/*|www/pupsinator/*|usr/share/rpcd/ucode/pupsinator|usr/share/rpcd/acl.d/luci-app-pupsinator.json|usr/share/luci/menu.d/luci-app-pupsinator.json|etc/init.d/pupsinator-*|etc/pupsinator/version|etc/pupsinator/repository|usr/bin/pupsinator-lists|www/luci-static/resources/view/pupsinator*)
  case "$file" in *../*|*/../*) exit 1;; esac
  rm -f "/$file";;
 esac
done < "$backup/new-files"
rm -f /tmp/pupsinator/active /tmp/pupsinator/confirmed /tmp/pupsinator/busy
rmdir /tmp/pupsinator/lock 2>/dev/null || true
[ ! -f /usr/lib/pupsinator/app.uc ] || ucode /usr/lib/pupsinator/app.uc dns-restore
if [ "${1:-}" != boot ]; then
 /etc/init.d/cron restart
 /etc/init.d/dnsmasq restart
 if [ -f "$backup/was-active" ]; then
  restored=0
  if grep -q 'connect|test|boot)' /usr/lib/pupsinator/control.sh; then
   if PUPS_IN_APP_UPDATE=1 /usr/lib/pupsinator/control.sh connect; then restored=1; fi
  else
   if /usr/lib/pupsinator/control.sh test; then /usr/lib/pupsinator/control.sh confirm; restored=1; fi
  fi
  if [ "$restored" != 1 ]; then ucode /usr/lib/pupsinator/app.uc dns-restore; /etc/init.d/dnsmasq restart; echo 'Файлы восстановлены. Проверочный сервер сейчас не отвечает; доступно прямое подключение.' >&2; fi
 fi
 /etc/init.d/rpcd restart
fi
/etc/init.d/pupsinator-rollback disable 2>/dev/null || true
find /etc/rc.d -maxdepth 1 -type l -name '*pupsinator-rollback' -exec rm -f {} \;
if [ -e "$backup/root-was-missing" ]; then rm -rf /etc/pupsinator; fi
rm -f /etc/pupsinator-rollback/active
case "$backup" in /etc/pupsinator-rollback/txn.*) rm -rf "$backup";; esac
echo 'Предыдущая сборка и настройки восстановлены.'
