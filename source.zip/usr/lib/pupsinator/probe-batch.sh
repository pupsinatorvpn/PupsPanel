#!/bin/sh
set -eu
plan=$1
output=$2
work=$(mktemp -d /tmp/pupsinator/probe-batch.XXXXXXXX)
trap 'rm -rf "$work"' EXIT
tab=$(printf '\t');number=0;running=0
parallel=3
[ "$(awk '/MemTotal:/ {print $2}' /proc/meminfo)" -ge 180000 ] || parallel=1
while IFS="$tab" read -r id port; do
 (printf '%s\t' "$id"; /usr/lib/pupsinator/probe-node.sh "$port") > "$work/$number" &
 number=$((number+1));running=$((running+1))
 if [ "$running" = "$parallel" ]; then wait;running=0;fi
done < "$plan"
wait
: > "$output"
index=0
while [ "$index" -lt "$number" ]; do cat "$work/$index" >> "$output";index=$((index+1));done
