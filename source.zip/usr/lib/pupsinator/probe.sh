#!/bin/sh
set -eu
file=/etc/pupsinator/nodes.json
count=$(jsonfilter -i "$file" -e '@[*].id' | wc -l)
index=0
while [ "$index" -lt "$count" ]; do
    port=$((15600+index))
    name=$(jsonfilter -i "$file" -e "@[$index].name")
    printf '%s: ' "$name"
    curl --proxy "socks5h://127.0.0.1:$port" --connect-timeout 5 --max-time 8 -sS -o /dev/null -w '%{http_code} %{time_total}s\n' https://www.gstatic.com/generate_204 || true
    index=$((index+1))
done
