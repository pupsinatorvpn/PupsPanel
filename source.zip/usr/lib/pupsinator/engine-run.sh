#!/bin/sh
# Also runs on procd crash recovery, not only on a UI restart.
set -u
run=/tmp/pupsinator
mkdir -p "$run"
rm -f "$run/engine-ready" "$run/api-ready"
/usr/bin/pupsinator-xray run -config /etc/pupsinator/xray.json &
child=$!
cleanup() {
 trap - TERM INT
 kill "$child" 2>/dev/null || true
 wait "$child" 2>/dev/null || true
 if [ "$(cat "$run/engine-ready" 2>/dev/null)" = "$child" ]; then rm -f "$run/engine-ready" "$run/api-ready"; fi
}
trap 'cleanup; exit 0' TERM INT
count=0
dns_port=$(jsonfilter -i /etc/pupsinator/xray.json -e '@.inbounds[*].port' | grep '^15453$' || true)
while kill -0 "$child" 2>/dev/null && [ "$count" -lt 45 ]; do
 sockets=$(netstat -ln 2>/dev/null)
 if printf '%s\n' "$sockets" | grep -q '127.0.0.1:15434 ' && printf '%s\n' "$sockets" | grep -q '127.0.0.1:15457 ' && { [ -z "$dns_port" ] || printf '%s\n' "$sockets" | grep -q '127.0.0.1:15453 '; }; then
  rm -f "$run/engine-selection"
  if /usr/lib/pupsinator/engine-sync.sh; then
   printf '%s\n' "$child" > "$run/engine-ready"
   wait "$child"; result=$?
   cleanup
   exit "$result"
  fi
 fi
 count=$((count+1)); sleep 1
done
echo 'Engine startup or route restoration failed' >&2
cleanup
exit 1
