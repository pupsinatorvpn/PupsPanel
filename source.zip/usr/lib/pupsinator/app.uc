#!/usr/bin/ucode
let fs=require('fs'), digest=require('digest');
let root='/etc/pupsinator';
function fail(s){warn(s+'\n');exit(1);}
function load(path,fallback){let s=fs.readfile(path);if(s==null&&substr(path,0,length(root+'/lists/'))==root+'/lists/'&&fs.stat(path+'.gz')){let p=fs.popen('gzip -dc "'+path+'.gz"','r');if(p){s=p.read('all');let code=p.close();if(code!=0)fail('Cannot read compressed list');}}return s==null?fallback:json(s);}
function write(path,data){if(!fs.writefile(path,sprintf('%J',data)))fail('Write failed');}
function ram_kib(){let m=match(fs.readfile('/proc/meminfo')||'',/MemTotal:[[:space:]]+([0-9]+)/);return m?int(m[1]):239560;}
function favorite_macs(route){
 let s=load(root+'/settings.json',{}),out=[];
 for(let d in s.favorites||[]){
  let current=d.route??(d.enabled?'proxy':'inherit');
  if(current==route&&match(d.mac||'',/^[a-fA-F0-9]{2}(:[a-fA-F0-9]{2}){5}$/))push(out,lc(d.mac));
 }
 return out;
}
function decode(s){return replace(s,/%([a-fA-F0-9]{2})/g,function(full,hex){let n=index('0123456789abcdef',lc(substr(hex,0,1)))*16+index('0123456789abcdef',lc(substr(hex,1,1)));return sprintf('%c',n);});}
function b64(s){let a='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out='',v=0,bits=0;s=replace(replace(s,/-/g,'+'),/_/g,'/');for(let i=0;i<length(s);i++){let c=substr(s,i,1);if(c=='='||match(c,/[\r\n\t ]/))continue;let n=index(a,c);if(n<0)fail('Invalid Base64');v=(v<<6)|n;bits+=6;if(bits>=8){bits-=8;out+=sprintf('%c',(v>>bits)&255);v=v&((1<<bits)-1);}}return out;}
function parse_link(line){
 let hash=index(line,'#'),name=hash>=0?decode(substr(line,hash+1)):'';if(hash>=0)line=substr(line,0,hash);
 let m=match(line,/^(vless|hy2|hysteria2):\/\/([^\/\?#]+)(.*)$/);if(!m)fail('Unsupported share link');
 let scheme=m[1],authority=m[2],tail=m[3];let at=index(authority,'@');let auth=at>=0?decode(substr(authority,0,at)):'';let target=at>=0?substr(authority,at+1):authority;
 let hp=match(target,/^\[([^\]]+)\](:([0-9]+))?$/)||match(target,/^([^:]+)(:([0-9]+))?$/);if(!hp)fail('Invalid address');let host=hp[1],port=int(hp[3]||'443');if(port<1||port>65535)fail('Invalid port');
 let q={},qm=index(tail,'?');if(qm>=0)for(let pair in split(substr(tail,qm+1),'&')){let eq=index(pair,'=');if(eq>=0)q[decode(substr(pair,0,eq))]=decode(substr(pair,eq+1));}
 let network=q.type||'tcp',security=q.security||'none',ob={protocol:'vless',settings:{vnext:[{address:host,port,users:[{id:auth,encryption:q.encryption||'none'}]}]},streamSettings:{network,security}};
 if(q.flow)ob.settings.vnext[0].users[0].flow=q.flow;
 if(scheme!='vless'){ob={protocol:'hysteria',settings:{version:2,address:host,port},streamSettings:{network:'hysteria',security:'tls',hysteriaSettings:{version:2,auth},tlsSettings:{serverName:q.sni||host,alpn:['h3']}}};if(q.obfs&&q.obfs!='salamander')fail('Unknown Hysteria obfuscation');if(q.obfs=='salamander')ob.streamSettings.finalmask={udp:[{type:'salamander',settings:{password:q['obfs-password']||''}}]};}
 else {
  if(security=='reality')ob.streamSettings.realitySettings={serverName:q.sni||host,fingerprint:q.fp||'chrome',publicKey:q.pbk||'',shortId:q.sid||'',spiderX:q.spx||''};
  else if(security=='tls'){ob.streamSettings.tlsSettings={serverName:q.sni||host,fingerprint:q.fp||'chrome'};if(q.alpn)ob.streamSettings.tlsSettings.alpn=split(q.alpn,',');}
  else if(security!='none')fail('Unknown security');
  if(network=='xhttp'||network=='splithttp'){ob.streamSettings.network='xhttp';let extra=q.extra?json(q.extra):{};if(type(extra)!='object')fail('Invalid XHTTP extra');ob.streamSettings.xhttpSettings={host:q.host||q.sni||host,path:q.path||'/',mode:q.mode||'auto',extra};}
  else if(network=='grpc')ob.streamSettings.grpcSettings={serviceName:q.serviceName||'',authority:q.authority||q.host||'',multiMode:q.mode=='multi'};
  else if(network=='ws')ob.streamSettings.wsSettings={path:q.path||'/',headers:q.host?{Host:q.host}:{}};
  else if(network!='tcp'&&network!='raw')fail('Unsupported VLESS transport');
 }
 // Refuse unknown parameters instead of silently losing transport/security settings.
 let known=split('encryption flow type security sni fp pbk sid spx alpn host path mode extra serviceName authority allowInsecure insecure obfs obfs-password fm',' ');
 for(let k in keys(q))if(index(known,k)<0)fail('Unsupported share-link parameter: '+k);
 if(q.fm){let fm=json(q.fm);if(type(fm)!='object')fail('Invalid FinalMask JSON');ob.streamSettings.finalmask=fm;}
 if(q.allowInsecure=='1'||q.insecure=='1'){if(!ob.streamSettings.tlsSettings)fail('Invalid insecure option');ob.streamSettings.tlsSettings.allowInsecure=true;}
 return {id:substr(digest.sha256(scheme+'|'+auth+'|'+host),0,20),name:name||host,host,port,transport:scheme=='vless'?ob.streamSettings.network:'hysteria2',outbound:ob};
}
let cmd=ARGV[0];
if(cmd=='favorite-macs'){print(join(', ',favorite_macs(ARGV[1]||'proxy')),'\n');
}else if(cmd=='devices'){
 let devices={},lan=trim(fs.readfile('/tmp/pupsinator/lan-device')||'br-lan');
 for(let line in split(fs.readfile('/tmp/dhcp.leases')||'','\n')){let a=split(trim(line),/[[:space:]]+/);if(length(a)<4||!match(a[1],/^[a-fA-F0-9]{2}(:[a-fA-F0-9]{2}){5}$/))continue;devices[lc(a[1])]={mac:lc(a[1]),ip:a[2],name:a[3]=='*'?a[2]:a[3]};}
 for(let line in split(fs.readfile('/proc/net/arp')||'','\n')){let a=split(trim(line),/[[:space:]]+/);if(length(a)<6||a[5]!=lan||a[3]=='00:00:00:00:00:00'||!match(a[3],/^[a-fA-F0-9]{2}(:[a-fA-F0-9]{2}){5}$/))continue;if(!devices[lc(a[3])])devices[lc(a[3])]={mac:lc(a[3]),ip:a[0],name:a[0]};}
 print(sprintf('%J',values(devices)));
}else if(cmd=='change-kind'){
 let a=load(ARGV[1]||root+'/settings.previous.json',{}),b=load(root+'/settings.json',{});
 let changed=[];for(let key in ['routeMode','mode','selected','lists','customLists','direct','proxy','whiteProvider','whiteIps','dnsMode','dnsDirect','dnsVpn','bootstrap','dnsIpv6'])if(sprintf('%J',a[key])!=sprintf('%J',b[key]))push(changed,key);
 let routeChanged=index(changed,'routeMode')>=0;
 let fast=length(changed)&&!length(filter(changed,k=>k!='selected'&&k!='routeMode'))&&(!routeChanged||(a.routeMode!='whitelist'&&b.routeMode!='whitelist'&&a.dnsMode!='manual'&&b.dnsMode!='manual'))&&fs.stat('/tmp/pupsinator/api-ready');
 print(fast?'selection':length(changed)?'core':sprintf('%J',a.favorites||[])!=sprintf('%J',b.favorites||[])?'devices':'light','\n');
}else if(cmd=='bootstrap'){
 write(root+'/settings.json',{version:1,subscription:'',ua:'PupsPanel',routeMode:'selective',mode:'tproxy',strategy:'manual',returnPrimary:true,selected:'',lists:{youtube:'proxy',telegram:'proxy',meta:'proxy'},direct:[],proxy:[],dnsMode:'auto',dnsDirect:'77.88.8.8',dnsVpn:'https://1.1.1.1/dns-query',bootstrap:'77.88.8.8',dnsIpv6:false,subscriptionInterval:'1',listsInterval:'6'});write(root+'/nodes.json',[]);
}else if(cmd=='curl-config'){
 let cfg=load(root+'/settings.json',{});if(type(cfg.subscription)!='string'||match(cfg.subscription,/[\r\n]/)||substr(cfg.subscription,0,8)!='https://')fail('Invalid subscription URL');
 let url=replace(replace(cfg.subscription,/\\/g,'\\\\'),/"/g,'\\"');
 let p=fs.popen('/usr/bin/pupsinator-xray version 2>/dev/null','r'),v=p?p.read('all'):'';if(p)p.close();let vm=match(v,/^(Xray|Xray-rust) ([0-9.]+)/),engine=vm?vm[1]:'unknown',version=vm?vm[2]:'unknown',appVersion=trim(fs.readfile(root+'/version')||'0.6.4');
 let release=match(fs.readfile('/etc/openwrt_release')||'',/DISTRIB_RELEASE='([^']+)'/),os=release?release[1]:'unknown';
 let model=trim(fs.readfile('/tmp/sysinfo/model')||load('/etc/board.json',{}).model?.name||'OpenWrt Router');
 let vendor=match(model,/^([^ ]+) (.+)$/);if(vendor&&substr(vendor[2],0,length(vendor[1])+1)==vendor[1]+'-')model=vendor[2];
 let id=trim(fs.readfile(root+'/device-id')||'');if(!match(id,/^[a-zA-Z0-9=-]{10,64}$/)){id='Pupsinator-'+trim(fs.readfile('/proc/sys/kernel/random/uuid')||'');if(!match(id,/^Pupsinator-[a-f0-9-]{36}$/))fail('Cannot generate device identifier');fs.writefile(root+'/device-id',id);fs.chmod(root+'/device-id',0600);}
 function clean(s){return replace(s,/[\r\n"\\]/g,'');}
 let ua=clean('PupsPanel ('+model+'; '+engine+'/'+version+'; OpenWrt/'+os+')');cfg.ua=ua;write(root+'/settings.json',cfg);
 write(root+'/client.json',{name:'PupsPanel',appVersion,engine:engine+' '+version,userAgent:ua,model,os:'OpenWrt '+os});
 fs.writefile(ARGV[1],'url = "'+url+'"\nuser-agent = "'+ua+'"\nheader = "x-hwid: '+id+'"\nheader = "x-device-os: OpenWrt"\nheader = "x-ver-os: '+clean(os)+'"\nheader = "x-device-model: '+clean('PupsPanel / '+model+' / '+engine+' '+version)+'"\nheader = "x-app-version: '+clean(appVersion)+'"\n');fs.chmod(ARGV[1],0600);
}else if(cmd=='metadata'){
 let headers={};for(let line in split(fs.readfile(ARGV[1])||'','\n')){line=trim(line);if(match(line,/^HTTP\//)){headers={};continue;}let pos=index(line,':');if(pos>0)headers[lc(substr(line,0,pos))]=trim(substr(line,pos+1));}
 let title=headers['profile-title']||'';if(substr(lc(title),0,7)=='base64:')title=b64(substr(title,7));
 title=substr(replace(title,/[[:cntrl:]]/g,''),0,200);
 let info={name:title,checked:time()};for(let part in split(headers['subscription-userinfo']||'',';')){let kv=match(trim(part),/^(upload|download|total|expire)=([0-9]+)$/);if(kv)info[kv[1]]=+kv[2];}write(ARGV[2],info);
}else if(cmd=='import'){
 let raw=trim(fs.readfile(ARGV[1])||'');let nodes=[];
 if(!match(raw,/^(vless|hy2|hysteria2):\/\//)&&substr(raw,0,1)!='['&&substr(raw,0,1)!='{')raw=trim(b64(raw));
 if(substr(raw,0,1)=='['||substr(raw,0,1)=='{'){
  let profiles=json(raw);if(type(profiles)!='array')profiles=[profiles];
  for(let p in profiles)for(let o in p.outbounds||[])if(index(['vless','hysteria','trojan'],o.protocol)>=0){let ob=json(sprintf('%J',o));let name=p.remarks||p.remark||o.tag||'Server';delete ob.tag;push(nodes,{id:substr(digest.sha256(sprintf('%J',ob)),0,20),name,host:ob.settings?.vnext?.[0]?.address||ob.settings?.servers?.[0]?.address||ob.settings?.address,transport:ob.streamSettings?.network||ob.protocol,outbound:ob});}
 }else for(let line in split(raw,'\n')){line=trim(line);if(!length(line)||substr(line,0,1)=='#')continue;push(nodes,parse_link(line));}
 let extraLinks=fs.readfile(root+'/extra-links-pending');if(extraLinks==null)extraLinks=fs.readfile(root+'/extra-links');
 for(let line in split(trim(extraLinks||''),'\n'))if(length(trim(line)))push(nodes,parse_link(trim(line)));
 if(!length(nodes)||length(nodes)>100)fail('No nodes or subscription too large');let ids={};for(let n in nodes){if(ids[n.id])n.id+='-'+length(keys(ids));ids[n.id]=true;}
 write(ARGV[2],nodes);print(length(nodes),' nodes imported\n');
}else if(cmd=='normalize'){
 let s=load(root+'/settings.json',{}),nodes=load(ARGV[1],[]),ids=map(nodes,n=>n.id);if(index(ids,s.selected)<0)s.selected=ids[0];s.order=filter(s.order||[],id=>index(ids,id)>=0);for(let id in ids)if(index(s.order,id)<0)push(s.order,id);write(root+'/settings.json',s);
}else if(cmd=='subscription-stamp'){
 write(root+'/subscription-update.json',{checked:time(),nodes:length(load(root+'/nodes.json',[]))});let meta=load('/tmp/pupsinator/subscription-info.json',null);if(meta)write(root+'/subscription-info.json',meta);
}else if(cmd=='list-plan'){
 let s=load(root+'/settings.json',{}),ids=keys(s.lists||{}),catalog=load(root+'/lists/current/catalog.json',{lists:[]});if(s.routeMode=='whitelist'){ids=filter(ids,id=>id!='mobile_whitelist_ip');push(ids,s.whiteProvider||'mobile_whitelist');if(s.whiteIps)push(ids,'mobile_whitelist_ip');}for(let id in ids){if(match(id,/^[a-z0-9_]+$/)==null)fail('Invalid list id');if(ARGV[1]=='missing'&&(fs.stat(root+'/lists/current/xray/'+id+'.json')||fs.stat(root+'/lists/current/xray/'+id+'.json.gz'))){let custom=filter(s.customLists||[],l=>l.id==id)[0],stored=filter(catalog.lists,l=>l.id==id)[0];if(!custom||(stored&&stored.url==custom.url&&stored.format==custom.format))continue;}print(id,'\n');}
}else if(cmd=='dns-save'||cmd=='dns-restore'){
 let u=require('uci').cursor();let section='';u.foreach('dhcp','dnsmasq',x=>{if(!section)section=x['.name'];});if(!section)fail('No dnsmasq');
 let path=root+'/dns-original.json';
 if(cmd=='dns-save'){if(fs.stat(path)==null)write(path,{section,server:u.get('dhcp',section,'server'),noresolv:u.get('dhcp',section,'noresolv')});u.set('dhcp',section,'server',['127.0.0.1#15453']);u.set('dhcp',section,'noresolv','1');}
 else {let old=load(path,null);if(old==null)exit(0);section=old.section;for(let k in ['server','noresolv']){u.delete('dhcp',section,k);if(old[k]!=null)u.set('dhcp',section,k,old[k]);}}
 if(!u.commit('dhcp'))fail('Cannot commit DNS settings');
 if(cmd=='dns-restore')fs.unlink(path);
}else if(cmd=='select'){
 assert(match(ARGV[1]||'',/^[a-z0-9-]{1,60}$/),'Invalid node id');let s=load(root+'/settings.json',{});s.selected=ARGV[1];write(root+'/settings.json',s);
}else if(cmd=='tcp-results'){
 let old=load('/tmp/pupsinator/tcp.json',{}),results=ARGV[2]=='partial'?{...(old.results||{})}:{};for(let line in split(trim(fs.readfile(ARGV[1])||''),'\n')){let p=split(line,'\t');if(length(p)!=5||!match(p[3],/^(tcp|tcp-peer|udp)(:[0-9]+)?$/))continue;let kind=split(p[3],':'),ok=p[1]=='tcp'&&p[4]=='0';results[p[0]]={applicable:kind[0]!='udp',ok,ms:int(+p[2]*1000),site:kind[0],port:kind[1]?int(kind[1]):null,error:p[4],checked:time(),failures:ok?0:(old.results?.[p[0]]?.failures||0)+1};}write('/tmp/pupsinator/tcp.json',{checked:time(),switched:old.switched||0,results});
}else if(cmd=='selection-changed'){
 let a=load(ARGV[1],{}),b=load(root+'/settings.json',{});print(length(filter(['strategy','order','returnPrimary','probeMethod','probeTarget','probeTimeout'],k=>sprintf('%J',a[k])!=sprintf('%J',b[k])))?'1':'0');
}else if(cmd=='auto-select'){
 let s=load(root+'/settings.json',{});if(s.strategy=='manual')exit(0);
 let path=s.probeMethod=='tcp'?'/tmp/pupsinator/tcp.json':'/tmp/pupsinator/health.json',state=load(path,{}),results=state.results||{},nodes=load(root+'/nodes.json',[]),ordered=filter(s.order||[],id=>length(filter(nodes,n=>n.id==id)));
 for(let n in nodes)if(index(ordered,n.id)<0)push(ordered,n.id);
 let pick=s.selected,cur=results[pick],force=ARGV[1]=='force',canSwitch=!cur||cur.failures>=3||cur.applicable===false;
 function usable(id){let r=results[id];return r?.ok&&r.applicable!==false&&time()-(r.checked||state.checked||0)<300;}
 if(force&&length(filter(ordered,id=>!results[id]||time()-(results[id].checked||state.checked||0)>=300))){print('refresh\n');exit(0);}
 if(s.strategy=='priority'&&(force||canSwitch||(cur?.ok&&s.returnPrimary&&time()-(state.switched||0)>120))){for(let id in ordered)if(usable(id)){pick=id;break;}}
 else if(s.strategy=='latency'){let best=null;for(let id in ordered)if(usable(id)&&(best==null||results[id].ms<results[best].ms))best=id;if(best&&(force||canSwitch||(cur?.ok&&time()-(state.switched||0)>120&&results[best].ms+15<cur.ms)))pick=best;}
 if(pick&&pick!=s.selected){s.selected=pick;write(root+'/settings.json',s);state.switched=time();state.selected=pick;write(path,state);print('switch\n');}
}else if(cmd=='probe-target'){
 let nodes=load(root+'/nodes.json',[]),i=int(ARGV[1])-15600,n=nodes[i];if(i<0||!n)fail('Invalid probe port');
 let ob=n.outbound,host=ob.settings?.vnext?.[0]?.address||ob.settings?.servers?.[0]?.address||ob.settings?.address||n.host,port=ob.settings?.vnext?.[0]?.port||ob.settings?.servers?.[0]?.port||ob.settings?.port||n.port;
 let kind='tcp';if(ob.protocol=='hysteria'||n.transport=='hysteria2'||n.transport=='hysteria'){
  kind='udp';for(let peer in nodes){let p=peer.outbound,ph=p.settings?.vnext?.[0]?.address||p.settings?.servers?.[0]?.address||p.settings?.address||peer.host,pp=p.settings?.vnext?.[0]?.port||p.settings?.servers?.[0]?.port||p.settings?.port||peer.port;if(ph==host&&p.protocol!='hysteria'&&p.streamSettings?.network!='hysteria'&&pp){port=pp;kind='tcp-peer';break;}}
 }
 if(!match(host||'',/^[a-zA-Z0-9.:-]+$/)||int(port)<1||int(port)>65535)fail('Invalid probe endpoint');print(host,'\t',int(port),'\t',kind,'\n');
}else if(cmd=='health-plan'){
 let s=load(root+'/settings.json',{}),nodes=load(ARGV[1]||root+'/nodes.json',[]),order=s.order||map(nodes,n=>n.id);
 for(let n in nodes)if(index(order,n.id)<0)push(order,n.id);
 for(let id in order)for(let i=0;i<length(nodes);i++)if(nodes[i].id==id)print(id,'\t',15600+i,'\n');
}else if(cmd=='health-pick'){
 let s=load(root+'/settings.json',{}),old=load('/tmp/pupsinator/health.json',{}),results=ARGV[1]=='partial'?{...(old.results||{})}:{},ordered=[];
 for(let line in split(trim(fs.readfile(ARGV[2]||'/tmp/pupsinator/health.tsv')||''),'\n')){let p=split(line,'\t');if(length(p)!=3&&length(p)!=5)continue;let ok=p[1]=='204'&&(length(p)==3||p[4]=='0'),prev=old.results?.[p[0]];results[p[0]]={ok,http:p[1],ms:int(+p[2]*1000),site:p[3]||'google',error:p[4]||'0',checked:time(),failures:ok?0:(prev?.failures||0)+1};push(ordered,p[0]);}
 let pick=s.selected||ordered[0],cur=results[pick],canSwitch=!cur||cur.failures>=3;
 if(s.strategy=='priority'&&(canSwitch||(cur?.ok&&s.returnPrimary&&time()-(old.switched||0)>120))){for(let id in ordered)if(results[id].ok){pick=id;break;}}
 else if(s.strategy=='latency'){let best=null;for(let id in ordered)if(results[id].ok&&(best==null||results[id].ms<results[best].ms))best=id;if(best&&(canSwitch||(cur?.ok&&(time()-(old.switched||0)>120)&&results[best].ms+15<cur.ms)))pick=best;}
 if(ARGV[1]=='measure-only')pick=s.selected||ordered[0];
 let changed=pick&&pick!=s.selected;write('/tmp/pupsinator/health.json',{checked:time(),results,selected:pick,switched:changed?time():old.switched||0});
 if(changed&&(s.strategy!='manual'||!s.selected)){s.selected=pick;write(root+'/settings.json',s);print('switch\n');}
}else if(cmd=='generate'){
 let s=load(root+'/settings.json',{}),nodes=load(ARGV[1],[]);if(!length(nodes))fail('No nodes');
 let chosen=s.selected;let good=false;for(let n in nodes)if(n.id==chosen)good=true;if(!good)chosen=nodes[0].id;
 let rules=[],outbounds=[],inbounds=[{tag:'service',listen:'127.0.0.1',port:15434,protocol:'socks',settings:{udp:true}},{tag:'tproxy',listen:'0.0.0.0',port:15435,protocol:'dokodemo-door',settings:{network:'tcp,udp',followRedirect:true},sniffing:{enabled:true,destOverride:['http','tls','quic'],routeOnly:true},streamSettings:{sockopt:{tproxy:'tproxy'}}}];
 for(let i=0;i<length(nodes);i++){let n=nodes[i],o=json(sprintf('%J',n.outbound));o.tag='node-'+n.id;o.streamSettings=o.streamSettings||{};o.streamSettings.sockopt=o.streamSettings.sockopt||{};o.streamSettings.sockopt.mark=0x8000000;push(outbounds,o);push(inbounds,{tag:'probe-'+n.id,listen:'127.0.0.1',port:15600+i,protocol:'socks',settings:{udp:true}});push(rules,{type:'field',inboundTag:['probe-'+n.id],outboundTag:o.tag});}
 push(outbounds,{tag:'direct',protocol:'freedom',settings:{},streamSettings:{sockopt:{mark:0x8000000}}});push(outbounds,{tag:'block',protocol:'blackhole'});
 let target='node-'+chosen;
 // Keep the tiny dedicated listeners ready: MAC toggles then need only nft changes.
 let fullDevices=true;
 if(fullDevices){
  push(inbounds,{tag:'device-dns',listen:'0.0.0.0',port:15454,protocol:'dokodemo-door',settings:{address:'1.1.1.1',port:53,network:'tcp,udp'}});
  push(inbounds,{tag:'full-device',listen:'0.0.0.0',port:15456,protocol:'dokodemo-door',settings:{network:'tcp,udp',followRedirect:true},streamSettings:{sockopt:{tproxy:'tproxy'}},sniffing:{enabled:true,destOverride:['http','tls','quic'],routeOnly:true}});
  push(rules,{type:'field',inboundTag:['device-dns'],outboundTag:target});
 }
 // Service traffic always uses the selected tunnel, including updates.
 push(rules,{type:'field',inboundTag:['service'],outboundTag:target});
 push(rules,{type:'field',ip:['geoip:private'],outboundTag:'direct'});
 function custom(values,tag){let dom=[],ips=[],inboundTag=[s.mode=='tun'?'tun-in':'tproxy'];for(let v in values||[]){if(index(v,'/')>=0)push(ips,v);else push(dom,'domain:'+v);}if(length(dom))push(rules,{type:'field',inboundTag,domain:dom,outboundTag:tag});if(length(ips))push(rules,{type:'field',inboundTag,ip:ips,outboundTag:tag});}
 custom(s.direct,'direct');custom(s.proxy,target);
 let selections=ARGV[3]=='bootstrap'?{}:{...(s.lists||{})};if(ARGV[3]!='bootstrap'&&s.routeMode=='whitelist'){selections[s.whiteProvider||'mobile_whitelist']='direct';delete selections.mobile_whitelist_ip;if(s.whiteIps)selections.mobile_whitelist_ip='direct';}
 let matcherCount=length(s.direct||[])+length(s.proxy||[]),budget=ram_kib()<180000?(s.dnsMode=='manual'?15000:30000):0;
 for(let action in ['block','direct','proxy']){
  if(action=='direct'&&fullDevices)push(rules,{type:'field',inboundTag:['full-device'],outboundTag:target});
  for(let id in keys(selections))if(selections[id]==action){if(match(id,/^[a-z0-9_]+$/)==null)fail('Invalid list id');let f=load(root+'/lists/current/xray/'+id+'.json',null);if(f==null)fail('Preload required: '+id);for(let r in f.rules)matcherCount+=length(r.domain||[])+length(r.ip||[]);if(budget&&matcherCount>budget){let message='Для роутера со 128 МБ выбран слишком большой набор правил. Выберите отдельные сервисы вместо общих списков: лимит '+budget+' правил.';fs.writefile('/tmp/pupsinator/user-error',message);fail(message);}for(let r in f.rules){r.outboundTag=action=='proxy'?target:action;push(rules,r);}}
 }
 push(rules,{type:'field',network:'tcp,udp',outboundTag:s.routeMode=='selective'?'direct':target});
 let directDomains=[],proxyDomains=[],serverDomains=[];
 for(let n in nodes)if(n.host)push(serverDomains,'full:'+n.host);
 for(let r in rules)if(r.domain)for(let d in r.domain){if(r.outboundTag=='direct')push(directDomains,d);else if(s.dnsMode=='manual'&&r.outboundTag==target)push(proxyDomains,d);}
 let dnsServers=[];if(length(serverDomains))push(dnsServers,{address:s.bootstrap||'77.88.8.8',domains:serverDomains,tag:'dns-direct',skipFallback:true,finalQuery:true});
 if(length(directDomains))push(dnsServers,{address:s.dnsDirect||'77.88.8.8',domains:directDomains,tag:'dns-direct',skipFallback:true,finalQuery:true});
 if(length(proxyDomains))push(dnsServers,{address:s.dnsVpn||'https://1.1.1.1/dns-query',domains:proxyDomains,tag:'dns-vpn',skipFallback:true,finalQuery:true});
 let defaultDirect=s.dnsMode=='manual'&&s.routeMode=='selective';
 push(dnsServers,{address:defaultDirect?(s.dnsDirect||'77.88.8.8'):(s.dnsVpn||'https://1.1.1.1/dns-query'),tag:defaultDirect?'dns-direct':'dns-vpn',finalQuery:true});
 push(inbounds,{tag:'dns-in',listen:'127.0.0.1',port:15453,protocol:'dokodemo-door',settings:{address:s.bootstrap||'77.88.8.8',port:53,network:'tcp,udp'}});
 push(outbounds,{tag:'dns-out',protocol:'dns'});
 rules=[{type:'field',inboundTag:['dns-in'],outboundTag:'dns-out'},{type:'field',inboundTag:['dns-direct'],outboundTag:'direct'},{type:'field',inboundTag:['dns-vpn'],outboundTag:target},...rules];
 if(ARGV[3]=='bootstrap')inbounds=filter(inbounds,x=>x.tag=='service'||substr(x.tag,0,6)=='probe-');
 else if(s.mode=='tun'){inbounds=filter(inbounds,x=>x.tag!='tproxy');push(inbounds,{tag:'tun-in',protocol:'tun',settings:{name:'pups0',mtu:1400,gateway:['172.31.255.1/30'],autoSystemRoutingTable:[],autoSystemDnsToGateway:false},sniffing:{enabled:true,destOverride:['http','tls','quic'],routeOnly:true}});}
 let last=rules[length(rules)-1];delete last.outboundTag;last.balancerTag='default-route';
 for(let r in rules)if(r.outboundTag==target&&substr(r.inboundTag?.[0]||'',0,6)!='probe-'){delete r.outboundTag;r.balancerTag='vpn';}
 let config={log:{loglevel:'warning',access:'none'},api:{tag:'api',listen:'127.0.0.1:15457',services:['RoutingService']},inbounds,outbounds,routing:{domainStrategy:'AsIs',balancers:[{tag:'vpn',selector:[target],strategy:{type:'random'}},{tag:'default-route',selector:[s.routeMode=='selective'?'direct':target],strategy:{type:'random'}}],rules},dns:{servers:dnsServers,disableFallbackIfMatch:true,queryStrategy:s.dnsIpv6?'UseIP':'UseIPv4'}};
 // Avoid needing a bundled geoip.dat: use explicit private CIDRs.
 for(let r in rules)if(r.ip&&r.ip[0]=='geoip:private')r.ip=['127.0.0.0/8','10.0.0.0/8','172.16.0.0/12','192.168.0.0/16','169.254.0.0/16','::1/128','fc00::/7','fe80::/10'];
 write(ARGV[2],config);
}else fail('Unknown app command');
