#!/bin/sh
set -eu
umask 077
run=/tmp/pupsinator
out="$run/diagnostic.tsv"
: > "$out"
report() { printf '%s\t%s\n' "$1" "$2" >> "$out"; }
engine=0
if /etc/init.d/pupspanel-engine status >/dev/null 2>&1; then report engine ok; engine=1; elif [ -e "$run/active" ]; then report engine fail; else report engine off; fi
if [ -e "$run/active" ] && nft list table inet pupsinator >/dev/null 2>&1; then report routing ok; else report routing off; fi
mode=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.mode')
if [ ! -e "$run/active" ]; then report intercept off
elif [ "$mode" = tun ]; then
 if ip link show pups0 >/dev/null 2>&1 && ip route show table 200 | grep -q 'default dev pups0'; then report intercept ok; else report intercept fail; fi
else
 if ip route show table 200 | grep -q 'local default'; then report intercept ok; else report intercept fail; fi
fi
if nslookup example.com 127.0.0.1 >/dev/null 2>&1; then report dns ok; else report dns fail; fi
code=$(curl --noproxy '*' --connect-timeout 4 --max-time 8 -s -o /dev/null -w '%{http_code}' https://www.gstatic.com/generate_204 2>/dev/null || true)
if [ "$code" = 204 ]; then report direct ok; else report direct warn; fi
if [ "$engine" = 1 ]; then
 code=$(curl --proxy socks5h://127.0.0.1:15434 --connect-timeout 5 --max-time 12 -s -o /dev/null -w '%{http_code}' https://www.gstatic.com/generate_204 2>/dev/null || true)
 if [ "$code" = 204 ]; then report tunnel ok; else report tunnel fail; fi
 code=$(curl --proxy socks5h://127.0.0.1:15434 --connect-timeout 5 --max-time 15 -s -o /dev/null -w '%{http_code}' https://www.youtube.com/ 2>/dev/null || true)
 case "$code" in 200|301|302) report youtube ok;; *) report youtube warn;; esac
else report tunnel off; report youtube off; fi
if ucode /usr/lib/pupsinator/app.uc list-plan missing > "$run/diagnostic-missing" && [ ! -s "$run/diagnostic-missing" ]; then report lists ok; else report lists fail; fi
if /usr/lib/pupsinator/verify-config.sh /etc/pupsinator/xray.json > "$run/diagnostic-core.log" 2>&1; then report config ok; else report config fail; fi
ucode /usr/lib/pupsinator/diagnostics.uc
