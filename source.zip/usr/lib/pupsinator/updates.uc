let fs=require('fs'),r=json(fs.readfile(ARGV[0])),current=trim(fs.readfile('/etc/pupsinator/version')||'0.0.0');
assert(!r.draft&&!r.prerelease,'Не стабильный релиз');assert(match(r.tag_name,/^v[0-9]+\.[0-9]+\.[0-9]+$/),'Некорректная версия релиза');
let next=substr(r.tag_name,1),a=split(current,'.'),b=split(next,'.'),available=false;
for(let i=0;i<3;i++){if(int(b[i])>int(a[i])){available=true;break;}if(int(b[i])<int(a[i]))break;}
let names=map(r.assets||[],x=>x.name);for(let required in ['install.sh','pupsinator-files.tar.gz','SHA256SUMS'])assert(index(names,required)>=0,'Релиз ещё не готов к установке');
fs.writefile('/tmp/pupsinator/update.json.new',sprintf('%J',{checked:time(),current,latest:next,tag:r.tag_name,available,notes:substr(r.body||'',0,3000)}));

fs.rename('/tmp/pupsinator/update.json.new','/tmp/pupsinator/update.json');
