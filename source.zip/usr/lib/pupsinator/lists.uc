#!/usr/bin/ucode
// Parse community catalog and translate independent OR matchers, never execute input.
let fs = require('fs');
function die(s) { warn(s + '\n'); exit(1); }
function read(p) { let s=fs.readfile(p); if(s==null)die('Cannot read '+p); let o=json(s); if(o==null)die('Invalid JSON'); return o; }
function valid_id(s) { return type(s)=='string' && match(s,/^[a-z0-9_]+$/)!=null; }
let mode=ARGV[0];
if(mode=='commit') {
    let c=read(ARGV[1]); if(type(c.sha)!='string'||match(c.sha,/^[a-f0-9]{40}$/)==null)die('Invalid commit'); print(c.sha,'\n');
} else if(mode=='augment') {
    let c=read(ARGV[1]);
    for(let item in [
        {id:'mobile_whitelist',title:'Белые списки мобильного интернета РФ — домены (hxehex)',file:'whitelist.txt',kind:'domains'},
        {id:'mobile_whitelist_ip',title:'Белые списки мобильного интернета РФ — подсети (hxehex)',file:'cidrwhitelist.txt',kind:'subnets'}
    ])push(c.lists,{id:item.id,title:item.title,kind:item.kind,group:'mobile_whitelist',recommended_action:'direct',description:'Сборник сообщества по разным операторам и регионам. Не гарантия доступности у вашего провайдера. Подсети включаются отдельно.',files:{json:'external/'+item.file},counts:{},provider:'hxehex/russia-mobile-internet-whitelist'});
    let settings=ARGV[3]?read(ARGV[3]):{};
    for(let l in settings.customLists||[]) {
        if(!match(l.id||'',/^user_[a-f0-9]{16}$/)||!match(l.url||'',/^https:\/\/[^[:space:]"\\#]+$/)||index(['domains','cidrs','json'],l.format)<0)die('Invalid custom source');
        push(c.lists,{id:l.id,title:l.name,description:'Свой источник',kind:l.format,group:'custom',provider:'custom',url:l.url,format:l.format,files:{json:'custom/'+l.id},counts:{}});
    }
    c.total_lists=length(c.lists);fs.writefile(ARGV[2],sprintf('%J',c));
} else if(mode=='with-subnets') {
    let src=read(ARGV[1]), text=fs.readfile(ARGV[2]), ips=[];
    if(text==null)die('Missing subnet file');
    for(let s in split(text,'\n')) {s=trim(s);if(!length(s)||substr(s,0,1)=='#')continue;if(match(s,/^[0-9a-fA-F:.]+\/[0-9]+$/)==null)die('Invalid subnet');push(ips,s);}
    if(length(ips))push(src.rules,{ip_cidr:ips});fs.writefile(ARGV[3],sprintf('%J',src));
} else if(mode=='plain') {
    let text=fs.readfile(ARGV[1]); if(text==null)die('Cannot read plain list'); let values=[];
    for(let line in split(text,'\n')) {line=trim(line);if(!length(line)||substr(line,0,1)=='#')continue;
        if(ARGV[3]=='cidrs'){if(match(line,/^[0-9a-fA-F:.]+\/[0-9]+$/)==null)die('Invalid external CIDR');}
        else if(match(line,/^[a-zA-Z0-9_][a-zA-Z0-9_.-]*\.[a-zA-Z0-9-]+$/)==null)die('Invalid external domain');
        push(values,line);
    }
    let r={};r[ARGV[3]=='cidrs'?'ip_cidr':'domain']=values;
    if(ARGV[3]=='domains'){r={domain_suffix:values};}
    fs.writefile(ARGV[2],sprintf('%J',{version:3,rules:[r]}));
} else if(mode=='plan') {
    let c=read(ARGV[1]); if(c.version!=1||type(c.lists)!='array'||!length(c.lists))die('Invalid catalog');
    let wanted={}; for(let id in split(trim(ARGV[2]||''),/[ \t\r\n]+/))if(id!='')wanted[id]=true;
    let all=ARGV[2]=='all'; let found={};
    for(let l in c.lists) {
        let ext=(l.id=='mobile_whitelist'&&l.files?.json=='external/whitelist.txt')||(l.id=='mobile_whitelist_ip'&&l.files?.json=='external/cidrwhitelist.txt');
        let custom=l.provider=='custom'&&match(l.id||'',/^user_[a-f0-9]{16}$/)&&match(l.url||'',/^https:\/\/[^[:space:]"\\#]+$/)&&index(['domains','cidrs','json'],l.format)>=0&&l.files?.json=='custom/'+l.id;
        if(!valid_id(l.id)||type(l.files)!='object'||(!ext&&!custom&&l.files.json!='release/json/'+l.id+'.json'))die('Invalid list path');
        if(found[l.id])die('Duplicate list id'); found[l.id]=true;
        if(l.files.subnets!=null&&l.files.subnets!='release/subnets/'+l.id+'.lst')die('Invalid subnet path');
        if(all||wanted[l.id])print(l.id,'\t',l.files.json,'\t',l.files.subnets||'-','\t',custom?l.url:'-','\t',custom?l.format:'-','\n');
    }
    if(!all)for(let id in keys(wanted))if(!found[id])die('Unknown list '+id);
} else if(mode=='compile') {
    let src=read(ARGV[1]); if(src.version!=3||type(src.rules)!='array'||!length(src.rules))die('Unsupported or empty rule set');
    let domains={}, ips={}; let maps={domain:'full:',domain_suffix:'domain:',domain_keyword:'keyword:',domain_regex:'regexp:'};
    for(let rule in src.rules) {
        if(type(rule)!='object')die('Invalid rule');
        for(let k in keys(rule)) {
            if(k!='ip_cidr'&&maps[k]==null)die('Unsupported rule field: '+k);
            if(type(rule[k])!='array')die('Expected array: '+k);
            for(let s in rule[k]) {
                if(type(s)!='string'||!length(s)||length(s)>4096||match(s,/[\r\n\t]/))die('Invalid matcher');
                if(k=='ip_cidr') {
                    if(match(s,/^[0-9a-fA-F:.]+\/[0-9]+$/)==null)die('Invalid CIDR');
                    ips[s]=true;
                } else { if(k=='domain_suffix'&&substr(s,0,1)=='.')s=substr(s,1); domains[maps[k]+s]=true; }
            }
        }
    }
    domains=keys(domains);ips=keys(ips);
    if(!length(domains)&&!length(ips))die('Empty rules rejected');
    if(length(domains)+length(ips)>100000)die('List exceeds 100000 matchers');
    // Two separate Xray rules preserve OR between domain and IP matchers.
    let rules=[]; if(length(domains))push(rules,{type:'field',domain:domains}); if(length(ips))push(rules,{type:'field',ip:ips});
    if(!fs.writefile(ARGV[2],sprintf('%J',{schema:1,rules,counts:{domains:length(domains),cidrs:length(ips)}})))die('Write failed');
    print(length(domains),' domains, ',length(ips),' CIDRs\n');
} else if(mode=='status') {
    let root=ARGV[1]; let catalog=fs.readfile(root+'/current/catalog.json');
    print(sprintf('%J\n',{ready:catalog!=null,revision:trim(fs.readfile(root+'/current/revision')||''),last_attempt:trim(fs.readfile(root+'/last-attempt')||''),last_success:trim(fs.readfile(root+'/last-success')||''),last_error:trim(fs.readfile(root+'/last-error')||'')}));
} else die('Unknown command');
