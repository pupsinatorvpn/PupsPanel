#!/bin/sh
set -eu
run=/tmp/pupsinator
method=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.probeMethod' 2>/dev/null || true)
if [ "$method" != tcp ] && ! /etc/init.d/pupspanel-engine status >/dev/null 2>&1; then
 echo 'Включите VPN для проверки HTTPS через туннели' > "$run/user-error"
 exit 1
fi
ucode /usr/lib/pupsinator/app.uc health-plan > "$run/manual-plan"
/usr/lib/pupsinator/probe-batch.sh "$run/manual-plan" "$run/manual-health.tsv"
if [ "$method" = tcp ]; then ucode /usr/lib/pupsinator/app.uc tcp-results "$run/manual-health.tsv";else ucode /usr/lib/pupsinator/app.uc health-pick measure-only "$run/manual-health.tsv";fi
