let fs=require('fs'),digest=require('digest'),root='/etc/pupsinator',run='/tmp/pupsinator';
function load(p,f){let x=fs.readfile(p);if(x==null&&substr(p,0,length(root+'/lists/'))==root+'/lists/'&&fs.stat(p+'.gz')){let z=fs.popen('gzip -dc "'+p+'.gz"','r');if(z){x=z.read('all');assert(z.close()==0,'Compressed list error');}}return x?json(x):f;}
function store(p,x){fs.writefile(p+'.new',sprintf('%J',x));fs.rename(p+'.new',p);}
function loglines(){let p=fs.popen("logread -e 'query\\[' | tail -c 196608",'r'),text=p?p.read('all'):'';if(p)p.close();return split(text,'\n');}
function markCurrent(){let ids=[];for(let line in loglines())if(length(line))push(ids,digest.sha256(line));store(run+'/observed-lines.json',ids);}
let cmd=ARGV[0]||'collect';
if(cmd=='on'||cmd=='off'){
 let u=require('uci').cursor(),section='';u.foreach('dhcp','dnsmasq',s=>{if(!section)section=s['.name'];});assert(section,'DNS не найден');
 if(cmd=='on'){
  if(!fs.stat(root+'/monitor-dns-original.json'))store(root+'/monitor-dns-original.json',{section,logqueries:u.get('dhcp',section,'logqueries'),logfacility:u.get('dhcp',section,'logfacility')});
  u.set('dhcp',section,'logqueries','1');u.delete('dhcp',section,'logfacility');fs.writefile(root+'/monitor-enabled','1');markCurrent();
 }else{
  let old=load(root+'/monitor-dns-original.json',null);if(old){for(let k in ['logqueries','logfacility']){u.delete('dhcp',old.section,k);if(old[k]!=null)u.set('dhcp',old.section,k,old[k]);}}
  fs.unlink(root+'/monitor-enabled');fs.unlink(root+'/monitor-dns-original.json');
 }
 assert(u.commit('dhcp'),'Не удалось сохранить DNS');exit(0);
}
if(cmd=='clear'){markCurrent();fs.unlink(run+'/observations.json');exit(0);}
if(!fs.stat(root+'/monitor-enabled'))exit(0);
let generation=fs.readlink(root+'/lists/current')||'',idx=load(run+'/service-idx.json',{});
if(idx.generation!=generation){
 idx={generation,full:{},suffix:{},services:{}};
 for(let c in load('/www/pupsinator/data/catalog.json',{lists:[]}).lists){
  if(index(['media','social','gaming','ai','tech','other'],c.group)<0)continue;
  let rules=load(root+'/lists/current/xray/'+c.id+'.json',null);if(!rules)continue;
  idx.services[c.id]={id:c.id,name:split(c.title,' — ')[0]};
  for(let r in rules.rules||[])for(let d in r.domain||[]){let m=match(d,/^(full|domain):(.+)$/);if(!m)continue;let map=m[1]=='full'?idx.full:idx.suffix,key=lc(m[2]);if(!map[key]||match(map[key],/_all$/))map[key]=c.id;}
 }
 store(run+'/service-idx.json',idx);
}
let previous=load(run+'/observations.json',{records:[]}),known=load(run+'/observed-lines.json',[]),seen={};for(let id in known)seen[id]=true;
let records={};for(let r in previous.records)if(r.seen>time()-900)records[r.device+'|'+r.domain]=r;
for(let line in loglines()){
 let hash=digest.sha256(line);if(seen[hash])continue;seen[hash]=true;push(known,hash);
 let m=match(line,/query\[[A-Z0-9]+\] ([a-zA-Z0-9_.-]+) from ([0-9.]+)/);if(!m||m[2]=='127.0.0.1')continue;
 let domain=lc(m[1]),key=m[2]+'|'+domain,service=idx.full[domain]||null,labels=split(domain,'.');
 if(!service)for(let i=0;i<length(labels);i++){let s=join('.',slice(labels,i));if(idx.suffix[s]){service=idx.suffix[s];break;}}
 let old=records[key];records[key]={domain,device:m[2],service,seen:time(),count:(old?.count||0)+1};
}
let rows=values(records);sort(rows,(a,b)=>b.seen-a.seen);if(length(rows)>600)rows=slice(rows,0,600);
if(length(known)>2500)known=slice(known,length(known)-2500);store(run+'/observed-lines.json',known);
store(run+'/observations.json',{checked:time(),records:rows,services:idx.services});
