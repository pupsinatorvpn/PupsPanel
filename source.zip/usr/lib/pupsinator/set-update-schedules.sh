#!/bin/sh
set -eu
umask 077
root=/etc/pupsinator
stage=$(mktemp /tmp/pupsinator-schedules-XXXXXXXX)
trap 'rm -f "$stage" "$stage.old"' EXIT
crontab -l > "$stage.old" 2>/dev/null || true
sed '/# pupsinator-lists$/d; /# pupsinator-subscription$/d; /# pupsinator-updates$/d; /# pupsinator-auto-upgrade$/d' "$stage.old" > "$stage"
lists=$(jsonfilter -i "$root/settings.json" -e '@.listsInterval' || true)
subs=$(jsonfilter -i "$root/settings.json" -e '@.subscriptionInterval' || true)
case "$lists" in 0) ;; 24) echo '17 4 * * * /usr/lib/pupsinator/control.sh lists-update >/tmp/pupsinator-lists-update.log 2>&1 # pupsinator-lists' >> "$stage" ;; *) echo '17 */6 * * * /usr/lib/pupsinator/control.sh lists-update >/tmp/pupsinator-lists-update.log 2>&1 # pupsinator-lists' >> "$stage" ;; esac
case "$subs" in 0) ;; 6) echo '7 */6 * * * /usr/lib/pupsinator/control.sh refresh >/tmp/pupsinator-subscription.log 2>&1 # pupsinator-subscription' >> "$stage" ;; 24) echo '7 4 * * * /usr/lib/pupsinator/control.sh refresh >/tmp/pupsinator-subscription.log 2>&1 # pupsinator-subscription' >> "$stage" ;; *) echo '7 * * * * /usr/lib/pupsinator/control.sh refresh >/tmp/pupsinator-subscription.log 2>&1 # pupsinator-subscription' >> "$stage" ;; esac
echo '27 5 * * * /usr/lib/pupsinator/updates.sh check >/tmp/pupsinator-updates.log 2>&1 # pupsinator-updates' >> "$stage"
if [ "$(jsonfilter -i "$root/settings.json" -e '@.autoUpgrade' || true)" = true ]; then echo '* * * * * /usr/lib/pupsinator/schedule-upgrade.sh # pupsinator-auto-upgrade' >> "$stage"; fi
if ! cmp -s "$stage" "$stage.old"; then crontab "$stage"; fi
