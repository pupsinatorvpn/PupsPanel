import * as fs from 'fs';
function load(path,fallback){try{return json(fs.readfile(path)||'null')||fallback;}catch(e){return fallback;}}
function bounded(command){let p=fs.popen(command,'r');if(!p)return '';let text=p.read(32768)||'';p.close();return text;}
export function supportReport(resources){
 let settings=load('/etc/pupsinator/settings.json',{}),nodes=load('/etc/pupsinator/nodes.json',[]),secrets=[];
 function collect(value,key){if(type(value)=='string'){let sensitive=index(['auth','password','token','id','privateKey','publicKey','shortId','uuid','mac','label','name'],key)>=0;if(length(value)>=(sensitive?1:4)&&index(secrets,value)<0)push(secrets,value);}else if(type(value)=='array'){for(let item in value)collect(item,key);}else if(type(value)=='object')for(let k in keys(value))collect(value[k],k);}
 collect(settings);collect(nodes);collect(load('/etc/pupsinator/client.json',{}));
 // Longer values first: removing a host must not leave its subscription token.
 sort(secrets,(a,b)=>length(b)-length(a));
 function redact(text){
  text=replace(text||'',/\x1b\[[0-9;]*[A-Za-z]/g,'');
  text=replace(text,/[a-zA-Z][a-zA-Z0-9+.-]*:\/\/[^\s<>"']+/g,'[URL]');
  text=replace(text,/(response for|query for|lookup|resolve)[[:space:]]+[^[:space:]>]+/gi,function(full,prefix){return prefix+' [HOST]';});
  for(let secret in secrets)text=join('[PRIVATE]',split(text,secret));
  text=replace(text,/[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}/g,'[UUID]');
  text=replace(text,/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,'[EMAIL]');
  text=replace(text,/([a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}/g,'[MAC]');
  text=replace(text,/\b([0-9]{1,3}\.){3}[0-9]{1,3}\b/g,'[IP]');
  text=replace(text,/\b[0-9a-fA-F]*:[0-9a-fA-F:]+\b/g,'[IPV6]');
  text=replace(text,/([a-zA-Z0-9_-]+\.)+[a-zA-Z][a-zA-Z0-9-]*/g,'[HOST]');
  text=replace(text,/(password|passwd|token|authorization|secret|privateKey|publicKey|auth)["']?[[:space:]]*[:=][[:space:]]*["']?[^\s,"'}]+/gi,'[CREDENTIAL]');
  text=replace(text,/[a-zA-Z0-9_+\/-]{24,}={0,2}/g,'[LONG_VALUE]');
  return substr(text,0,32768);
 }
 let health=load('/tmp/pupsinator/health.json',{}),tcp=load('/tmp/pupsinator/tcp.json',{}),safeNodes=[];
 function measurement(value){if(!value)return null;return {ok:!!value.ok,applicable:value.applicable!==false,ms:int(value.ms||0),port:int(value.port||0),checked:int(value.checked||0),failures:int(value.failures||0)};}
 for(let i=0;i<length(nodes)&&i<128;i++){let n=nodes[i];push(safeNodes,{number:i+1,selected:n.id==settings.selected,transport:match(n.transport||'',/^[a-z0-9-]{1,20}$/)?n.transport:'unknown',tcp:measurement(tcp.results?.[n.id]),https:measurement(health.results?.[n.id])});}
 let diagnostic=load('/tmp/pupsinator/diagnostic.json',{}),checks=[];
 for(let item in diagnostic.checks||[])if(match(item.id||'',/^[a-z_]{1,32}$/)&&index(['ok','off','warn','fail'],item.status)>=0)push(checks,{id:item.id,status:item.status});
 let safeSettings={};for(let key in ['routeMode','mode','strategy','probeMethod','probeTarget','probeTimeout','dnsMode','dnsIpv6','returnPrimary','listsInterval','subscriptionInterval']){
  let value=settings[key];if(type(value)=='bool'||type(value)=='int'||type(value)=='double'||(type(value)=='string'&&match(value,/^[a-z0-9_-]{1,32}$/)))safeSettings[key]=value;
 }
 safeSettings.subscriptionConfigured=!!settings.subscription;safeSettings.customListCount=length(settings.customLists||[]);safeSettings.favoriteCount=length(settings.favorites||[]);
 let lists=[];for(let id in keys(settings.lists||{}))if(match(id,/^[a-z0-9_]{1,80}$/)&&index(['proxy','direct','block'],settings.lists[id])>=0)push(lists,{id,route:settings.lists[id]});
 let order=[];for(let id in settings.order||[])for(let i=0;i<length(nodes)&&i<128;i++)if(nodes[i].id==id)push(order,i+1);
 let os=fs.readfile('/etc/openwrt_release')||'',release=match(os,/DISTRIB_RELEASE=['"]?([0-9.]+)/)?.[1]||'unknown';
 let version=trim(fs.readfile('/etc/pupsinator/version')||''),engine=load('/tmp/pupsinator/engine-version.json',{}).engine||'';
 let report={format:'pupsinator-support-v1',generated:time(),privacy:'Обезличенный отчёт. Настройки подключения, адреса узлов, ссылка подписки, устройства и история DNS не включены. Журналы очищены; проверьте файл перед отправкой.',versions:{app:match(version,/^[0-9.]+$/)?version:'unknown',engine:match(engine,/^Xray [0-9.]+$/)?engine:'unknown',openwrt:release},active:fs.stat('/tmp/pupsinator/active')!=null,busy:fs.stat('/tmp/pupsinator/busy')!=null,settings:safeSettings,lists,order,nodes:safeNodes,resources:resources||{},diagnostic:{checked:int(diagnostic.checked||0),checks},lastOperation:{name:redact(trim(fs.readfile('/tmp/pupsinator/job')||'')),exit:int(fs.readfile('/tmp/pupsinator/job-exit')||'0'),finished:int(fs.readfile('/tmp/pupsinator/job-finished')||'0'),error:redact(substr(fs.readfile('/tmp/pupsinator/user-error')||'',0,4096))},logs:{job:redact(bounded('tail -c 24576 /tmp/pupsinator/job.log 2>/dev/null')),validation:redact(bounded('tail -c 8192 /tmp/pupsinator/diagnostic-core.log 2>/dev/null')),engine:redact(bounded("logread -l 160 2>/dev/null | grep -E 'pupsinator|app/dns|transport/internet|proxy/|app/proxyman' | tail -c 32768"))}};
 return report;
};
