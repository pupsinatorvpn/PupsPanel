#!/bin/sh
set -eu
plan=$1
started=$(date +%s)
tab=$(printf '\t')
while IFS="$tab" read -r id port; do
 [ $(($(date +%s)-started)) -lt 90 ] || break
 result=$(/usr/lib/pupsinator/probe-node.sh "$port" 8 https)
 if printf '%s\n' "$result" | awk -F '\t' '$1==204&&$4==0 {found=1} END {exit !found}'; then printf '%s\n' "$id"; exit 0; fi
done < "$plan"
exit 1
