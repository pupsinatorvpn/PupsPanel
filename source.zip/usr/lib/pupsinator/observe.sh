#!/bin/sh
mkdir -p /tmp/pupsinator
while [ -e /etc/pupsinator/monitor-enabled ]; do
    ucode /usr/lib/pupsinator/observe.uc collect >/tmp/pupsinator/observe-error.log 2>&1 || true
    sleep 15
done
