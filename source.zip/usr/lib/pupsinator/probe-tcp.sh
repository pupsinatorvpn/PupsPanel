#!/bin/sh
set -u
target=$(ucode /usr/lib/pupsinator/app.uc probe-target "$1") || exit 2
tab=$(printf '\t');host=${target%%"$tab"*};rest=${target#*"$tab"};port=${rest%%"$tab"*};kind=${rest#*"$tab"}
if [ "$kind" = udp ]; then printf 'udp\t0\tudp\t0\n';exit 0;fi
site="$kind:$port"
timeout=${2:-8}
case "$timeout" in 8|15|25) ;; *) timeout=8;; esac
case "$host" in
 *:*) urlhost="[$host]";ip=$host;;
 *[!0-9.]*)
  dns=$(jsonfilter -i /etc/pupsinator/settings.json -e '@.bootstrap' 2>/dev/null || true)
  case "$dns" in ''|*[!0-9.]*) dns=77.88.8.8;; esac
  ip=$(timeout 5 nslookup "$host" "$dns" 2>/dev/null | awk '/^Name:/ {answer=1} answer && /^Address: / && $2 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ {print $2;exit}')
  urlhost=$host;;
 *) ip=$host;urlhost=$host;;
esac
if [ -z "$ip" ]; then printf '000\t0\t%s\t6\n' "$site";exit 0;fi
# time_connect is set only after the remote TCP handshake. HTTP response,
# TLS, credentials and server application protocol are deliberately irrelevant.
# HEAD asks for no response body; remote protocol refusal still leaves a valid RTT.
elapsed=$(curl --noproxy '*' --proxy '' --resolve "$urlhost:$port:$ip" --connect-timeout "$timeout" --max-time "$timeout" --speed-limit 1 --speed-time 1 --max-filesize 1024 --head -s -o /dev/null -w '%{time_connect}' "http://$urlhost:$port/" </dev/null 2>/dev/null)
error=$?
if awk -v elapsed="$elapsed" 'BEGIN {exit !(elapsed+0>0)}'; then printf 'tcp\t%s\t%s\t0\n' "$elapsed" "$site";else printf '000\t0\t%s\t%s\n' "$site" "$error";fi
