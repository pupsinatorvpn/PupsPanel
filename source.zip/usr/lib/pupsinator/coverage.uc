import * as fs from 'fs';
let digest=require('digest');
function canonical(v){if(type(v)=='array')return map(v,canonical);if(type(v)!='object')return v;let out={};for(let k in sort(keys(v)))out[k]=canonical(v[k]);return out;}
export function rulePage(id,cursor,version){
 assert(type(id)=='string'&&match(id,/^[a-z0-9_]{1,80}$/),'ID списка');
 cursor=int(cursor||0);assert(cursor>=0&&cursor<=500000,'Страница списка');
 let path='/etc/pupsinator/lists/current/xray/'+id+'.json',text;
 let memory=match(fs.readfile('/proc/meminfo')||'',/MemTotal:[[:space:]]+([0-9]+)/),cap=memory&&int(memory[1])<180000?2097152:8388608;
 if(fs.stat(path)){let f=fs.open(path,'r');text=f?f.read(cap+1):null;if(f)f.close();}
 else if(fs.stat(path+'.gz')){let f=fs.popen('gzip -dc '+path+'.gz 2>/dev/null','r');text=f?f.read(cap+1):null;if(f)f.close();}
 if(text==null)return {id,available:false,reason:'Список ещё не загружен на роутер'};
 if(length(text)>cap)return {id,available:false,reason:'Анализ этого списка превышает безопасный объём памяти'};
 let revision=digest.sha256(text);if(version&&version!=revision)return {id,available:false,stale:true,reason:'Источник обновился во время анализа'};
 let src;try{src=json(text);}catch(e){return {id,available:false,reason:'Не удалось прочитать правила'};}
 if(type(src.rules)!='array')return {id,available:false,reason:'Неизвестный формат правил'};
 let items=[],position=0,bytes=0,full=false;
 function emit(kind,value,scope){let index=position++;if(index<cursor||full)return;let size=length(value)+length(scope)+80;if(size>80000){full=true;return;}if(length(items)>=512||bytes+size>80000){full=true;return;}push(items,{kind,value,scope});bytes+=size;}
 for(let r in src.rules){
  let scope={};for(let k in keys(r))if(index(['domain','ip','type','outboundTag'],k)<0)scope[k]=r[k];
  let conditions=sprintf('%J',canonical(scope));
  if((r.domain&&r.ip)||r.type&&r.type!='field'){
   let raw={...r};delete raw.outboundTag;emit('opaque',sprintf('%J',canonical(raw)),'{}');continue;
  }
  for(let v in r.domain||[])emit('domain',v,conditions);
  for(let v in r.ip||[])emit('ip',v,conditions);
  if(!r.domain&&!r.ip)emit('opaque',sprintf('%J',canonical(r)),conditions);
 }
 if(!length(items)&&cursor<position)return {id,available:false,reason:'Слишком большое или неизвестное правило'};
 return {id,available:true,version:revision,total:position,items,next:cursor+length(items)<position?cursor+length(items):null};
};
