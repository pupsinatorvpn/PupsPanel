import * as fs from 'fs';
let digest=require('digest');
// One parsed source only. Every request hashes the current on-disk bytes,
// including compressed bytes, so replacing a source always invalidates it.
let pageCache=null;
function canonical(v){if(type(v)=='array')return map(v,canonical);if(type(v)!='object')return v;let out={};for(let k in sort(keys(v)))out[k]=canonical(v[k]);return out;}
function boundedRead(path,cap){let f=fs.open(path,'r'),text=f?f.read(cap+1):null;if(f)f.close();return text;}
export function rulePage(id,cursor,version){
 assert(type(id)=='string'&&match(id,/^[a-z0-9_]{1,80}$/),'ID списка');
 cursor=int(cursor||0);assert(cursor>=0&&cursor<=500000,'Страница списка');
 let path='/etc/pupsinator/lists/current/xray/'+id+'.json';
 let memory=match(fs.readfile('/proc/meminfo')||'',/MemTotal:[[:space:]]+([0-9]+)/),cap=memory&&int(memory[1])<180000?2097152:8388608;
 let zipped=false;if(!fs.stat(path)){path+='.gz';zipped=true;}
 let stored=boundedRead(path,cap);
 if(stored==null)return {id,available:false,reason:'Список ещё не загружен на роутер'};
 if(length(stored)>cap)return {id,available:false,reason:'Анализ этого списка превышает безопасный объём памяти'};
 let fingerprint=digest.sha256(stored),key=id+'|'+fingerprint;
 if(!pageCache||pageCache.key!=key){
  // Evict before parsing the next source; never retain all selected sources.
  pageCache=null;
  let text=stored;
  if(zipped){let f=fs.popen('gzip -dc '+path+' 2>/dev/null','r');text=f?f.read(cap+1):null;if(f)f.close();}
  if(text==null||length(text)>cap)return {id,available:false,reason:'Анализ этого списка превышает безопасный объём памяти'};
  let revision=digest.sha256(text);
  if(version&&version!=revision)return {id,available:false,stale:true,reason:'Источник обновился во время анализа'};
  let src;try{src=json(text);}catch(e){return {id,available:false,reason:'Не удалось прочитать правила'};}
  if(type(src.rules)!='array')return {id,available:false,reason:'Неизвестный формат правил'};
  let groups=[],total=0;
  function group(kind,values,scope){if(!length(values))return;push(groups,{kind,values,scope,start:total});total+=length(values);}
  for(let r in src.rules){
   let scope={};for(let k in keys(r))if(index(['domain','ip','type','outboundTag'],k)<0)scope[k]=r[k];
   let conditions=sprintf('%J',canonical(scope));
   if((r.domain&&r.ip)||r.type&&r.type!='field'){
    let raw={...r};delete raw.outboundTag;group('opaque',[sprintf('%J',canonical(raw))],'{}');continue;
   }
   group('domain',r.domain||[],conditions);group('ip',r.ip||[],conditions);
   if(!r.domain&&!r.ip)group('opaque',[sprintf('%J',canonical(r))],conditions);
  }
  // Refuse a concurrent replacement rather than caching a mixed snapshot.
  if(digest.sha256(boundedRead(path,cap)||'')!=fingerprint)return {id,available:false,stale:true,reason:'Источник обновился во время анализа'};
  pageCache={key,revision,groups,total};
 }
 let snapshot=pageCache;
 if(version&&version!=snapshot.revision)return {id,available:false,stale:true,reason:'Источник обновился во время анализа'};
 let items=[],bytes=0,full=false;
 for(let g in snapshot.groups){
  if(cursor>=g.start+length(g.values))continue;
  for(let i=max(0,cursor-g.start);i<length(g.values);i++){
   let value=g.values[i],size=length(value)+length(g.scope)+80;
   if(size>80000||length(items)>=512||bytes+size>80000){full=true;break;}
   push(items,{kind:g.kind,value,scope:g.scope});bytes+=size;
  }
  if(full)break;
 }
 if(!length(items)&&cursor<snapshot.total)return {id,available:false,reason:'Слишком большое или неизвестное правило'};
 return {id,available:true,version:snapshot.revision,total:snapshot.total,items,next:cursor+length(items)<snapshot.total?cursor+length(items):null};
};
