# PupsPanel Rust engine

Baseline: Pupsinator 0.6.4. Upstream: aimalygin/xray-rust,
commit `3cef7c42c2fd296afd27ab0b6435c632842e1a26` (0.10.1).

Xray remains active during qualification. After all gates pass, the user now
requires Rust to replace the main engine, with Xray retained only for rollback.
Installing a test binary must not modify the active
engine, subscription, server order, routing, DNS or NodeWatch. A TCP endpoint
check is not a successful VPN functional test, especially for Hysteria2.

Activation requires all gates on the SNR ARM64 router:

- Every transport parameter is implemented equivalently or rejected with its
  JSON path. No lossy conversion is permitted.
- Selective/full/provider-whitelist routing, automatic/manual DNS, device
  overrides, TCP and real HTTPS probes, manual/priority/latency strategies.
- Atomic hot rule replacement and selector updates, restart recovery,
  diagnostics, update/rollback behavior.
- Same configuration, node, rules, traffic and concurrency for memory
  comparison; record idle/active RSS and peak memory, not binary size alone.
- Tested return to the retained Xray binary and configuration.

The upstream CLI lacks Pupsinator's RoutingService API and fixed-target
dokodemo-door DNS forwarding. The lab adapter implements a private Unix control
socket, Linux TUN ownership and bounded TCP/UDP DNS bridges retaining the
original routing tags. These are unqualified until real router tests pass.

The adapter rejects unknown API/TUN/DNS bridge fields and parser warnings about
unsupported behavior. Only the explicit transparent LAN listener exposure
warning is acknowledged. Source-sensitive DNS bridge routing is rejected.
The runtime package allowlist does not include the experimental engine yet.
See `qualification.json`: no pending gate counts as a pass.
The first SNR test did not qualify this engine; see [the report](QUALIFICATION.md).

Build tools: `tools/rust-*`. Private configurations and test artifacts are
excluded from runtime packaging.

## Final 0.7.0 qualification

The main SNR engine is now Rust, with compressed Go recovery only. See
`qualification.json` for exact evidence and remaining platform/UI limits.
Earlier text above records the original qualification plan, not current
activation state. The final AD-request compatibility patch preserves ordinary
musl/BusyBox DNS queries without asserting authenticated DNSSEC answers.
