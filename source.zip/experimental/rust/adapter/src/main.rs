//! Lab adapter: no production activation before the compatibility gate passes.
mod dns;
mod compat;
use serde::Deserialize;
use serde_json::{json, Value};
use std::{env, fs, os::{fd::{AsRawFd, IntoRawFd}, unix::fs::{PermissionsExt, FileTypeExt, OpenOptionsExt}}, path::Path, process::Command};
use tokio::{io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, BufReader}, net::{UnixListener, UnixStream}, time::{timeout, Duration}, task::JoinSet};
use xray_config::{parse_xray_json, CoreConfig};
use xray_core_rs::{Core, TunMtu, TunRuntimeOptions, TunFdConfig, TunFdRuntime, TunFdClosePolicy, TunFdPacketFormat, RuntimeLogger, RuntimeLogConfig};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error + Send + Sync>>;
const MAX_REQUEST: u64 = 24 * 1024 * 1024;

#[derive(Clone)]
struct TunPlan { name: String, mtu: u32, gateway: Vec<String> }
#[derive(Clone)]
struct DnsBridge { tag: String, listen: std::net::SocketAddr, target: std::net::SocketAddr, tcp: bool, udp: bool }
struct Parsed { core: CoreConfig, tun: Option<TunPlan>, bridges: Vec<DnsBridge>, selections: Vec<(String,String)>, logging: Option<bool> }

fn immutable(value: &Value) -> Value {
    Value::Object(value.as_object().map(|o| o.iter().filter(|(key,_)| key.as_str() != "routing").map(|(k,v)| (k.clone(),v.clone())).collect()).unwrap_or_default())
}

fn parse(mut mapped: Value) -> Result<Parsed> {
    let log=mapped.get("log");
    if log.is_some_and(|v| !v.is_object()) { return Err("$.log: expected object".into()); }
    if log.and_then(|v|v.get("loglevel")).is_some_and(|v| !v.is_string()) { return Err("$.log.loglevel: expected string".into()); }
    if let Some(fields)=log.and_then(Value::as_object) {
        for key in fields.keys() {
            if key!="loglevel" && key!="access" { return Err(format!("$.log.{key}: unsupported host log option").into()); }
        }
    }
    if log.and_then(|v|v.get("access")).is_some_and(|v|v!="none") { return Err("$.log.access: PupsPanel supports access=none only".into()); }
    let logging=match log.and_then(|v|v.get("loglevel")).and_then(Value::as_str).unwrap_or("warning") {
        "none"=>None,"warning"|"error"=>Some(false),"debug"=>Some(true),_=>return Err("$.log.loglevel: unsupported level".into()),
    };
    // Adapter-owned API operations below replace this exact RoutingService.
    // Reject any unfamiliar service, listener or additional field.
    if let Some(api) = mapped.get("api") {
        if api != &json!({"tag":"api","listen":"127.0.0.1:15457","services":["RoutingService"]}) {
            return Err("$.api: unsupported API configuration".into());
        }
        mapped.as_object_mut().ok_or("$: expected object")?.remove("api");
    }
    // Go RoutingService accepts overrides outside the startup selector prefix.
    // The SDK requires static candidates: retain every node and pin the exact
    // initial selection before startup, rather than changing random behavior.
    let nodes: Vec<String> = mapped["outbounds"].as_array().ok_or("$.outbounds: expected array")?.iter()
        .filter_map(|o| o["tag"].as_str().filter(|t| t.starts_with("node-")).map(str::to_owned)).collect();
    let mut selections = Vec::new();
    if let Some(groups) = mapped.get_mut("routing").and_then(|r|r.get_mut("balancers")).and_then(Value::as_array_mut) {
        for group in groups {
            let tag = group["tag"].as_str().unwrap_or("").to_owned();
            if tag != "vpn" && tag != "default-route" { continue; }
            let selector = group["selector"].as_array().filter(|v| v.len()==1).and_then(|v| v[0].as_str()).ok_or("$.routing.balancers: expected one exact initial candidate")?.to_owned();
            if group["strategy"] != json!({"type":"random"}) || !(nodes.contains(&selector) || (tag=="default-route" && selector=="direct")) {
                return Err("$.routing.balancers: unsupported Pupsinator selector shape".into());
            }
            let mut candidates = nodes.clone();
            if tag=="default-route" { candidates.push("direct".into()); }
            group["selector"] = json!(candidates);
            selections.push((tag,selector));
        }
    }
    let mut tun = None;
    let mut bridges = Vec::new();
    for (index, inbound) in mapped["inbounds"].as_array_mut().ok_or("$.inbounds: expected array")?.iter_mut().enumerate() {
        if inbound["protocol"] == "tun" {
            if inbound["sniffing"]["enabled"] == true && inbound["sniffing"]["destOverride"].as_array().is_some_and(|v| v.iter().any(|p| p=="http" || p=="tls")) && inbound["sniffing"]["routeOnly"] != true {
                return Err(format!("$.inbounds[{index}].sniffing.routeOnly: Pupsinator TUN requires routeOnly=true to preserve the original destination").into());
            }
            let path = format!("$.inbounds[{index}].settings");
            let settings = inbound["settings"].as_object().ok_or(format!("{path}: expected object"))?;
            let allowed = ["name", "mtu", "gateway", "autoSystemRoutingTable", "autoSystemDnsToGateway"];
            for key in settings.keys() {
                if !allowed.contains(&key.as_str()) { return Err(format!("{path}.{key}: unsupported TUN option").into()); }
            }
            if tun.is_some() { return Err(format!("{path}: multiple TUN interfaces unsupported").into()); }
            if settings.get("autoSystemRoutingTable") != Some(&json!([])) || settings.get("autoSystemDnsToGateway") != Some(&json!(false)) {
                return Err(format!("{path}: automatic OS routing/DNS must stay disabled; Pupsinator owns these rules").into());
            }
            let name = settings.get("name").and_then(Value::as_str).ok_or(format!("{path}.name: required"))?;
            if name.is_empty() || name.len() > 15 || !name.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_') { return Err(format!("{path}.name: invalid interface name").into()); }
            let mtu = settings.get("mtu").and_then(Value::as_u64).filter(|v| (1280..=9000).contains(v)).ok_or(format!("{path}.mtu: invalid MTU"))? as u32;
            let mut gateway = Vec::new();
            for address in settings.get("gateway").and_then(Value::as_array).ok_or(format!("{path}.gateway: expected array"))? {
                let text = address.as_str().ok_or(format!("{path}.gateway: expected CIDR"))?;
                let (ip, prefix) = text.split_once('/').ok_or(format!("{path}.gateway: expected CIDR"))?;
                let _: std::net::Ipv4Addr = ip.parse().map_err(|_| format!("{path}.gateway: IPv4 required"))?;
                let _: u8 = prefix.parse::<u8>().ok().filter(|v| *v <= 32).ok_or(format!("{path}.gateway: invalid prefix"))?;
                gateway.push(text.to_owned());
            }
            tun = Some(TunPlan { name: name.to_owned(), mtu, gateway });
            // These fields are implemented by open_tun(), not ignored by the parser.
            inbound["settings"] = json!({});
        }
        if inbound["protocol"] == "dokodemo-door" && inbound["settings"].get("address").is_some() {
            let path = format!("$.inbounds[{index}]");
            let settings = inbound["settings"].as_object().ok_or(format!("{path}.settings: expected object"))?;
            for key in settings.keys() {
                if !["address", "port", "network"].contains(&key.as_str()) { return Err(format!("{path}.settings.{key}: unsupported DNS bridge setting").into()); }
            }
            let address: std::net::IpAddr = settings.get("address").and_then(Value::as_str).ok_or(format!("{path}.settings.address: required"))?.parse()?;
            let port = settings.get("port").and_then(Value::as_u64).filter(|p| *p == 53).ok_or(format!("{path}.settings.port: only DNS forwarding is implemented"))? as u16;
            let network = settings.get("network").and_then(Value::as_str).ok_or(format!("{path}.settings.network: required"))?;
            if !["tcp", "udp", "tcp,udp"].contains(&network) { return Err(format!("{path}.settings.network: unsupported network").into()); }
            let listen_ip: std::net::IpAddr = inbound["listen"].as_str().ok_or(format!("{path}.listen: required"))?.parse()?;
            let listen_port = inbound["port"].as_u64().filter(|p| *p > 0 && *p <= 65535).ok_or(format!("{path}.port: invalid"))? as u16;
            let tag = inbound["tag"].as_str().ok_or(format!("{path}.tag: required"))?.to_owned();
            bridges.push(DnsBridge { tag, listen: (listen_ip, listen_port).into(), target: (address,port).into(), tcp: network.contains("tcp"), udp: network.contains("udp") });
            // The host preserves fixed-target DNS semantics through this same
            // inbound tag. An ephemeral loopback SOCKS port is never exposed.
            inbound["protocol"] = json!("socks");
            inbound["listen"] = json!("127.0.0.1");
            inbound["port"] = json!(0);
            inbound["settings"] = json!({"udp":true});
        }
    }
    let parsed = parse_xray_json(&serde_json::to_string(&mapped)?)
        .map_err(|e| format!("configuration rejected: {}", serde_json::to_string(&e.diagnostics).unwrap_or_default()))?;
    let rejected: Vec<_> = parsed.diagnostics.iter().filter(|d| {
        // This exposure warning describes the explicit transparent LAN inlet,
        // not an ignored option. The WS Host deprecation also retains the
        // exact Go semantics (explicit host wins, otherwise headers.Host).
        // Unknown/unsupported behavior still fails closed.
        let exposure = d.message == "wildcard listen address exposes this inbound to other devices on the network; use 127.0.0.1 unless LAN sharing is intended"
          && d.path.as_ref().is_some_and(|p| p.ends_with(".listen"));
        let legacy_ws_host = d.message == "`host` in `headers` is deprecated; use the independent `host` field"
          && d.path.as_ref().is_some_and(|p| p.ends_with(".streamSettings.wsSettings.headers"));
        !(exposure || legacy_ws_host)
    }).collect();
    if !rejected.is_empty() {
        return Err(format!("strict compatibility check: {}", serde_json::to_string(&rejected)?).into());
    }
    // Source-sensitive DNS routing cannot be preserved across a loopback bridge.
    if !bridges.is_empty() && mapped["routing"]["rules"].as_array().is_some_and(|rules| rules.iter().any(|r| r.get("source").is_some() || r.get("sourcePort").is_some())) {
        return Err("$.routing.rules: source-sensitive DNS bridge routing is unsupported".into());
    }
    Ok(Parsed { core: parsed.config, tun, bridges, selections, logging })
}

struct SocketGuard { path: String, _lock: fs::File }
impl Drop for SocketGuard {
    fn drop(&mut self) { let _ = fs::remove_file(&self.path); }
}

fn bind_control(path: &str) -> Result<(UnixListener,SocketGuard)> {
    let lock = fs::OpenOptions::new().create(true).read(true).write(true).mode(0o600).open(format!("{path}.lock"))?;
    if unsafe { libc::flock(lock.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) } != 0 { return Err("control socket is owned by a running instance".into()); }
    if Path::new(path).exists() {
        if !fs::symlink_metadata(path)?.file_type().is_socket() { return Err("control path is not a Unix socket".into()); }
        fs::remove_file(path)?;
    }
    let listener=UnixListener::bind(path)?;
    let guard=SocketGuard { path:path.to_owned(), _lock:lock };
    fs::set_permissions(path,fs::Permissions::from_mode(0o600))?;
    Ok((listener,guard))
}

fn open_tun(plan: &TunPlan) -> Result<fs::File> {
    if Path::new(&format!("/sys/class/net/{}", plan.name)).exists() { return Err("TUN name already exists; refusing to touch it".into()); }
    let file = fs::OpenOptions::new().read(true).write(true).open("/dev/net/tun")?;
    let mut request = [0u8; 40];
    request[..plan.name.len()].copy_from_slice(plan.name.as_bytes());
    request[16..18].copy_from_slice(&((libc::IFF_TUN | libc::IFF_NO_PI) as i16).to_ne_bytes());
    if unsafe { libc::ioctl(file.as_raw_fd(), 0x400454ca as _, request.as_mut_ptr()) } < 0 { return Err(std::io::Error::last_os_error().into()); }
    for address in &plan.gateway {
        if !Command::new("ip").args(["addr", "add", address, "dev", &plan.name]).status()?.success() { return Err("TUN address setup failed".into()); }
    }
    if !Command::new("ip").args(["link", "set", "dev", &plan.name, "mtu", &plan.mtu.to_string(), "up"]).status()?.success() { return Err("TUN link setup failed".into()); }
    Ok(file)
}

#[derive(Deserialize)]
#[serde(tag = "op", rename_all = "kebab-case", deny_unknown_fields)]
enum Request {
    Status {},
    Select { group: String, outbound: String },
    Routing { config: Value },
    Rules { routing: Value },
}

fn handle(core: &Core, active: &mut Value, request: Request) -> Result<Value> {
    match request {
        Request::Status {} => {
            let snapshot=core.outbound_selection_snapshot();
            let groups:Vec<_>=snapshot.groups.iter().map(|g| json!({"tag":g.tag,"override":g.override_tag,"candidates":g.candidates.len()})).collect();
            Ok(json!({"engine":"xray-rust","upstream":"3cef7c42c2fd296afd27ab0b6435c632842e1a26","experimental":true,"selectionRevision":snapshot.revision,"groups":groups}))
        }
        Request::Select { group, outbound } => {
            if group != "vpn" && group != "default-route" { return Err("unknown selector".into()); }
            Ok(json!({"revision":core.set_outbound_selector_override(&group, &outbound)?}))
        }
        Request::Routing { mut config } => {
            let routing = config.as_object_mut().ok_or("invalid replacement config")?.remove("routing").ok_or("missing $.routing")?;
            if &config != active { return Err("hot replacement may change only $.routing".into()); }
            config.as_object_mut().unwrap().insert("routing".into(), routing);
            let parsed = parse(config)?;
            let revision = core.replace_routing_policy(parsed.core.routing)?;
            Ok(json!({"revision":revision}))
        }
        Request::Rules { routing } => {
            let mut config=active.clone();
            config.as_object_mut().ok_or("invalid active config")?.insert("routing".into(),routing);
            let parsed=parse(config)?;
            Ok(json!({"revision":core.replace_routing_policy(parsed.core.routing)?}))
        }
    }
}

async fn serve(config_path: &str, socket_path: &str) -> Result<()> {
    let config: Value = serde_json::from_slice(&fs::read(config_path)?)?;
    let mut active = immutable(&config);
    let parsed = parse(config)?;
    let mut options = TunRuntimeOptions::default();
    let tun_file = if let Some(plan) = &parsed.tun { options.mtu = TunMtu::new(plan.mtu)?; Some(open_tun(plan)?) } else { None };
    let mut core = Core::with_tun_runtime_options(parsed.core, options)?;
    if env::var("PUPS_RUST_LAB_LOG").as_deref()==Ok("1") {
        let dir=Path::new(socket_path).parent().ok_or("control socket parent required")?;
        core.set_runtime_logger(RuntimeLogger::new(RuntimeLogConfig::directory(dir))?);
    } else if let Some(debug)=parsed.logging {
        let dir=Path::new(socket_path).parent().ok_or("control socket parent required")?;
        core.set_runtime_logger(RuntimeLogger::bounded(RuntimeLogConfig::directory(dir),debug,false,65536)?);
    }
    for (group,target) in parsed.selections { core.set_outbound_selector_override(&group,&target)?; }
    let (listener,_socket_guard) = bind_control(socket_path)?;
    if let Err(error) = core.start().await { let _ = fs::remove_file(socket_path); return Err(error.into()); }
    let mut bridge_tasks = JoinSet::new();
    let permits = std::sync::Arc::new(tokio::sync::Semaphore::new(32));
    for plan in parsed.bridges {
        let address = core.inbound_addr(Some(&plan.tag)).ok_or("missing DNS bridge inlet")?;
        if let Err(error) = dns::spawn(plan, address, &mut bridge_tasks, permits.clone()).await {
            bridge_tasks.abort_all(); let _ = core.stop().await; let _ = fs::remove_file(socket_path); return Err(error);
        }
    }
    let tun_runtime = if let Some(file) = tun_file {
        let fd = file.into_raw_fd();
        match TunFdRuntime::start(TunFdConfig::new(fd, TunFdPacketFormat::RawIp, TunFdClosePolicy::Owned), core.tun_handle()) {
            Ok(runtime) => Some(runtime),
            Err(error) => { let _ = core.stop().await; let _ = fs::remove_file(socket_path); return Err(error.into()); }
        }
    } else { None };
    let mut term = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())?;
    loop {
        tokio::select! {
            _ = term.recv() => break,
            _ = tokio::signal::ctrl_c() => break,
            connection = listener.accept() => {
                let (mut stream, _) = connection?;
                let result: Result<Value> = async {
                    let mut line = String::new();
                    timeout(Duration::from_secs(10), BufReader::new((&mut stream).take(MAX_REQUEST + 1)).read_line(&mut line)).await??;
                    if line.len() as u64 > MAX_REQUEST { return Err("request too large".into()); }
                    handle(&core, &mut active, serde_json::from_str(&line)?)
                }.await;
                let response = match result { Ok(value) => json!({"ok":true,"result":value}), Err(error) => json!({"ok":false,"error":error.to_string()}) };
                let _ = timeout(Duration::from_secs(5), stream.write_all(format!("{response}\n").as_bytes())).await;
            }
        }
    }
    bridge_tasks.abort_all();
    while bridge_tasks.join_next().await.is_some() {}
    if let Some(runtime) = tun_runtime { runtime.stop().await; }
    let result = core.stop().await;
    let _ = fs::remove_file(socket_path);
    result?;
    Ok(())
}

#[tokio::main(worker_threads = 1)]
async fn main() {
    let result: Result<()> = async {
        let args: Vec<String> = env::args().collect();
        if compat::run(&args).await? { return Ok(()); }
        match args.get(1).map(String::as_str) {
            Some("check") if args.len() == 3 => {
                parse(serde_json::from_slice::<Value>(&fs::read(&args[2])?)?)?;
                println!("strict parser check passed; runtime compatibility remains unproven");
            }
            Some("lab-run") if args.len() == 4 => serve(&args[2], &args[3]).await?,
            Some("request" | "request-file") if args.len() == 4 => {
                let payload=if args[1]=="request-file" { fs::read_to_string(&args[3])? } else { args[3].clone() };
                if payload.len() as u64>MAX_REQUEST { return Err("request too large".into()); }
                let _: Request = serde_json::from_str(&payload)?;
                let mut stream = UnixStream::connect(&args[2]).await?;
                stream.write_all(format!("{payload}\n").as_bytes()).await?;
                let mut line = String::new();
                timeout(Duration::from_secs(95), BufReader::new(stream.take(MAX_REQUEST)).read_line(&mut line)).await??;
                let response: Value = serde_json::from_str(&line)?;
                println!("{response}");
                if response["ok"] != true { return Err("control request rejected".into()); }
            }
            _ => return Err("usage: pupsinator-rust check FILE | lab-run FILE SOCKET | request SOCKET JSON".into()),
        }
        Ok(())
    }.await;
    if let Err(error) = result { eprintln!("{error}"); std::process::exit(1); }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn config() -> Value {
        json!({"api":{"tag":"api","listen":"127.0.0.1:15457","services":["RoutingService"]},
            "inbounds":[{"tag":"service","listen":"127.0.0.1","port":15990,"protocol":"socks","settings":{"udp":true}}],
            "outbounds":[{"tag":"direct","protocol":"freedom","settings":{}}],
            "routing":{"domainStrategy":"AsIs","rules":[]}})
    }

    #[test]
    fn unknown_api_is_rejected() {
        let mut value = config();
        value["api"]["services"] = json!(["RoutingService","StatsService"]);
        assert!(parse(value).err().unwrap().to_string().contains("$.api"));
    }

    #[test]
    fn tun_options_are_not_silently_discarded() {
        let mut value = config();
        value["inbounds"] = json!([{"tag":"tun-in","protocol":"tun","settings":{"name":"labtun0","mtu":1400,"gateway":["172.31.254.1/30"],"autoSystemRoutingTable":[],"autoSystemDnsToGateway":false,"unsupported":true}}]);
        assert!(parse(value).err().unwrap().to_string().contains(".unsupported"));
    }

    #[test]
    fn unknown_transport_parameter_is_rejected() {
        let mut value = config();
        value["outbounds"] = json!([{"tag":"node-demo","protocol":"vless","settings":{"vnext":[{"address":"example.invalid","port":443,"users":[{"id":"00000000-0000-4000-8000-000000000001","encryption":"none"}]}]},"streamSettings":{"network":"xhttp","security":"tls","tlsSettings":{"serverName":"example.invalid"},"xhttpSettings":{"path":"/","mode":"packet-up","extra":{"unimplementedOption":true}}}}]);
        assert!(parse(value).is_err());
    }

    #[test]
    fn control_requests_reject_unknown_fields() {
        assert!(serde_json::from_value::<Request>(json!({"op":"select","group":"vpn","outbound":"node-demo","ignored":true})).is_err());
        assert!(serde_json::from_value::<Request>(json!({"op":"status","ignored":true})).is_err());
    }

    #[test]
    fn immutable_identity_does_not_copy_rules() {
        let mut value = config();
        value["routing"]["rules"] = json!([{"type":"field","domain":["domain:example.invalid"],"outboundTag":"direct"}]);
        assert!(immutable(&value).get("routing").is_none());
        assert_eq!(immutable(&value)["outbounds"], value["outbounds"]);
    }
}
