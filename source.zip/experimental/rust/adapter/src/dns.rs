//! Bounded fixed-target DNS bridges using the core's original inbound tags.
use super::{DnsBridge, Result};
use std::{net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr}, sync::Arc};
use tokio::{io::{AsyncReadExt, AsyncWriteExt}, net::{TcpListener, TcpStream, UdpSocket}, sync::Semaphore, task::JoinSet, time::{timeout, Duration}};

fn address(value: SocketAddr) -> Vec<u8> {
    let mut bytes = match value.ip() {
        IpAddr::V4(ip) => { let mut b = vec![1]; b.extend(ip.octets()); b }
        IpAddr::V6(ip) => { let mut b = vec![4]; b.extend(ip.octets()); b }
    };
    bytes.extend(value.port().to_be_bytes());
    bytes
}

async fn socks(server: SocketAddr, command: u8, target: SocketAddr) -> Result<(TcpStream, SocketAddr)> {
    let mut stream = TcpStream::connect(server).await?;
    stream.write_all(&[5,1,0]).await?;
    let mut greeting = [0;2]; stream.read_exact(&mut greeting).await?;
    if greeting != [5,0] { return Err("DNS bridge SOCKS authentication failed".into()); }
    let mut request = vec![5,command,0]; request.extend(address(target));
    stream.write_all(&request).await?;
    let mut header = [0;4]; stream.read_exact(&mut header).await?;
    if header[..3] != [5,0,0] { return Err("DNS bridge SOCKS request rejected".into()); }
    let ip = match header[3] {
        1 => { let mut b = [0;4]; stream.read_exact(&mut b).await?; IpAddr::V4(Ipv4Addr::from(b)) }
        4 => { let mut b = [0;16]; stream.read_exact(&mut b).await?; IpAddr::V6(Ipv6Addr::from(b)) }
        _ => return Err("DNS bridge invalid relay address".into()),
    };
    let mut port = [0;2]; stream.read_exact(&mut port).await?;
    let ip = if ip.is_unspecified() { server.ip() } else { ip };
    Ok((stream, (ip,u16::from_be_bytes(port)).into()))
}

pub async fn spawn(plan: DnsBridge, server: SocketAddr, tasks: &mut JoinSet<()>, permits: Arc<Semaphore>) -> Result<()> {
    let tcp = if plan.tcp { Some(TcpListener::bind(plan.listen).await?) } else { None };
    let udp = if plan.udp { Some(Arc::new(UdpSocket::bind(plan.listen).await?)) } else { None };
    if let Some(listener) = tcp {
        let permits = permits.clone();
        let target = plan.target;
        tasks.spawn(async move {
            let mut workers = JoinSet::new();
            loop {
                tokio::select! {
                    _ = workers.join_next(), if !workers.is_empty() => {},
                    accepted = listener.accept() => {
                        let Ok((mut client, _)) = accepted else { break };
                        let Ok(permit) = permits.clone().try_acquire_owned() else { continue };
                        workers.spawn(async move {
                            let _permit = permit;
                            let _ = async {
                                let (mut upstream, _) = timeout(Duration::from_secs(8), socks(server, 1, target)).await??;
                                tokio::io::copy_bidirectional(&mut client, &mut upstream).await?;
                                Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
                            }.await;
                        });
                    }
                }
            }
        });
    }
    if let Some(listener) = udp {
        tasks.spawn(async move {
            let mut buffer = vec![0;65535];
            let mut workers = JoinSet::new();
            loop {
                tokio::select! {
                    _ = workers.join_next(), if !workers.is_empty() => {},
                    packet = listener.recv_from(&mut buffer) => {
                        let Ok((len, client)) = packet else { break };
                        let Ok(permit) = permits.clone().try_acquire_owned() else { continue };
                        let packet = buffer[..len].to_vec();
                        let listener = listener.clone();
                        let target = plan.target;
                        workers.spawn(async move {
                            let _permit = permit;
                            let _ = timeout(Duration::from_secs(8), async {
                                let udp = UdpSocket::bind("127.0.0.1:0").await?;
                                let (_control, relay) = socks(server, 3, udp.local_addr()?).await?;
                                udp.connect(relay).await?;
                                let mut request = vec![0,0,0]; request.extend(address(target)); request.extend(packet);
                                udp.send(&request).await?;
                                let mut response = vec![0;65535];
                                let len = udp.recv(&mut response).await?;
                                if len < 4 || response[..3] != [0,0,0] { return Err("invalid SOCKS UDP response".into()); }
                                let offset = match response[3] { 1 => 10, 4 => 22, 3 if len >= 5 => 7 + response[4] as usize, _ => return Err("invalid SOCKS UDP address".into()) };
                                if len < offset { return Err("truncated SOCKS UDP response".into()); }
                                listener.send_to(&response[offset..len], client).await?;
                                Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
                            }).await;
                        });
                    }
                }
            }
        });
    }
    Ok(())
}
