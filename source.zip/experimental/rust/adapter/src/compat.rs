//! The subset of the old local CLI actually used by PupsPanel 0.6.4.
//! This translates commands to the SDK; it does not emulate a gRPC listener.
use super::*;

fn control_socket() -> String {
    env::var("PUPSINATOR_RUST_CONTROL").unwrap_or_else(|_| "/tmp/pupsinator/rust-control.sock".into())
}

pub async fn request(socket: &str, payload: &Value, seconds: u64) -> Result<Value> {
    let data=serde_json::to_vec(payload)?;
    if data.len() as u64>MAX_REQUEST { return Err("request too large".into()); }
    let mut stream=UnixStream::connect(socket).await?;
    stream.write_all(&data).await?;stream.write_all(b"\n").await?;
    let mut line=String::new();
    timeout(Duration::from_secs(seconds),BufReader::new(stream.take(MAX_REQUEST)).read_line(&mut line)).await??;
    let response:Value=serde_json::from_str(&line)?;
    if response["ok"]!=true { return Err(response["error"].as_str().unwrap_or("control request rejected").to_owned().into()); }
    Ok(response)
}

pub async fn run(args: &[String]) -> Result<bool> {
    match args.get(1).map(String::as_str) {
        Some("probe") if args.len()==5 => {
            let parsed=parse(serde_json::from_slice::<Value>(&fs::read(&args[2])?)?)?;
            if parsed.tun.is_some() || !parsed.bridges.is_empty() { return Err("probe expects an isolated outbound configuration".into()); }
            let mut core=Core::new(parsed.core)?.with_startup_probe(xray_core_rs::StartupProbeOptions {url:args[4].clone(),timeout:Duration::from_secs(10),outbound_tag:Some(args[3].clone())});
            core.start().await?;core.stop().await?;
            println!("Real outbound probe passed");Ok(true)
        }
        Some("version") if args.len()==2 => {
            println!("Xray-rust 0.10.1 (PupsPanel adapter 0.1.0; upstream 3cef7c42; patchset 1)");
            Ok(true)
        }
        Some("run") => {
            let mut file=None;let mut check=false;let mut i=2;
            while i<args.len() {
                match args[i].as_str() {
                    "-config"|"--config" if file.is_none() => { i+=1;file=Some(args.get(i).ok_or("missing config file")?.clone()); }
                    "-test" if !check => check=true,
                    flag => return Err(format!("unsupported run argument: {flag}").into()),
                }
                i+=1;
            }
            let file=file.ok_or("missing -config FILE")?;
            if check {
                parse(serde_json::from_slice::<Value>(&fs::read(file)?)?)?;
                println!("Configuration OK (PupsPanel Rust)");
            } else { serve(&file,&control_socket()).await?; }
            Ok(true)
        }
        Some("api") => {
            let command=args.get(2).ok_or("missing API command")?;
            let mut group=None;let mut positional=Vec::new();let mut seconds=95;let mut i=3;
            while i<args.len() {
                let flag=&args[i];
                if flag=="--server=127.0.0.1:15457" {
                    // The old private endpoint identifies this application's
                    // control plane. Rust uses the root-only Unix socket.
                } else if let Some(value)=flag.strip_prefix("--timeout=") {
                    seconds=value.parse::<u64>()?.checked_add(5).filter(|n| (6..=125).contains(n)).ok_or("API timeout out of range")?;
                } else if flag=="-b" && group.is_none() {
                    i+=1;group=Some(args.get(i).ok_or("missing balancer tag")?.clone());
                } else if flag.starts_with('-') { return Err(format!("unsupported API argument: {flag}").into()); }
                else { positional.push(flag.clone()); }
                i+=1;
            }
            let payload=match command.as_str() {
                "bo" if positional.len()==1 => json!({"op":"select","group":group.ok_or("missing -b GROUP")?,"outbound":positional[0]}),
                "adrules" if positional.len()==1 && group.is_none() => {
                    let value:Value=serde_json::from_slice(&fs::read(&positional[0])?)?;
                    if value.as_object().is_none_or(|o| o.len()!=1 || !o.contains_key("routing")) { return Err("adrules expects only a routing object".into()); }
                    json!({"op":"rules","routing":value["routing"]})
                }
                "bi" if group.is_none() && positional.is_empty() => json!({"op":"status"}),
                _ => return Err("unsupported API command or arguments".into()),
            };
            println!("{}",request(&control_socket(),&payload,seconds).await?);
            Ok(true)
        }
        _ => Ok(false),
    }
}
