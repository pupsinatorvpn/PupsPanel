The experimental adapter links xray-rust by aimalygin and its contributors,
licensed under MPL-2.0. Upstream source and license:

https://github.com/aimalygin/xray-rust/tree/3cef7c42c2fd296afd27ab0b6435c632842e1a26

The new adapter files are covered by Pupsinator's MIT license. This does not
relicense upstream files or dependencies. Any experimental binary distribution
must include upstream MPL-2.0 notices and the corresponding source reference,
along with required dependency notices.

`arm64-musl.patch` changes the upstream Linux TPROXY file to account for musl's
32-bit socket-control length fields on ARM64. That modified file remains under
MPL-2.0. The patch must accompany corresponding experimental source releases.

`patches/upstream-310.diff` is the author's TUN TCP sniffing implementation
from https://github.com/aimalygin/xray-rust/pull/310. Only the core and runtime
test hunks are applied; Pupsinator requires routeOnly=true, so the saved-profile
migration that delayed upstream adoption does not affect this integration.

`patches/xhttp-empty-header-body.patch` fixes prematurely cancelled HTTP/2
header/cookie uplinks. `patches/bounded-host-logging.patch` adds bounded,
filtered host diagnostics and removes idle logger polling. Modified upstream
files retain MPL-2.0; these patches accompany corresponding source releases.

`patches/dns-ad-request.patch` accepts the standard AD request flag without
claiming DNSSEC authentication in synthesized replies. CD, DO and unsupported
EDNS semantics retain upstream's explicit refusal. The modified upstream
file remains MPL-2.0; the patch includes its regression assertion.
