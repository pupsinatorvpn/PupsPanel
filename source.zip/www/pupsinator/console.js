'use strict';
const $=id=>document.getElementById(id), $$=s=>[...document.querySelectorAll(s)];
const catalog=window.PUPS_CATALOG.lists;
const groupNames={regional:'Обход ограничений',media:'Видео, музыка и книги',social:'Соцсети и общение',gaming:'Игры',ai:'Нейросети',tech:'Приложения и работа',other:'Другие сайты',direct:'Исключения без VPN',block:'Реклама и защита',mobile_whitelist:'Мобильные белые списки',infra:'Сети и инфраструктура',internal:'Технические наборы'};
const shortNames={russia_inside:'Обход ограничений в России',geoblock:'Сервисы, закрывшие доступ из России',block:'Базовый список ограниченных сайтов',ru_blocked:'Ограниченные сайты — очищенный список',ru_blocked_all:'Ограниченные сайты — полный список',russia_outside:'Российские сервисы из-за рубежа',ru_whitelist:'Российские сервисы напрямую',ru_domains:'Домены России и СНГ',ru_only_inside:'Сайты, доступные только из России',ai_all:'Все основные нейросети',meta:'Instagram, Facebook и Threads',games_all:'Все основные игровые платформы',mobile_whitelist:'Мобильный белый список: домены',mobile_whitelist_ip:'Мобильный белый список: IP-подсети',ads_hagezi_pro:'Реклама и трекеры',captcha_auth:'Капчи и вход в аккаунты',rutracker_lampa:'RuTracker, Lampa, KinoPub и Flibusta',hodca:'Проверка сертификатов сайтов'};
const routeNames={selective:['Только выбранные сайты','Включённые списки и свои VPN-правила идут через сервер. Остальной интернет напрямую.'],all:['Весь интернет через VPN','Все внешние сайты через сервер. Прямые исключения сохраняются.'],whitelist:['VPN + мобильные белые списки','Сайты из белого списка напрямую, остальное через VPN. Сервер должен быть доступен при ограничениях.']};
const strategyNames={manual:'Вручную',priority:'По порядку',latency:'По задержке'};
const actionNames={apply:'Применение настроек',refresh:'Обновление подписки',test:'Включение VPN',disconnect:'Выключение VPN',restart:'Перезапуск VPN',diagnose:'Диагностика',confirm:'Подтверждение подключения',stop:'Выключение VPN',connect:'Включение VPN',preload:'Загрузка списков','lists-update':'Обновление списков'};
const successMessages={apply:'Настройки применены.',refresh:'Подписка обновлена.',test:'VPN включён. Проверь сайты и подтверди подключение.',disconnect:'VPN выключен. Интернет идёт напрямую.',restart:'VPN перезапущен.',diagnose:'Диагностика завершена. Результаты ниже.',confirm:'Подключение подтверждено.',stop:'VPN выключен.',connect:'VPN включён.',preload:'Выбранные списки сохранены на роутере.'};
let state=null,draft=null,seq=0,waiting=new Map(),operation=false,polling=false,dirtyRules=false,dirtyServers=false,backgroundWasBusy=false;
let cached=new Set(),catalogOpen=new Set(),lastDiagnostic=0;
function node(tag,attrs={},text){const el=document.createElement(tag);for(const [k,v] of Object.entries(attrs)){if(k==='class')el.className=v;else el.setAttribute(k,v)}if(text!=null)el.textContent=text;return el}
function notify(message,error=false){$('notice').hidden=false;$('notice').textContent=message;$('notice').classList.toggle('error',error)}
function tab(id){$$('.page').forEach(p=>p.classList.toggle('active',p.id===id));$$('nav button').forEach(b=>b.classList.toggle('selected',b.dataset.tab===id));}
$$('[data-tab]').forEach(b=>b.onclick=()=>tab(b.dataset.tab));$$('[data-go]').forEach(b=>b.onclick=()=>tab(b.dataset.go));
document.querySelector('.brand').onclick=e=>{e.preventDefault();tab('overview')};
function api(method,payload){return new Promise((resolve,reject)=>{const id=++seq,timer=setTimeout(()=>{waiting.delete(id);reject(Error('Роутер не ответил. Обнови страницу и проверь подключение.'))},25000);waiting.set(id,{resolve,reject,timer});parent.postMessage({channel:'pupsinator',id,method,payload},location.origin)})}
window.addEventListener('message',e=>{if(e.source!==parent||e.origin!==location.origin||e.data?.channel!=='pupsinator-reply')return;const item=waiting.get(e.data.id);if(!item)return;clearTimeout(item.timer);waiting.delete(e.data.id);e.data.error?item.reject(Error(e.data.error)):item.resolve(e.data.result)});
const date=seconds=>seconds?new Date(seconds*1000).toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'ещё не обновлялась';
const radio=name=>document.querySelector(`input[name="${name}"]:checked`)?.value;
function setRadio(name,value){$$(`input[name="${name}"]`).forEach(x=>x.checked=x.value===value)}
function nodeById(id){return state?.nodes.find(n=>n.id===id)}
function managedList(id){return radio('routeMode')==='whitelist'&&(id===$('whiteProvider').value||id==='mobile_whitelist_ip')}
function listAction(id){if(managedList(id))return id==='mobile_whitelist_ip'&&!$('whiteIps').checked?'off':'direct';return draft.lists[id]||'off'}
function amount(n,forms){const hundreds=n%100,ones=n%10;return n+' '+(hundreds>=11&&hundreds<=14?forms[2]:ones===1?forms[0]:ones>=2&&ones<=4?forms[1]:forms[2])}
function orderedNodes(){const order=draft?.order||[];return [...(state?.nodes||[])].sort((a,b)=>{let ai=order.indexOf(a.id),bi=order.indexOf(b.id);return (ai<0?999:ai)-(bi<0?999:bi)})}
function fill(){
 draft=structuredClone(state.settings);draft.lists??={};draft.order??=state.nodes.map(n=>n.id);draft.selected=nodeById(draft.selected)?.id||state.nodes[0]?.id;
 setRadio('routeMode',draft.routeMode||'selective');setRadio('strategy',draft.strategy||'manual');
 for(const [id,key,fallback] of [['subscriptionInterval','subscriptionInterval','1'],['listsInterval','listsInterval','6'],['whiteProvider','whiteProvider','mobile_whitelist'],['dnsMode','dnsMode','auto'],['captureMode','mode','tproxy'],['dnsDirect','dnsDirect','77.88.8.8'],['dnsVpn','dnsVpn','https://1.1.1.1/dns-query'],['bootstrap','bootstrap','77.88.8.8']])$(id).value=draft[key]??fallback;
 $('whiteIps').checked=!!draft.whiteIps;$('returnPrimary').checked=draft.returnPrimary!==false;$('directRules').value=(draft.direct||[]).join('\n');$('vpnRules').value=(draft.proxy||[]).join('\n');
 $('quickServer').replaceChildren(...orderedNodes().map(n=>{let option=node('option',{value:n.id},n.name);option.selected=n.id===draft.selected;return option}));
 dirtyRules=dirtyServers=false;drawServers();drawCatalog();updateFormVisibility();
}
function updateFormVisibility(){
 $('whitelistSettings').hidden=radio('routeMode')!=='whitelist';$('manualDns').hidden=$('dnsMode').value!=='manual';$('returnPrimaryRow').hidden=radio('strategy')!=='priority';
 $('whiteExplanation').textContent=$('whiteProvider').value==='mobile_whitelist'?'Сайты из общественного списка hxehex. Подходит для режима мобильных ограничений; у твоего оператора состав может отличаться.':'Общие российские сервисы: банки, госпорталы и другие сайты. Это не белый список конкретного оператора.';
 const ids=[$('whiteProvider').value];if($('whiteIps').checked)ids.push('mobile_whitelist_ip');
 $('whiteCacheStatus').textContent=ids.every(id=>cached.has(id))?'Правила уже есть на роутере и доступны без интернета.':'При применении недостающие правила будут загружены и проверены.';
 $('rulesDirty').textContent=dirtyRules?'Есть неприменённые изменения':'Маршрутизация сохранена';
 $('listCount').textContent=catalog.filter(l=>listAction(l.id)!=='off').length+' включено · '+catalog.length+' всего';
}
function drawServers(){
 $('serverList').replaceChildren();const strategy=radio('strategy');
 orderedNodes().forEach((n,i,arr)=>{const row=node('div',{class:'server-row','data-node':n.id}),pick=node('input',{type:'radio',name:'chosenNode',value:n.id,'aria-label':'Выбрать '+n.name});pick.checked=n.id===draft.selected;pick.disabled=strategy!=='manual';pick.onchange=()=>{draft.selected=n.id;dirtyServers=true};const info=node('div');info.append(node('div',{class:'name'},n.name),node('small',{},n.transport));const measure=node('span',{class:'measure'},'Ожидает проверки');const actions=node('div',{class:'order'});for(const [label,delta] of [['↑',-1],['↓',1]]){const b=node('button',{'aria-label':(delta<0?'Поднять ':'Опустить ')+n.name},label);b.disabled=i+delta<0||i+delta>=arr.length;b.onclick=()=>{const ids=arr.map(x=>x.id);[ids[i],ids[i+delta]]=[ids[i+delta],ids[i]];draft.order=ids;dirtyServers=true;drawServers()};actions.append(b)}row.append(pick,info,measure,actions);$('serverList').append(row)});renderHealth();
}
function title(l){return shortNames[l.id]||l.title.split(' — ')[0].replace(/\s*\((Direct|Block)\)/g,'')}
function drawCatalog(){
 const q=$('searchLists').value.trim().toLocaleLowerCase('ru-RU'),filter=$('listFilter').value;let total=0;$('catalog').replaceChildren();
 for(const [group,label] of Object.entries(groupNames)){
  const all=catalog.filter(l=>l.group===group),lists=all.filter(l=>(filter!=='chosen'||listAction(l.id)!=='off')&&(filter==='all'||filter==='chosen'||filter===group)&&(!q||`${title(l)} ${l.id} ${l.title} ${l.description}`.toLocaleLowerCase('ru-RU').includes(q)));
  if(!lists.length)continue;total+=lists.length;const details=node('details',{class:'category'});details.open=!!q||filter!=='all'||catalogOpen.has(group);const summary=node('summary',{},label+' '),active=all.filter(l=>listAction(l.id)!=='off').length;summary.append(node('span',{class:'category-count'},amount(lists.length,['список','списка','списков'])+(active?' · включено '+active:'')));details.append(summary);details.ontoggle=()=>details.open?catalogOpen.add(group):catalogOpen.delete(group);
  for(const l of lists){const row=node('div',{class:'catalog-row'}),info=node('div'),desc=node('details'),sum=node('summary',{},'Что входит');info.append(node('b',{},title(l)));
   const raw=l.id==='mobile_whitelist'?'Сайты, доступные без VPN при мобильных ограничениях.':l.id==='mobile_whitelist_ip'?'Целые сети для прямого доступа. Обычно не нужно.':l.title.includes(' — ')?l.title.split(' — ').slice(1).join(' — '):l.description.replace(/^\[[^\]]+\]\s*/,''),brief=raw.length>115?raw.slice(0,112)+'…':raw;info.append(node('small',{},brief));desc.append(sum,node('p',{},l.description.replace(/^\[[^\]]+\]\s*/,'')),node('div',{class:'source'},'Источник: '+(l.id.startsWith('mobile_whitelist')?'hxehex / russia-mobile-internet-whitelist':'Каталог сообщества')+' · '+l.id));info.append(desc);
   const count=Object.values(l.counts||{}).reduce((a,b)=>a+Number(b||0),0);if(count>200000)info.append(node('small',{class:'missing-label'},'Большой список: может не поместиться на роутер'));
   info.append(node('small',{class:cached.has(l.id)?'cache-label':'missing-label','data-cache':l.id},cached.has(l.id)?'Сохранён на роутере':'Загрузится при применении'));
   const select=node('select',{'aria-label':'Маршрут: '+title(l)});for(const [value,text] of [['off','Выключено'],['proxy','Через VPN'],['direct','Напрямую'],['block','Блокировать']])select.append(node('option',{value},text));select.value=listAction(l.id);select.disabled=managedList(l.id);if(select.disabled)info.append(node('small',{},'Управляется настройками белого списка выше'));select.onchange=()=>{if(select.value==='off')delete draft.lists[l.id];else draft.lists[l.id]=select.value;dirtyRules=true;updateFormVisibility()};row.append(info,select);details.append(row);
  }$('catalog').append(details);
 }$('noLists').hidden=total>0;$('listCount').textContent=catalog.filter(l=>listAction(l.id)!=='off').length+' включено · '+catalog.length+' всего';
}
for(const [value,label] of Object.entries(groupNames))$('listFilter').append(node('option',{value},label));
$('searchLists').oninput=drawCatalog;$('listFilter').onchange=drawCatalog;
$$('input[name="routeMode"],#whiteProvider,#whiteIps,#listsInterval,#directRules,#vpnRules').forEach(x=>x.addEventListener('change',()=>{dirtyRules=true;updateFormVisibility();if(x.name==='routeMode'||x.id==='whiteProvider'||x.id==='whiteIps')drawCatalog()}));
$$('input[name="strategy"],#returnPrimary').forEach(x=>x.addEventListener('change',()=>{dirtyServers=true;updateFormVisibility();drawServers()}));$('dnsMode').onchange=updateFormVisibility;
function renderHealth(){for(const row of $$('.server-row')){const h=state.health?.results?.[row.dataset.node],target=row.querySelector('.measure');target.textContent=h?(h.ok?h.ms+' мс':`Не ответил${h.failures?' · '+h.failures+' провер.':''}`):'Ожидает проверки';target.classList.toggle('down',!!h&&!h.ok)}}
function renderDiagnostics(){const d=state.diagnostic;if(!d||d.checked===lastDiagnostic)return;lastDiagnostic=d.checked;const bad=d.checks.filter(c=>c.status==='fail'),warn=d.checks.filter(c=>c.status==='warn');$('diagnosticSummary').textContent=bad.length?'Есть проблемы: '+bad.length:warn.length?'Основные проверки пройдены, есть замечания':'Проверки пройдены';$('diagnosticTime').textContent=date(d.checked);$('diagnosticHelp').textContent='Каждая строка — отдельная проверка. Успешный запрос не гарантирует доступ ко всем сайтам.';$('diagnosticResults').replaceChildren(...d.checks.map(c=>{const row=node('div',{class:'diagnostic-row '+c.status}),text=node('div');text.append(node('b',{},c.title),node('p',{},c.detail));row.append(node('span',{class:'icon'},c.status==='ok'?'✓':c.status==='off'?'—':c.status==='warn'?'!':'×'),text);return row}))}
function render(){
 const s=state.settings,t=state.telemetry||{},active=state.active,n=nodeById(s.selected)||state.nodes[0],h=state.health?.results?.[n?.id];cached=new Set(state.cached||[]);
 $('clientIdentity').textContent=/^(PupsPanel|Pupsinator)/.test(s.ua||'')?s.ua:'Брендированное имя появится после ближайшего обновления подписки.';
 $('connectionBadge').textContent=active?'VPN включён':'VPN выключен';$('connectionBadge').classList.toggle('on',active);$('statusDot').classList.toggle('on',active);$('vpnStatus').textContent=active?'VPN включён':'VPN выключен';$('vpnDetail').textContent=active?`${routeNames[s.routeMode][0]}. Сервер: ${n?.name||'не выбран'}.`:'Устройства выходят в интернет напрямую. Нажми «Включить VPN», чтобы применить свои правила.';
 $('power').textContent=active?'Выключить VPN':'Включить VPN';$('confirm').hidden=!active||state.confirmed;if(active&&!state.confirmed)$('vpnDetail').textContent='Проверь сайты и подтверди подключение в течение 10 минут. Иначе восстановится прежняя сеть.';
 $('activeServer').textContent=n?.name||'Добавь подписку';$('activeServerMeta').textContent=n?`${n.transport.toUpperCase()} · ${h?.ok?'HTTPS-запрос проходит':h?'Последняя проверка не прошла':'Проверка ожидается'}`:'Серверы появятся после загрузки подписки';$('selectionSummary').textContent=strategyNames[s.strategy];$('latency').textContent=h?.ok?h.ms+' мс':'Нет успешного ответа';$('routeSummary').textContent=routeNames[s.routeMode][0];$('routeDetail').textContent=routeNames[s.routeMode][1];$('selectedLists').textContent=Object.keys(s.lists||{}).length;$('dnsSummary').textContent=s.dnsMode==='manual'?'Свой DNS':'Автоматически';
 const mem=t.memory||{},available=(mem.available||0)/1024,total=(mem.total||0)/1024,used=total-available;$('memory').textContent=total?Math.round(used)+' / '+Math.round(total)+' МБ':'—';$('memoryBar').value=total?used/total*100:0;$('memoryDetail').textContent=`Доступно ${available.toFixed(1)} МБ · кеш ${(mem.cached/1024||0).toFixed(0)} МБ. Кеш освобождается по необходимости.`;
 $('cpu').textContent=t.cpu!=null?t.cpu+' %':'Измеряем…';$('cpuDetail').textContent='Загрузка между обновлениями панели';const sensor=t.sensors?.[0];$('temperature').textContent=sensor?sensor.celsius.toFixed(1)+' °C':'Нет датчика';$('temperatureDetail').textContent=sensor?'Реальное показание процессора':'Прошивка не предоставляет показания';const up=t.uptime||0;$('uptime').textContent='Без перезагрузки: '+Math.floor(up/3600)+' ч '+Math.floor(up%3600/60)+' мин';const results=Object.values(state.health?.results||{});$('healthy').textContent=results.filter(r=>r.ok).length+' / '+state.nodes.length;$('healthTime').textContent=state.health?.checked?'Проверено '+date(state.health.checked):'Проверки появятся после запуска ядра';
 $('subscriptionSummary').textContent=(s.hasSubscription?'Подключена: '+s.subscriptionHost:'Подписка не подключена')+' · '+state.nodes.length+' серверов · обновление: '+date(state.subscriptionUpdate?.checked);$('subscriptionUrl').placeholder=s.hasSubscription?'Вставь новую ссылку для замены':'https://…';$('cacheSummary').textContent=`На роутере сохранено ${cached.size} списков. `+(state.listError?'Последняя загрузка не удалась; используется сохранённая копия.':'Правила доступны без интернета.');
 $$('[data-cache]').forEach(el=>{const ok=cached.has(el.dataset.cache);el.textContent=ok?'Сохранён на роутере':'Загрузится при применении';el.className=ok?'cache-label':'missing-label'});
 const job=state.job.trim().replace(/^queued: /,''),name=actionNames[job]||'Системная операция',busy=state.busy||operation;$('lastJob').textContent=name+' · '+(state.busy?'выполняется…':state.exit!=null?(Number(state.exit)===0?'завершено':'не выполнено'):'ожидает запуска');$('jobError').hidden=!state.jobError;$('jobError').textContent=state.jobError;
 for(const id of ['power','restart','diagnose','refreshSub','saveServers','saveRules','saveSettings','preload','saveSubscriptionInterval','useServer','confirm'])$(id).disabled=busy;
 $('restart').disabled=busy||!active;$('power').disabled=busy||(!active&&!state.nodes.length);$$('button[type="submit"]').forEach(b=>b.disabled=busy);
 $('useServer').hidden=s.strategy!=='manual';$('quickServer').disabled=busy||s.strategy!=='manual';$('captureMode').disabled=active;
 $('healthy').textContent=state.nodes.filter(n=>state.health?.results?.[n.id]?.ok).length+' / '+state.nodes.length;
 const activeLists=new Set(Object.keys(s.lists||{}));if(s.routeMode==='whitelist'){activeLists.add(s.whiteProvider||'mobile_whitelist');if(s.whiteIps)activeLists.add('mobile_whitelist_ip')}$('selectedLists').textContent=activeLists.size;
 if(n)$('activeServerMeta').textContent=n.transport.toUpperCase()+' · '+(h?.ok?'Последний HTTPS-запрос прошёл':h?'Последняя проверка не прошла':'Проверка ожидается');
 if(state.busy){backgroundWasBusy=true;$('notice').hidden=false;$('notice').classList.remove('error');$('notice').textContent=(state.phase?.trim()||name)+'…';}else if(backgroundWasBusy){backgroundWasBusy=false;if(!operation)notify(Number(state.exit)===0?successMessages[job]||'Действие завершено.':state.jobError||'Не удалось завершить действие.',Number(state.exit)!==0);}
 renderHealth();renderDiagnostics();if(draft)updateFormVisibility();
}
async function readState(){
 const result=await api('status');if(!result||!Array.isArray(result.nodes))throw Error('Не удалось получить данные роутера. Обнови страницу LuCI.');
 const previous=state?.nodes.map(n=>n.id+'|'+n.name).join('\n');state=result;
 if(!draft)fill();else if(previous!==state.nodes.map(n=>n.id+'|'+n.name).join('\n')){
  const ids=state.nodes.map(n=>n.id);draft.order=(draft.order||[]).filter(id=>ids.includes(id));ids.forEach(id=>{if(!draft.order.includes(id))draft.order.push(id)});if(!ids.includes(draft.selected))draft.selected=state.settings.selected||ids[0];
  const selected=$('quickServer').value;$('quickServer').replaceChildren(...orderedNodes().map(n=>node('option',{value:n.id},n.name)));$('quickServer').value=ids.includes(selected)?selected:draft.selected;drawServers();
 }
 if(draft&&!dirtyServers){
  const changed=JSON.stringify(draft.order)!==JSON.stringify(state.settings.order);
  draft.selected=state.settings.selected;draft.strategy=state.settings.strategy;draft.order=state.settings.order||state.nodes.map(n=>n.id);draft.returnPrimary=state.settings.returnPrimary;
  setRadio('strategy',draft.strategy||'manual');$('returnPrimary').checked=draft.returnPrimary!==false;
  if(changed)drawServers();
  for(const pick of $$('input[name="chosenNode"]')){pick.checked=pick.value===draft.selected;pick.disabled=draft.strategy!=='manual'}
  $('quickServer').value=draft.selected;
 }
 render();return state;
}
async function poll(){if(polling)return;polling=true;try{await readState()}catch(e){notify(e.message,true)}finally{polling=false}}
async function run(method,payload,message){
 if(operation||state?.busy)return notify('Дождись завершения текущей операции.');operation=true;render();notify(message||'Применяем изменения. Это может занять до минуты…');
 try{const r=await api(method,payload);if(!r.ok)throw Error(r.error||'Роутер отклонил действие');const started=Date.now();for(;;){await new Promise(resolve=>setTimeout(resolve,Date.now()-started<3000?300:1500));await readState();if(!state.busy&&!state.job.startsWith('queued:')&&state.exit!=null)break;if(Date.now()-started>240000)throw Error('Операция ещё не завершилась. Её состояние видно в диагностике; не запускай повторно.');}
  if(Number(state.exit)!==0)throw Error(state.jobError||'Действие не выполнено. Предыдущие настройки сохранены.');fill();notify(method==='save'&&payload.subscription?'Новая подписка применена: '+state.nodes.length+' серверов.':successMessages[state.job.trim()]||'Готово. Изменения применены.');return true;
 }catch(e){notify(e.message,true);return false}finally{operation=false;render()}
}
$('power').onclick=()=>run('action',state.active?'disconnect':'connect',state.active?'Выключаем VPN. Интернет будет идти напрямую…':'Включаем VPN…');
$('confirm').onclick=()=>run('action','confirm','Сохраняем текущее подключение…');$('restart').onclick=()=>run('action','restart','Перезапускаем VPN. Соединения ненадолго прервутся…');
$('diagnose').onclick=()=>run('action','diagnose','Проверяем DNS, интернет, VPN и настройки. Подожди до минуты…');
$('subscriptionForm').onsubmit=async e=>{e.preventDefault();const url=$('subscriptionUrl').value.trim();if(!url.startsWith('https://'))return notify('Нужна полная ссылка подписки, начинающаяся с https://',true);if(await run('save',{subscription:url,_refresh:true,subscriptionInterval:$('subscriptionInterval').value},'Загружаем новую подписку и проверяем настройки. Прежняя работает до замены…'))$('subscriptionUrl').value=''};
$('refreshSub').onclick=()=>run('action','refresh','Загружаем обновление подписки…');$('saveSubscriptionInterval').onclick=()=>run('save',{subscriptionInterval:$('subscriptionInterval').value},'Сохраняем расписание обновления…');
$('linkForm').onsubmit=async e=>{e.preventDefault();if(await run('link',$('shareLink').value.trim(),'Добавляем сервер…'))$('shareLink').value=''};
$('saveServers').onclick=()=>run('save',{selected:draft.selected,strategy:radio('strategy'),returnPrimary:$('returnPrimary').checked,order:draft.order},'Применяем выбор сервера…');
$('useServer').onclick=()=>run('save',{selected:$('quickServer').value},'Подключаем выбранный сервер…');
function rulesPayload(){return {routeMode:radio('routeMode'),lists:draft.lists,customLists:draft.customLists||[],whiteProvider:$('whiteProvider').value,whiteIps:$('whiteIps').checked,listsInterval:$('listsInterval').value,direct:$('directRules').value.split('\n').map(x=>x.trim()).filter(Boolean),proxy:$('vpnRules').value.split('\n').map(x=>x.trim()).filter(Boolean)}}
$('saveRules').onclick=()=>run('save',rulesPayload(),'Загружаем недостающие списки, проверяем и применяем маршрутизацию…');
$('preload').onclick=()=>{if(dirtyRules)return notify('Сначала примени маршрутизацию: это также загрузит выбранные списки.');run('action','preload','Загружаем выбранные списки на роутер…')};
$('saveSettings').onclick=()=>run('save',{dnsMode:$('dnsMode').value,dnsDirect:$('dnsDirect').value.trim(),dnsVpn:$('dnsVpn').value.trim(),bootstrap:$('bootstrap').value.trim(),mode:$('captureMode').value},'Проверяем и применяем настройки подключения…');
if(window.parent===window){notify('Открой PupsPanel через «Службы» в LuCI: для управления нужна авторизация роутера.',true)}else{poll();setInterval(poll,8000)}
if(window.parent!==window){let lastHeight=0;new ResizeObserver(()=>{const height=Math.ceil(document.querySelector('.app').getBoundingClientRect().height)+16;if(Math.abs(height-lastHeight)>2){lastHeight=height;parent.postMessage({channel:'pupsinator-size',height},location.origin)}}).observe(document.querySelector('.app'));}

