'use strict';
const pingMethod=node('select',{'aria-label':'Тип проверки серверов'});
for(const [value,label] of [['tcp','TCP-пинг до узла'],['https','HTTPS через VPN']])pingMethod.append(node('option',{value},label));
const pingWrap=node('div');pingWrap.append(node('label',{},'Тип проверки'),pingMethod);probeRow.prepend(pingWrap);
settingsProbe.querySelector('p').textContent='TCP-пинг измеряет задержку до узла. У Hysteria2 проверяется TCP-порт другого сервера на том же адресе, если он есть в подписке; его номер указан в результате. Для проверки самого VPN, включая UDP, выбери HTTPS.';
const pingHint=node('small',{class:'subtle'});latencyPanel.querySelector('summary').after(pingHint);
const selectionPingHint=node('p',{class:'info'});$('serverList').before(selectionPingHint);
pingMethod.onchange=()=>probeDirty=true;
probeSave.onclick=async()=>{if(await run('save',{probeMethod:pingMethod.value,probeTarget:targetSelect.value,probeTimeout:timeoutSelect.value},'Сохраняем способ проверки…'))probeDirty=false};
const oldPingDetail=checkDetail;
checkDetail=function(h){
 if(h?.site==='udp')return 'UDP-транспорт: TCP-пинг неприменим. Выбери проверку HTTPS.';
 if(h?.site==='tcp'||h?.site==='tcp-peer')return 'TCP до узла'+(h.port?' · порт '+h.port:'')+(h.site==='tcp-peer'?' · общий адрес с TCP-сервером':'')+(h.checked?' · '+date(h.checked):'')+(h.ok?'':h.error==='6'?' · DNS не ответил':' · нет TCP-ответа');
 return oldPingDetail(h);
};
const beforePingModeRender=render;
render=function(){
 if(!state){beforePingModeRender();return}
 const tcp=state.settings.probeMethod==='tcp',actualHealth=state.health,displayHealth=tcp?(state.tcp||{}):actualHealth;
 if(tcp)state.health=displayHealth;
 try{beforePingModeRender()}finally{state.health=actualHealth}
 if(!probeDirty)pingMethod.value=tcp?'tcp':'https';targetSelect.disabled=tcp;
 pingHint.textContent=tcp?'TCP-пинг и автовыбор используют доступность TCP-порта. У Hysteria2 проверяется TCP-порт на том же адресе, не UDP-туннель.':'Пинг и автовыбор проверяют настоящий HTTPS через каждый VPN-туннель.';
 selectionPingHint.textContent=tcp?'Автовыбор: по TCP-пингу до узла. У Hysteria2 используется указанный TCP-порт на том же адресе.':'Автовыбор: по HTTPS-запросу через VPN. Тип проверки можно изменить в настройках.';
 const checking=state.busy&&state.job.trim().replace(/^queued:\s*/, '')==='check';
 const checkLabel=checking?'Измеряем…':tcp?'TCP-пинг всех':'Проверить HTTPS всех';
 for(const id of ['dashCheck','checkServers']){
  $(id).textContent=checkLabel;
  $(id).disabled=operation||state.busy||!state.nodes.length||(!tcp&&!state.running);
  $(id).title=!tcp&&!state.running?'Включи VPN для проверки HTTPS через туннели.':'';
 }
 const applicable=state.nodes.filter(n=>displayHealth?.results?.[n.id]?.applicable!==false);
 summaries.servers.textContent=applicable.filter(n=>displayHealth?.results?.[n.id]?.ok).length+' / '+applicable.length+(tcp?' TCP-ответов':' HTTPS-ответов');
 for(const row of $$('.server-row')){
  const h=displayHealth?.results?.[row.dataset.node];if(!h||!tcp)continue;
  const measure=row.querySelector('.measure');measure.textContent=h.site==='udp'?'UDP · выбери HTTPS':h.ok?'TCP'+(h.site==='tcp-peer'&&h.port?' '+h.port:'')+' · '+h.ms+' мс':'TCP нет ответа';measure.title=checkDetail(h);measure.classList.toggle('down',h.applicable!==false&&!h.ok);
 }
 const rows=$('latencyServers').children;
 for(let i=0;tcp&&i<state.nodes.length&&i<rows.length;i++){
  const h=displayHealth?.results?.[state.nodes[i].id];if(h?.site==='udp')rows[i].lastChild.textContent='UDP · HTTPS';
 }
 const n=activeNode(),h=displayHealth?.results?.[n?.id];
 if(n)$('activeServerMeta').textContent=n.transport.toUpperCase()+' · '+(tcp?(h?.ok?'TCP-порт отвечает':h?.applicable===false?'UDP: TCP неприменим':'TCP-проверка ожидается'):(h?.ok?'VPN-проверка прошла':h?'VPN-проверка не прошла':'VPN-проверка ожидается'));
};
$('dashCheck').onclick=$('checkServers').onclick=()=>run('action','check',state.settings.probeMethod==='tcp'?'Измеряем TCP-задержку до серверов…':'Проверяем HTTPS через VPN-туннели…');
