'use strict';
// Presentation only: list identifiers, source URLs and routing remain unchanged.
const primaryListOrder=['russia_inside','youtube','telegram','discord','meta','ai_all','ru_whitelist'];
const primaryListSet=new Set(primaryListOrder);
window.PUPS_LIST_SCOPE=list=>includeExtraLists||$('searchLists').value.trim()||!['all','chosen'].includes($('listFilter').value)||primaryListSet.has(list.id)||listAction(list.id)!=='off'||list.id.startsWith('user_');
window.PUPS_LIST_ORDER=(a,b)=>((primaryListOrder.indexOf(a.id)+1||999)-(primaryListOrder.indexOf(b.id)+1||999))||displayListName(a).localeCompare(displayListName(b),'ru');
const listPresentation={
 russia_inside:['Обход ограничений в России','Основной список заблокированных ресурсов','globe'],
 youtube:['YouTube','Видео, YouTube Music и связанные CDN','youtube'],
 telegram:['Telegram','Сообщения, звонки и загрузка медиа','telegram'],
 discord:['Discord','Чаты, голос и вложения','discord'],
 meta:['Instagram и Facebook','Meta, Threads и медиасерверы','social'],
 twitter:['X / Twitter','Лента, видео и изображения','social'],
 tiktok:['TikTok','Видео и связанные сервисы','video'],
 spotify:['Spotify','Музыка, подкасты и обложки','music'],
 ai_all:['Нейросети','ChatGPT, Claude, Gemini и другие','ai'],
 games_all:['Игровые сервисы','Steam, Epic, Riot, Battle.net и другие','games'],
 playstation:['PlayStation','PSN и сервисы PlayStation; не гарантия всех игр','games'],
 geoblock:['Сервисы с геоблокировкой','Сервисы, ограничившие доступ из России','globe'],
 ru_domains:['Рунет и СНГ','Целые зоны .ru, .рф, .su и домены компаний. Рекомендуется напрямую.','globe'],
 ru_whitelist:['Российские сервисы','Госуслуги, банки, медиа и Rutube. Рекомендуется напрямую.','globe'],
 ru_only_inside:['Сервисы только из России','Российские сайты, ограничивающие зарубежные IP. Рекомендуется напрямую.','globe'],
 mobile_whitelist:['Мобильный белый список','Домены, доступные при мобильных ограничениях','globe'],
 mobile_whitelist_ip:['Подсети мобильного белого списка','IP-диапазоны. Подключаются отдельно в белом режиме.','globe']
};
window.PUPS_LIST_SEARCH=list=>displayListName(list)+' '+displayListDescription(list);
window.PUPS_LIST_NAME=displayListName;
window.PUPS_LIST_DEFAULT=list=>['direct','mobile_whitelist'].includes(list.group)?'direct':list.group==='block'?'block':'proxy';
const listHeader=listsSection.querySelector('.section-title');
listHeader.classList.add('lists-heading');listHeader.querySelector('h1').textContent='Списки маршрутизации';listHeader.querySelector('p').textContent='Выбирай сайты и направляй их через VPN.';
const listMascot=node('img',{src:'assets/corgi-router-v3.png',alt:'',class:'lists-mascot'});listHeader.append(listMascot);
const listCards=node('div',{class:'list-stat-cards'});listHeader.after(listCards);
const statNodes={};let listIndexStatus='idle',listIndexMessage='',listAnalysisChecked=0,listIndexRun=0;
const listAnalysisBar=node('div',{class:'list-analysis-bar'});
const listAnalysisStatus=node('p',{class:'list-analysis-status',role:'status'});
const listAnalysisRetry=node('button',{type:'button',class:'compact'},'Повторить расчёт');
listAnalysisBar.append(listAnalysisStatus,listAnalysisRetry);listCards.after(listAnalysisBar);
listAnalysisRetry.onclick=async()=>{try{await buildListIndex(true);drawCatalog();}catch(_){}};
window.PUPS_LIST_PROGRESS=(id,loaded,total)=>{if(listIndexStatus!=='loading')return;listAnalysisStatus.hidden=false;listAnalysisStatus.textContent='Загружаем состав: '+listName(id)+(total?' · '+new Intl.NumberFormat('ru').format(loaded)+' / '+new Intl.NumberFormat('ru').format(total):'…');};
for(const [key,label,glyph] of [['active','Активных списков','lists'],['unique','Уникальных правил','globe'],['overlap','Повторы активных','swap'],['conflicts','Конфликтов','shield']]){const card=node('div',{class:'list-stat-card'}),text=node('div'),value=node('strong',{},'—');card.append(icon(glyph),text);text.append(node('small',{},label),value);statNodes[key]=value;listCards.append(card)}
listSummary.hidden=true;listCards.after(coverageBanner);
const routingArticle=listsSection.querySelector('article'),routeSettings=node('details',{class:'article list-route-settings'}),routeTitle=node('summary'),routeCaption=node('span'),routeSelect=node('select',{'aria-label':'Режим маршрутизации списков'});
routeTitle.append(icon('swap'),node('span',{},'Режим маршрутизации'),routeCaption);routeSettings.append(routeTitle,routingArticle);listsSection.append(routeSettings);routingArticle.classList.add('routing-settings-inner');
for(const [value,label] of [['selective','Только выбранные сайты'],['all','Весь интернет через VPN'],['whitelist','Белые списки провайдера']])routeSelect.append(node('option',{value},label));
routeSelect.onchange=()=>{setRadio('routeMode',routeSelect.value);if(routeSelect.value==='whitelist')routeSettings.open=true;dirtyRules=true;analysisSignature='';updateFormVisibility();drawCatalog()};
const modeStrip=node('div',{class:'list-mode-strip'});modeStrip.append(node('span',{},'Куда идёт интернет'),routeSelect);listCards.after(modeStrip);
const modeHelp=node('p',{class:'list-mode-help',id:'list-mode-help'});
routeSelect.setAttribute('aria-describedby',modeHelp.id);modeStrip.after(modeHelp);
const modeHelpText={
 selective:'Обычные устройства идут через VPN по правилам списков, остальные сайты открывают напрямую.',
 all:'Обычные устройства идут через VPN по умолчанию. Прямые исключения и блокировки действуют.',
 whitelist:'Для обычных устройств сайты из белого списка открываются напрямую, остальные идут через VPN по умолчанию.'
};
const explainBox=node('details',{class:'article list-route-explain'});
const explainForm=node('form',{class:'list-route-query'});
const explainHost=node('input',{type:'text',required:'',maxlength:'253',placeholder:'youtube.com',autocomplete:'off'});
const explainDevice=node('select',{'aria-label':'Устройство для проверки'});
const explainButton=node('button',{type:'submit'},'Проверить маршрут');
const explainResult=node('p',{class:'subtle',role:'status'});
const explainLabel=node('label');explainLabel.append(node('span',{},'Сайт'),explainHost);
explainForm.append(explainLabel,explainDevice,explainButton);
explainBox.append(node('summary',{},'Как пойдёт трафик на сайт'),explainForm,explainResult);
modeHelp.after(explainBox);
function refreshExplainDevices(){
 const choice=explainDevice.value;
 const devices=state?.settings.devices||[],favorites=state?.settings.favorites||[];
 const options=new Map(devices.map(d=>[d.mac,d.name||d.ip||d.mac]));
 for(const d of favorites)if(!options.has(d.mac))options.set(d.mac,d.label||d.mac);
 explainDevice.replaceChildren(node('option',{value:''},'Обычное устройство'));
 for(const [value,name] of options)explainDevice.append(node('option',{value},name));
 explainDevice.value=options.has(choice)?choice:'';
}
explainBox.ontoggle=()=>{if(explainBox.open)refreshExplainDevices();};
explainForm.onsubmit=async event=>{
 event.preventDefault();
 let host;
 try{
  const input=explainHost.value.trim();
  if(!input)throw Error();
  const url=new URL(input.includes('://')?input:'https://'+input);
  host=url.hostname.toLowerCase().replace(/\.$/,'');
  if(!['http:','https:'].includes(url.protocol)||url.username||url.password||!host.includes('.')||PupsCoverage.ip(host)||!/^([a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9-]+$/.test(host))throw Error();
 }catch(_){explainResult.textContent='Укажи домен сайта, например youtube.com.';return;}
 const signature=JSON.stringify(listContext());
 const mac=explainDevice.value;
 const device=state.settings.favorites?.find(d=>d.mac===mac);
 if(device?.route==='direct'){
  explainResult.textContent='Напрямую · выбран внешний IPv4-маршрут устройства';
  return;
 }
 const favorite=device?.route==='proxy'||(!device?.route&&!!device?.enabled);
 explainResult.textContent='Проверяем доменные правила…';
 explainButton.disabled=true;
 try{
  await buildListIndex();
  if(signature!==JSON.stringify(listContext())||mac!==explainDevice.value){
   explainResult.textContent='Настройки изменились. Проверь маршрут ещё раз.';return;
  }
  const result=explainDomainRoute(host,favorite,listContext().mode,analysisIndex,analysisComplete,state.settings.mode);
  const labels={proxy:'Через VPN',direct:'Напрямую',block:'Блокируется'};
  explainResult.textContent=(result.action?labels[result.action]+' · '+result.reason:result.reason)+
   ' Проверка по домену и черновику настроек. Фактический маршрут может зависеть от IP-адреса и условий соединения.';
 }catch(e){explainResult.textContent='Не удалось проверить маршрут. '+e.message;}
 finally{explainButton.disabled=false;}
};
function explainDomainRoute(host,favorite,mode,index,complete,capture='tproxy'){
 if(!complete||!index)return {reason:'Часть списков ещё недоступна, итоговый маршрут неизвестен.'};
 const manual=['manual-direct','manual-proxy'];
 const sourceOrder=[...(!favorite?manual:[]),...['block','direct','proxy'].flatMap(action=>{
  if(favorite&&action!=='block')return [];
  return index.sources.filter(source=>!source.manual&&source.action===action).map(source=>source.id);
 })];
 const byId=new Map(index.sources.map(source=>[source.id,source])),matching=new Map(),unknown=new Set();
 const inbound=favorite?'full-device':capture==='tun'?'tun-in':'tproxy';
 const scopes=new Map();
 for(const scope of index.scopes){
  let conditions;
  try{conditions=JSON.parse(scope);}catch(_){conditions=null;}
  if(Array.isArray(conditions?.inboundTag)&&!conditions.inboundTag.includes(inbound))continue;
  const simple=!!conditions&&Object.keys(conditions).every(key=>key==='inboundTag');
  scopes.set(scope,simple);
  const query=PupsCoverage.normalize({kind:'domain',value:'full:'+host,scope});
  for(const rule of index.matches(query)){
   if(!simple)unknown.add(rule.source);
   else if(!matching.has(rule.source))matching.set(rule.source,rule);
  }
 }
 for(const rule of index.opaque)if(rule.type!=='keyword'&&scopes.has(rule.scope))unknown.add(rule.source);
 for(const id of sourceOrder){
  const source=byId.get(id);
  if(!source)continue;
  const rule=matching.get(id);
  if(rule)return {action:source.action,reason:source.name+' ('+rule.value+')'};
  if(unknown.has(id))return {reason:'В списке «'+source.name+'» есть правило, для которого одного домена недостаточно.'};
 }
 return {action:favorite||mode!=='selective'?'proxy':'direct',reason:favorite?'Правило устройства «Всегда VPN»':'Маршрут по умолчанию для выбранного режима'};
}
const catalogArticle=$('catalog').closest('article');catalogArticle.classList.add('list-catalog-card');catalogArticle.querySelector('.card-title').hidden=true;catalogArticle.querySelector('.list-legend').hidden=true;
const toolbar=node('div',{class:'list-toolbar'}),filters=catalogArticle.querySelector('.filters');toolbar.append(listTabs,filters);catalogArticle.prepend(toolbar);
const extras=node('button',{type:'button',class:'list-extra-toggle','aria-pressed':'false'},'Дополнительные списки'),catalogHelp=node('p',{class:'list-catalog-help'});catalogArticle.querySelector('#catalog').before(catalogHelp);
filters.append(extras);let includeExtraLists=false;
extras.onclick=()=>{includeExtraLists=!includeExtraLists;extras.setAttribute('aria-pressed',String(includeExtraLists));listPage=0;drawCatalog()};
const mobileListFilter=node('select',{'aria-label':'Набор списков'});for(const [value,label] of [['all','Основные списки'],['chosen','Активные'],['overlap','С пересечениями'],['custom','Пользовательские']])mobileListFilter.append(node('option',{value},label));mobileListFilter.onchange=()=>{listTabFilter=mobileListFilter.value;listPage=0;drawCatalog()};toolbar.prepend(mobileListFilter);
function displayListName(list){return listPresentation[list.id]?.[0]||title(list)}
function displayListDescription(list){
 const specific=listPresentation[list.id]?.[1]||list.description?.replace(/^\[[^\]]+\]\s*/, '');
 return specific||groupNames[list.group]||'Свой обновляемый источник';
}
function updateCoverageBadge(badge,result){
 const id=badge.dataset.coverage,action=listAction(id);
 const redundant=result?.disableWith?.length&&!managedList(id);
 badge.dataset.status=result?.conflicts&&action!=='off'?'conflict':redundant?'redundant':result?.covered||result?.conflicts?'partial':action!=='off'?'active':'new';
 badge.textContent=result?.conflicts?(action==='off'?'При включении: разные маршруты · ':'Разные маршруты · ')+result.conflicts:
  redundant?'Можно отключить':result?.full?'Уже покрыт':result?.covered?'Повторы · '+result.covered+' из '+result.total:
  result?.available?'Состав':'Проверить состав';
 const names=redundant?result.disableWith:result?.sources||[];
 if(names.length){
  badge.setAttribute('aria-label',badge.textContent+' · '+names.join(', '));
  badge.append(node('small',{class:'list-overlap-source'},names[0]+(names.length>1?' +'+(names.length-1):'')));
 }
 else badge.removeAttribute('aria-label');
}
function stageListRoute(id,action){
 if(operation||state?.busy||managedList(id))return;
 if(listAction(id)===action)delete draft.lists[id];
 else draft.lists[id]=action;
 dirtyRules=true;analysisSignature='';listAnalysis.clear();
 updateFormVisibility();drawCatalog();
 const updated=[...$('catalog').children].find(row=>row.dataset.list===id);
 updated?.querySelector('[data-list-route="'+action+'"]')?.focus();
}
function listVisual(id){const type=listPresentation[id]?.[2]||'lists',box=node('span',{class:'list-service-icon '+type,'aria-hidden':'true'});if(type==='youtube')box.append(node('span',{},'▶'));else if(type==='telegram')box.append(node('span',{},'➤'));else if(type==='discord')box.append(node('span',{},'◉'));else box.append(icon({social:'devices',video:'bars',music:'bars',ai:'chip',games:'devices',globe:'globe'}[type]||'lists'));return box}
function listRuleCount(list){const data=listData.get(list.id);if(data?.available)return {value:new Intl.NumberFormat('ru').format(data.items.length),label:'правил',known:true};const count=Object.values(list.counts||{}).reduce((n,value)=>n+Number(value||0),0);return count?{value:'≈ '+new Intl.NumberFormat('ru').format(count),label:'в каталоге',known:true}:{value:'—',label:'не загружен',known:false}}
function refreshListCount(id){const list=listMetadata().find(l=>l.id===id),row=[...$('catalog').children].find(el=>el.dataset.list===id),box=row?.querySelector('.list-rule-count');if(!list||!box)return;const count=listRuleCount(list);box.querySelector('strong').textContent=count.value;box.querySelector('small').textContent=count.label;}
const beforeLayoutLoad=loadList;loadList=async function(id,...args){const result=await beforeLayoutLoad(id,...args);refreshListCount(id);return result;};
function renderListStats(){
 if(!draft||!state)return;
 const selected=Object.keys(listContext().choices);statNodes.active.textContent=selected.length;
 const values=[...listSummary.children].map(el=>el.textContent.split(': ').slice(1).join(': '));
 const ready=listIndexStatus==='ready'&&analysisSignature===JSON.stringify(listContext());
 const loading=listIndexStatus==='loading';
 for(const [key,index] of [['unique',1],['overlap',2],['conflicts',3]]){
  const value=ready?values[index]:'',valid=/^\d+$/.test(value||'');
  statNodes[key].textContent=valid?new Intl.NumberFormat('ru').format(Number(value)):loading?'Считаем':listIndexStatus==='idle'?'Ожидаем':'Нет данных';
  statNodes[key].classList.toggle('stat-pending',!valid);
  statNodes[key].title=value||'Расчёт не завершён';
 }
 listsSection.classList.toggle('has-list-conflicts',ready&&Number(values[3])>0);
 const partial=ready&&(!analysisComplete||values.slice(1).some(value=>!/^\d+$/.test(value)));
 listAnalysisRetry.hidden=listIndexStatus!=='error'&&!partial;
 listAnalysisRetry.disabled=loading||!!operation||!!state.busy;
 if(loading)listAnalysisStatus.textContent='Считаем правила выбранных списков…';
 else if(listIndexStatus==='error')listAnalysisStatus.textContent='Не удалось посчитать правила. '+listIndexMessage;
 else if(partial)listAnalysisStatus.textContent=missingAnalysisSources.length?
  'Состав недоступен: '+missingAnalysisSources.slice(0,3).join(', ')+(missingAnalysisSources.length>3?' и ещё '+(missingAnalysisSources.length-3):'')+'. Показаны найденные пересечения.':
  'Показаны найденные пересечения. Некоторые условия нельзя сравнить полностью.';
 else if(ready&&listAnalysisChecked)listAnalysisStatus.textContent='Последний расчёт: '+new Date(listAnalysisChecked).toLocaleTimeString('ru',{hour:'2-digit',minute:'2-digit'});
 else listAnalysisStatus.textContent='Ожидаем расчёт выбранных списков.';
 routeSelect.value=radio('routeMode');routeCaption.textContent=routeSelect.selectedOptions[0]?.textContent||'';
 modeHelp.textContent=(modeHelpText[routeSelect.value]||'')+' Избранные устройства с отдельным маршрутом используют свой режим.';
 mobileListFilter.value=listTabFilter;
 const all=listMetadata(),active=all.filter(l=>listAction(l.id)!=='off').length,custom=all.filter(l=>l.id.startsWith('user_')).length,overlap=all.filter(l=>(listAnalysis.get(l.id)?.covered||listAnalysis.get(l.id)?.conflicts)).length;
 for(const button of listTabs.children){const key=button.dataset.listTab,count={all:includeExtraLists?all.length:all.filter(l=>primaryListSet.has(l.id)||listAction(l.id)!=='off'||l.id.startsWith('user_')).length,chosen:active,custom,overlap}[key];button.replaceChildren(document.createTextNode(({all:includeExtraLists?'Все списки':'Основные',chosen:'Активные',custom:'Пользовательские',overlap:'С пересечениями'}[key])+' '),node('b',{class:'list-tab-count'},count));}
 const extraCount=all.filter(l=>!primaryListSet.has(l.id)).length;extras.textContent=includeExtraLists?'Скрыть дополнительные':'Дополнительные · '+extraCount;
 catalogHelp.textContent=includeExtraLists?'Уточни категорию или найди список по названию.':'Нажми маршрут, чтобы выбрать его. Повторное нажатие выключает список.';
}
const beforeLayoutCatalog=drawCatalog;
drawCatalog=function(){
 if(!draft)return;beforeLayoutCatalog();renderListStats();
 for(const row of $('catalog').children){
  const id=row.querySelector('input[role=switch]')?.dataset.listId,list=listMetadata().find(l=>l.id===id);if(!list)continue;
  row.dataset.list=id;row.classList.toggle('list-is-active',listAction(id)!=='off');
  const info=row.children[1],name=info.querySelector('.list-name');name.textContent=displayListName(list);info.querySelector('small').textContent=displayListDescription(list);
  const oldGlyph=row.querySelector('.list-glyph');if(oldGlyph)oldGlyph.replaceWith(listVisual(id));
  const count=listRuleCount(list),countBox=node('div',{class:'list-rule-count'});countBox.append(node('strong',{},count.value),node('small',{},count.label));row.insertBefore(countBox,row.querySelector('.coverage-label'));
  if(id==='russia_inside')name.after(node('span',{class:'list-primary-label'},'Основной'));
  const action=listAction(id),badge=row.querySelector('.coverage-label');updateCoverageBadge(badge,listAnalysis.get(id));
  if(id==='ru_domains'&&action==='proxy')info.querySelector('small').textContent='Зоны .ru, .рф и .su сейчас идут через VPN. Для Rutube выбери прямой маршрут или своё исключение.';
  const toggle=row.querySelector('.toggle-target'),details=row.lastElementChild;details.hidden=true;toggle.hidden=true;
  const routes=node('div',{class:'list-route-buttons',role:'group','aria-label':'Маршрут списка '+displayListName(list)});
  if(managedList(id))routes.append(node('span',{},action==='direct'?'Напрямую · белый режим':'Выключен · белый режим'));
  else for(const [key,label] of [['proxy','VPN'],['direct','Прямо'],['block','Блок']]){
   const button=node('button',{type:'button','data-list-route':key,'aria-pressed':String(action===key)},label);
   button.disabled=!!operation||!!state?.busy;button.onclick=()=>stageListRoute(id,key);routes.append(button);
  }
  row.append(routes);
  row.onclick=e=>{if(e.target.closest('button,input,label'))return;openListDrawer(id)};
 }
};
window.PUPS_LIST_COVERAGE=updateCoverageBadge;
const beforeLayoutIndex=buildListIndex;
buildListIndex=async function(...args){
 if(!args[0]&&analysisIndex&&analysisSignature===JSON.stringify(listContext()))return beforeLayoutIndex(...args);
 const run=++listIndexRun,previousSignature=analysisSignature;
 listIndexStatus='loading';renderListStats();
 try{
  await beforeLayoutIndex(...args);
  if(run===listIndexRun){
   listIndexStatus='ready';
   if(args[0]||analysisSignature!==previousSignature||!listAnalysisChecked)listAnalysisChecked=Date.now();
  }
 }catch(e){
  if(run===listIndexRun){listIndexStatus='error';listIndexMessage=e.message;}
  throw e;
 }finally{if(run===listIndexRun)renderListStats();}
};
const beforeLayoutVisibility=updateFormVisibility;updateFormVisibility=function(){beforeLayoutVisibility();if(draft)renderListStats()};
// Expose the existing catalog choices to the filter without changing sources.
const advancedDetails=node('details',{class:'article list-storage-settings'});advancedDetails.append(node('summary',{},'Обновление списков и работа без сети'));const storageArticle=$('preload').closest('article');storageArticle.before(advancedDetails);advancedDetails.append(storageArticle);
// Keep the save bar adjacent to the catalog, above unrelated settings.
catalogArticle.after(listDraftBar);listsSection.querySelector('.savebar').hidden=true;
const chosenDetails=node('details',{class:'article list-chosen-settings'});chosenDetails.append(node('summary',{},'Выбранные источники'),$('chosenLists'));listDraftBar.after(chosenDetails);
const customDetails=catalogArticle.querySelector('details');if(customDetails)chosenDetails.after(customDetails);
if(state){drawCatalog();renderListStats()}
