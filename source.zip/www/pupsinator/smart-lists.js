'use strict';
const listData=new Map(),listAnalysis=new Map();let missingAnalysisSources=[];let listPage=0,listGeneration='',analysisSignature='',analysisIndex=null,analysisComplete=false,analysisJob=null,analysisEpoch=0,listTabFilter='all';
const listCacheLimit=250000;let analysisQueued=false;
const listsSection=$('rules'),listSummary=node('div',{class:'list-summary'}),coverageBanner=node('div',{class:'coverage-banner',role:'status'}),listTabs=node('div',{class:'list-tabs'}),listPager=node('div',{class:'list-pager'}),listDraftBar=node('div',{class:'list-draft-status'});
coverageBanner.hidden=true;listsSection.querySelector('h1').after(listSummary,coverageBanner,listTabs);$('catalog').after(listPager,listDraftBar);
for(const [key,label] of [['all','Все списки'],['chosen','Активные'],['overlap','С пересечениями'],['custom','Свои']]){const b=node('button',{type:'button'},label);b.onclick=()=>{listTabFilter=key;listPage=0;drawCatalog()};b.dataset.listTab=key;listTabs.append(b)}
const drawer=node('dialog',{class:'list-drawer','aria-label':'Состав и пересечения списка'});document.body.append(drawer);let drawerPage=0,drawerFilter='all',drawerList=null,drawerSearch='',drawerRender=0;
function closeListDrawer(){drawer.close();drawerList=null;drawerRender++}
function listMetadata(){const rows=[...catalog];for(const l of draft?.customLists||[])if(!rows.some(x=>x.id===l.id))rows.push({...l,title:l.name,description:'Свой обновляемый источник',group:'custom'});return rows;}
function listName(id){const m=listMetadata().find(x=>x.id===id);return m?(window.PUPS_LIST_NAME?.(m)||title(m)):id}
function listContext(){const choices={};for(const l of listMetadata()){const action=listAction(l.id);if(action!=='off')choices[l.id]=action}return {choices,custom: (draft.customLists||[]).map(l=>({id:l.id,url:l.url,format:l.format})),mode:radio('routeMode'),capture:state?.settings.mode,dns:state?.settings.dnsMode,white:$('whiteProvider').value,whiteIps:$('whiteIps').checked,direct:$('directRules').value,proxy:$('vpnRules').value,generation:listGeneration};}
const listLoads=new Map();
function loadList(id,revalidate=false,retries=0){
 const key=analysisEpoch+'|'+id+'|'+revalidate+'|'+retries;
 if(listLoads.has(key))return listLoads.get(key);
 const job=loadListUnshared(id,revalidate,retries).finally(()=>{if(listLoads.get(key)===job)listLoads.delete(key)});listLoads.set(key,job);return job;
}
async function loadListUnshared(id,revalidate=false,retries=0){
 if(id.startsWith('user_')){const next=(draft.customLists||[]).find(l=>l.id===id),old=(state.settings.customLists||[]).find(l=>l.id===id);if(!next||!old||next.url!==old.url||next.format!==old.format){listData.delete(id);return {available:false,reason:'Новый источник будет загружен после применения. Старый состав не используется для анализа.'}}}
 const epoch=analysisEpoch,old=listData.get(id);if(old&&!revalidate)return old;
 let items=[],cursor=0,version='';const started=Date.now();window.PUPS_LIST_PROGRESS?.(id,0,null);
 for(let page=0;page<512;page++){
  if(Date.now()-started>30000)throw Error('Анализ не завершён за 30 секунд. Попробуй открыть список позже.');
  const part=await api('rules',{id,cursor,version:old?.version&&revalidate&&cursor===0?old.version:version});
  if(epoch!==analysisEpoch)throw Error('Списки обновились во время анализа. Открой сведения ещё раз.');
  if(part.stale){listData.delete(id);if(retries>=2)throw Error('Источник продолжает обновляться. Анализ пока недоступен.');return loadList(id,false,retries+1)}
  if(!part.available){const result={available:false,reason:part.reason||'Состав пока неизвестен'};listData.set(id,result);return result}
  if(old&&part.version===old.version&&revalidate)return old;
  if(!Array.isArray(part.items)||!part.version)throw Error('Некорректная страница правил');
  version=part.version;items.push(...part.items);window.PUPS_LIST_PROGRESS?.(id,items.length,part.total);
  let stored=[...listData].reduce((n,[key,value])=>n+(key===id?0:value.items?.length||0),0);
  if(stored+items.length>listCacheLimit){const active=new Set(Object.keys(listContext().choices));for(const [key,value] of listData){if(key!==id&&!active.has(key)&&key!==drawerList){stored-=value.items?.length||0;listData.delete(key);listAnalysis.delete(key);if(stored+items.length<=listCacheLimit)break;}}}
  if(stored+items.length>listCacheLimit)return {available:false,reason:'Достигнут безопасный объём анализа. Уменьши число одновременно выбранных больших источников.'};
  if(items.length>200000){const result={available:false,reason:'Слишком большой список для безопасного анализа'};listData.set(id,result);return result}
  if(part.next===null){const result={available:true,version,items};listData.set(id,result);return result}
  if(!Number.isInteger(part.next)||part.next<=cursor)throw Error('Некорректная страница правил');cursor=part.next;
 }
 throw Error('Слишком много страниц правил');
}
let indexBuild=null,indexBuildKey='';
function buildListIndex(revalidate=false){
 const key=JSON.stringify(listContext())+'|'+revalidate;
 if(indexBuild&&indexBuildKey===key)return indexBuild;
 const job=buildListIndexUnshared(revalidate).finally(()=>{if(indexBuild===job)indexBuild=null});indexBuildKey=key;indexBuild=job;return job;
}
async function buildListIndexUnshared(revalidate=false){const context=listContext(),signature=JSON.stringify(context);if(signature===analysisSignature&&analysisIndex&&!revalidate)return;const sources=[];let complete=true;for(const [id,action] of Object.entries(context.choices)){let data;try{data=await loadList(id,revalidate);}catch(e){if(revalidate)throw e;complete=false;continue;}if(data.available)sources.push({id,name:listName(id),action,items:data.items});else complete=false;}
 for(const [field,action] of [['direct','direct'],['proxy','proxy']]){const values=context[field].split('\n').map(x=>x.trim()).filter(Boolean);if(values.length)sources.push({id:'manual-'+field,name:'Свои правила',action,manual:true,items:values.map(v=>({kind:v.includes('/')?'ip':'domain',value:v.includes('/')?v:'domain:'+v,scope:JSON.stringify({inboundTag:[context.capture==='tun'?'tun-in':'tproxy']})}))});}
 if(JSON.stringify(listContext())!==signature)return buildListIndex();
 analysisIndex=new PupsCoverage.Index(sources);analysisComplete=complete;analysisSignature=signature;listAnalysis.clear();
 missingAnalysisSources=Object.keys(context.choices).filter(id=>!sources.some(source=>source.id===id)).map(listName);
 const stats=PupsCoverage.activeStats(sources,analysisIndex);
 for(const [id,result] of Object.entries(stats.bySource))listAnalysis.set(id,{available:true,...result,incomplete:!complete});
 for(const badge of $('catalog').querySelectorAll('[data-coverage]'))window.PUPS_LIST_COVERAGE?.(badge,listAnalysis.get(badge.dataset.coverage));
 listSummary.replaceChildren(node('div',{},'Активных списков: '+Object.keys(context.choices).length),node('div',{},'Уникальных правил: '+(complete?stats.unique:'не всё загружено')),node('div',{},'Повторов в активных: '+(complete&&!stats.incomplete?stats.overlap:'анализ ограничен')),node('div',{},'Конфликтов: '+(complete&&!stats.incomplete?stats.conflicts:'анализ ограничен')));
}
async function analyzeList(id,action='proxy',revalidate=false){await buildListIndex(revalidate);const data=await loadList(id,revalidate);if(!data.available)return {available:false,reason:data.reason};let result=analysisIndex.analyze(data.items,action,id);if(radio('routeMode')!=='selective'&&action==='proxy'&&analysisComplete){const rows=result.rows.map(r=>r.conflict||r.unknown?r:{...r,covered:true,sources:r.sources.length?r.sources:[{id:'mode',name:'VPN по умолчанию',action:'proxy'}]});result={...result,covered:rows.filter(r=>r.covered&&!r.conflict).length,newRules:rows.filter(r=>!r.covered&&!r.conflict&&!r.unknown).length,inherent:true,rows};result.full=result.total>0&&result.covered===result.total&&!result.conflicts&&!result.unknown;}if(!analysisComplete){result.full=false;result.incomplete=true;}return {available:true,...result};}
function coverageText(r){if(!r)return 'Анализ ещё не выполнен';if(!r.available)return 'Состав неизвестен';if(r.incomplete)return 'Не все источники загружены';if(r.full)return 'Уже покрыт полностью';if(r.conflicts)return 'Конфликты: '+r.conflicts;if(r.covered)return 'Частично: '+r.covered+'/'+r.total;return r.unknown?'Часть правил не проверена':r.total+' новых правил'}
function bannerFor(id,r){coverageBanner.hidden=false;coverageBanner.dataset.status=r.conflicts?'conflict':r.full?'covered':'unknown';coverageBanner.replaceChildren(node('strong',{},listName(id)+(r.full?' уже покрыт':r.conflicts?' — пересечения маршрутов':' — состав списка')),node('p',{},r.full?`${r.covered} из ${r.total} правил уже действуют. Дополнительно включать список не нужно.`:coverageText(r)));const view=node('button',{},'Посмотреть совпадения'),close=node('button',{},'Понятно');view.onclick=()=>openListDrawer(id);close.onclick=()=>coverageBanner.hidden=true;coverageBanner.append(view,close);}
function confirmList(text){return new Promise(resolve=>{const d=node('dialog',{class:'list-confirm','aria-label':'Подтверждение изменения списка'}),yes=node('button',{class:'primary'},'Добавить список'),no=node('button',{},'Отмена');d.append(node('h2',{},'Проверим изменения'),node('p',{},text),yes,no);document.body.append(d);let settled=false;function finish(value){if(settled)return;settled=true;d.close();d.remove();resolve(value)}yes.onclick=()=>finish(true);no.onclick=()=>finish(false);d.oncancel=e=>{e.preventDefault();finish(false)};d.showModal();});}
async function selectList(id,action){try{const snapshot=JSON.stringify(listContext());const r=await analyzeList(id,action,true);if(snapshot!==JSON.stringify(listContext()))throw Error('Выбор изменился во время анализа. Повтори действие.');listAnalysis.set(id,r);if(r.full){bannerFor(id,r);openListDrawer(id);return false}if(r.covered||r.conflicts||r.unknown||!r.available||r.incomplete){const text=r.available?`${r.covered}/${r.total} уже покрыты; новых: ${r.newRules}; конфликтов: ${r.conflicts}; непроверенных: ${r.unknown}. Будет добавлен весь исходный список. До «Применить» маршрутизация не меняется.`:(r.reason||'Полный анализ недоступен')+'. Список будет загружен и проверен при применении. Продолжить?';if(!await confirmList(text))return false;}if(snapshot!==JSON.stringify(listContext()))throw Error('Черновик изменился. Проверь выбор и повтори действие.');draft.lists[id]=action;dirtyRules=true;analysisSignature='';updateFormVisibility();drawCatalog();return true;}catch(e){notify(e.message,true);return false}}
function openListDrawer(id){drawerList=id;drawerPage=0;drawerFilter='all';drawerSearch='';renderListDrawer();if(!drawer.open)drawer.showModal();}
async function renderListDrawer(){
 if(!drawerList)return;const id=drawerList,request=++drawerRender;drawer.replaceChildren(node('h2',{},listName(id)));
 const close=node('button',{'aria-label':'Закрыть сведения',class:'drawer-close'},'×');close.onclick=closeListDrawer;drawer.append(close,node('p',{},'Загружаем состав…'));
 try{
  const active=listAction(id),action=active==='off'?(window.PUPS_LIST_DEFAULT?.(listMetadata().find(list=>list.id===id))||'proxy'):active;
  const signature=JSON.stringify(listContext()),r=await analyzeList(id,action);
  if(drawerList!==id||request!==drawerRender)return;
  if(signature!==JSON.stringify(listContext())){renderListDrawer();return;}
  const summary=listAnalysis.get(id);
  drawer.lastChild.remove();
  if(!r.available){drawer.append(node('p',{},r.reason));return}
  const data=listData.get(id);if(data?.version)drawer.append(node('small',{},'Версия источника: '+data.version.slice(0,12)));
  const shared=r.rows.filter(rule=>rule.shared&&!rule.conflict).length;
  const sourceNames=[...new Set(r.rows.flatMap(rule=>rule.sources.filter(source=>source.id!=='mode').map(source=>source.name)))];
  drawer.append(node('p',{},`Повторы: ${shared} из ${r.total} · Разные маршруты: ${r.conflicts}`));
  if(sourceNames.length)drawer.append(node('p',{},'Совпадения с: '+sourceNames.join(', ')+'.'));
  const covering=summary?.disableWith||[];
  if(covering.length&&active!=='off'&&!managedList(id)){
   drawer.append(node('p',{},'Можно отключить: все правила с тем же маршрутом покрывают '+covering.join(', ')+'.'));
   const remove=node('button',{type:'button',class:'compact'},'Отключить в черновике');
   remove.onclick=()=>{if(signature!==JSON.stringify(listContext())){renderListDrawer();return;}if(operation||state?.busy||managedList(id))return;closeListDrawer();stageListRoute(id,active);};
   drawer.append(remove);
  }else if(active!=='off'&&shared)drawer.append(node('p',{},shared<r.total?`У ${r.total-shared} правил нет подтверждённого повтора с тем же маршрутом. Отключение может изменить маршруты.`:'Полное покрытие другими списками не подтверждено.'));
  if(r.incomplete||r.unknown)drawer.append(node('small',{},missingAnalysisSources.length?'Не удалось проверить состав: '+missingAnalysisSources.join(', ')+'.':'Часть правил нельзя точно сравнить по домену или подсети.'));
  const why=node('details'),whyTitle=node('summary',{},'Почему считается покрытым?');why.append(whyTitle,node('p',{},'Сравниваем точный домен, суффикс или IP-подсеть, маршрут и условия. Конфликт с прямым исключением или неизвестное условие не считается доказанным покрытием. Считаются правила, а не все возможные поддомены. При нескольких маршрутах их фактический приоритет определяет ядро; анализ не меняет этот порядок.'));drawer.append(why);
  const search=node('input',{type:'search','aria-label':'Поиск внутри списка',placeholder:'Найти домен, IP или источник'});search.value=drawerSearch;drawer.append(search);
  const tabs=node('div',{class:'list-tabs'}),content=node('div'),pager=node('div',{class:'list-pager'});drawer.append(tabs,content,pager);
  function displayRows(){
   const q=drawerSearch.trim().toLocaleLowerCase('ru'),rows=r.rows.filter(v=>(drawerFilter==='all'?true:drawerFilter==='new'?!v.shared&&!v.conflict&&!v.unknown:drawerFilter==='covered'?v.shared&&!v.conflict:v[drawerFilter])&&(!q||(v.value+' '+v.sources.map(s=>s.name).join(' ')).toLocaleLowerCase('ru').includes(q)));
   const start=drawerPage*20;content.replaceChildren();pager.replaceChildren();
   for(const item of rows.slice(start,start+20)){
    const row=node('div',{class:'coverage-rule'});row.dataset.status=item.conflict?'conflict':item.shared?'covered':item.unknown?'unknown':'new';
    const kind={full:'точный домен',domain:'домен и поддомены',ip:'IP / подсеть',regexp:'регулярное выражение',keyword:'ключевое слово',opaque:'составное правило'}[item.kind]||'правило';
    row.append(node('span',{},item.conflict?'!':item.shared?'✓':item.unknown?'?':'+'),node('code',{},item.value),node('small',{},kind+(item.scope&&item.scope!=='{}'?' · условия: '+item.scope:'')),node('small',{},item.sources.map(s=>s.name+' · '+({proxy:'VPN',direct:'напрямую',block:'блокировка'}[s.action])).join(', ')||'Совпадения не найдены'));content.append(row);
   }
   if(!rows.length)content.append(node('p',{},'По этому фильтру правил нет.'));
   const previous=node('button',{},'← Назад'),next=node('button',{},'Далее →');previous.disabled=drawerPage===0;next.disabled=start+20>=rows.length;previous.onclick=()=>{drawerPage--;displayRows()};next.onclick=()=>{drawerPage++;displayRows()};pager.append(previous,node('span',{},`${rows.length?start+1:0}–${Math.min(start+20,rows.length)} из ${rows.length}`),next);
  }
  for(const [value,text] of [['all','Все'],['covered','Повторы'],['new','Без совпадений'],['conflict','Разные маршруты'],['unknown','Непроверенные']]){const b=node('button',{},text);b.classList.toggle('selected',drawerFilter===value);b.onclick=()=>{drawerFilter=value;drawerPage=0;for(const button of tabs.children)button.classList.toggle('selected',button===b);displayRows()};tabs.append(b)}
  search.oninput=()=>{drawerSearch=search.value;drawerPage=0;displayRows()};displayRows();
  const route=node('select',{'aria-label':'Маршрут списка'});for(const [value,text] of [['proxy','Через VPN'],['direct','Напрямую'],['block','Блокировать']])route.append(node('option',{value},text));route.value=action;
  const add=node('button',{class:'primary'},listAction(id)==='off'?'Добавить выбранный маршрут':'Изменить маршрут');add.disabled=managedList(id);add.onclick=()=>selectList(id,route.value);drawer.append(node('h3',{},'Маршрут'),route,add);
 }catch(e){if(request===drawerRender){drawer.replaceChildren(node('h2',{},listName(id)),close,node('p',{},'Не удалось получить состав списка. Повтори загрузку.'));const retry=node('button',{type:'button'},'Повторить');retry.onclick=renderListDrawer;drawer.append(retry);}}
}
function refreshListDraft(){if(!draft||!state)return;const payload=rulesPayload();function stable(v){if(Array.isArray(v))return v.map(stable);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])]));return v}const defaults={customLists:[],lists:{},direct:[],proxy:[],whiteProvider:'mobile_whitelist',whiteIps:false,listsInterval:'6'};dirtyRules=Object.keys(payload).some(k=>JSON.stringify(stable(payload[k]))!==JSON.stringify(stable(state.settings[k]??defaults[k])));if(!listDraftBar.children.length){const text=node('span'),reset=node('button',{},'Отменить изменения'),apply=node('button',{class:'primary'},'Применить маршрутизацию');reset.onclick=()=>{fill();drawCatalog()};apply.onclick=()=>$('saveRules').click();listDraftBar.append(text,reset,apply)}const [text,reset,apply]=listDraftBar.children;text.textContent=dirtyRules?'Есть неприменённые изменения':'Настройки актуальны';reset.hidden=!dirtyRules;apply.disabled=!dirtyRules||!!operation||!!state?.busy;}
drawCatalog=function(){if(!draft)return;const q=$('searchLists').value.trim().toLocaleLowerCase('ru'),category=$('listFilter').value;let rows=listMetadata().filter(l=>!window.PUPS_LIST_SCOPE||window.PUPS_LIST_SCOPE(l)).filter(l=>(!q||`${l.id} ${window.PUPS_LIST_SEARCH?.(l)||title(l)} ${l.description||''}`.toLocaleLowerCase('ru').includes(q))&&(q||['all','chosen'].includes(category)||l.group===category));const filter=listTabFilter==='all'&&category==='chosen'?'chosen':listTabFilter;rows=rows.filter(l=>q||filter==='all'||filter==='chosen'&&listAction(l.id)!=='off'||filter==='custom'&&l.id.startsWith('user_')||filter==='overlap'&&(listAnalysis.get(l.id)?.covered||listAnalysis.get(l.id)?.conflicts));if(window.PUPS_LIST_ORDER)rows.sort(window.PUPS_LIST_ORDER);listPage=Math.min(listPage,Math.max(0,Math.ceil(rows.length/12)-1));const visible=rows.slice(listPage*12,listPage*12+12);$('catalog').replaceChildren();for(const l of visible){const row=node('div',{class:'smart-list-row'}),info=node('div'),name=node('button',{class:'list-name'},title(l)),r=listAnalysis.get(l.id);name.onclick=()=>openListDrawer(l.id);const iconName=/youtube/.test(l.id)?'▶':/telegram/.test(l.id)?'➤':/discord/.test(l.id)?'◉':l.group==='gaming'?'♧':l.group==='social'?'♙':'▱',glyph=node('span',{class:'list-glyph'},iconName);info.append(name,node('small',{},l.group==='custom'?'Свой источник':groupNames[l.group]||'Список сообщества'));const badge=node('button',{class:'coverage-label'},listAction(l.id)!=='off'?'✓ Активен':coverageText(r));badge.dataset.status=r?.conflicts?'conflict':r?.unknown||r?.incomplete?'unknown':r?.full?'covered':r?.covered?'partial':'new';badge.onclick=()=>openListDrawer(l.id);badge.dataset.coverage=l.id;const toggle=node('input',{type:'checkbox',role:'switch','aria-label':'Включить список '+title(l)});toggle.dataset.listId=l.id;toggle.checked=listAction(l.id)!=='off';toggle.disabled=managedList(l.id)||!!operation||!!state?.busy;toggle.onchange=async()=>{if(!toggle.checked){delete draft.lists[l.id];dirtyRules=true;analysisSignature='';updateFormVisibility();drawCatalog();return}toggle.checked=false;toggle.disabled=true;await selectList(l.id,window.PUPS_LIST_DEFAULT?.(l)||'proxy');drawCatalog()};const detail=node('button',{'aria-label':'Состав списка '+title(l)},'›');detail.onclick=()=>openListDrawer(l.id);const target=node('label',{class:'toggle-target'});target.append(toggle);row.append(glyph,info,badge,target,detail);$('catalog').append(row)}$('noLists').hidden=rows.length>0;for(const b of listTabs.children)b.classList.toggle('selected',b.dataset.listTab===filter);listPager.replaceChildren();for(const [label,change,disabled] of [['← Назад',-1,listPage===0],['Далее →',1,(listPage+1)*12>=rows.length]]){const b=node('button',{},label);b.disabled=disabled;b.onclick=()=>{listPage+=change;drawCatalog()};listPager.append(b)}listPager.insertBefore(node('span',{},`${rows.length?listPage*12+1:0}–${Math.min((listPage+1)*12,rows.length)} из ${rows.length}`),listPager.lastChild);refreshListDraft();$('listCount').textContent=Object.keys(listContext().choices).length+' активно';if(analysisJob)analysisQueued=true;if(!analysisJob&&$('rules').classList.contains('active')){const epoch=analysisEpoch;analysisJob=(async()=>{await buildListIndex();for(const l of visible){if(epoch!==analysisEpoch||!$('rules').classList.contains('active')||document.hidden)break;if(listAction(l.id)!=='off'||!cached.has(l.id))continue;const count=Object.values(l.counts||{}).reduce((a,b)=>a+Number(b||0),0);if(count>12000)continue;if(!listAnalysis.has(l.id))listAnalysis.set(l.id,await analyzeList(l.id,window.PUPS_LIST_DEFAULT?.(l)||'proxy'));const badge=document.querySelector('[data-coverage="'+l.id+'"]');if(badge){const result=listAnalysis.get(l.id);if(window.PUPS_LIST_COVERAGE)window.PUPS_LIST_COVERAGE(badge,result);else {badge.textContent=coverageText(result);badge.dataset.status=result?.conflicts?'conflict':result?.unknown||result?.incomplete?'unknown':result?.full?'covered':result?.covered?'partial':'new';}}}})().catch(e=>{listSummary.textContent='Полный анализ пока недоступен: '+e.message}).finally(()=>{analysisJob=null;if(analysisQueued){analysisQueued=false;if($('rules').classList.contains('active'))drawCatalog();}});}};
let listSearchTimer;$('searchLists').oninput=()=>{clearTimeout(listSearchTimer);listSearchTimer=setTimeout(()=>{listPage=0;drawCatalog()},200)};$('listFilter').onchange=()=>{listPage=0;drawCatalog()};
const smartBeforeTab=tab;tab=function(id){smartBeforeTab(id);if(id==='rules')drawCatalog()};
const smartBeforeRender=render;render=function(){smartBeforeRender();if(!state)return;const generation=state.listGeneration||state.listRevision||'';const generationChanged=generation!==listGeneration;if(generationChanged){listGeneration=generation;analysisEpoch++;listData.clear();listAnalysis.clear();analysisSignature='';coverageBanner.hidden=true;}if($('rules').classList.contains('active')){refreshListDraft();if(generationChanged)drawCatalog();else {for(const toggle of $('catalog').querySelectorAll('input[role=switch]'))toggle.disabled=!!operation||!!state.busy||managedList(toggle.dataset.listId);for(const button of $('catalog').querySelectorAll('[data-list-route]'))button.disabled=!!operation||!!state.busy;}}};
if(state)render();
// Re-read source versions only on explicit Apply; never in the status poll.
$('saveRules').onclick=async()=>{
 if(!dirtyRules||operation||state?.busy)return;
 const payload=rulesPayload(),snapshot=JSON.stringify(payload);
 try{
  await buildListIndex(true);
  if(snapshot!==JSON.stringify(rulesPayload()))throw Error('Выбор изменился во время анализа. Проверь черновик и примени ещё раз.');
  const sources=[],versions={};let missing=0;
  for(const [id,action] of Object.entries(listContext().choices)){const data=listData.get(id);if(data?.available){sources.push({id,name:listName(id),action,items:data.items});versions[id]=data.version;}else missing++;}
  const stats=PupsCoverage.activeStats(sources),old=state.settings.lists||{},ids=new Set([...Object.keys(old),...Object.keys(payload.lists)]),changed=[...ids].filter(id=>old[id]!==payload.lists[id]).length;
  const text=`Списков: ${Object.keys(listContext().choices).length}. Уникальных правил в загруженных источниках: ${stats.unique}. Повторов: ${stats.overlap}. Конфликтов: ${stats.conflicts}. Изменено маршрутов списков: ${changed}.`+(missing?` Ещё ${missing} источников будут загружены и проверены перед применением; полный расчёт пока недоступен.`:'')+' Существующая защита памяти и проверка правил сохраняются.';
  const confirmed=confirmList(text);queueMicrotask(()=>{const b=document.querySelector('.list-confirm .primary');if(b)b.textContent='Применить маршрутизацию'});
  if(!await confirmed)return;
  if(snapshot!==JSON.stringify(rulesPayload()))throw Error('Черновик изменился. Проверь изменения перед применением.');
  await run('save',{...payload,_listVersions:versions},'Проверяем источники и применяем маршрутизацию…');
 }catch(e){notify(e.message,true)}
};

const smartBeforeVisibility=updateFormVisibility;updateFormVisibility=function(){smartBeforeVisibility();refreshListDraft()};
