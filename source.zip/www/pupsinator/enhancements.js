'use strict';
const supportBox=node('article'),supportHeading=node('h2',{},'Отчёт для поддержки'),supportInfo=node('p',{class:'subtle'},'Собирается только по кнопке: версии, проверки и последние ошибки. Ссылка подписки, ключи, адреса узлов и история доменов не включаются; журналы очищаются. Просмотри файл перед отправкой. Для свежих результатов сначала запусти диагностику.'),supportButtons=node('div',{class:'buttons'}),supportBuild=node('button',{},'Собрать отчёт'),supportDownload=node('button',{},'Скачать JSON'),supportPreview=node('textarea',{'aria-label':'Предпросмотр отчёта для поддержки',readonly:'',rows:'16',hidden:''});
supportDownload.disabled=true;supportPreview.style.cssText='width:100%;box-sizing:border-box;margin-top:16px;font:12px/1.5 monospace';
supportButtons.append(supportBuild,supportDownload);supportBox.append(supportHeading,supportInfo,supportButtons,supportPreview);$('diagnostics').append(supportBox);
let supportText='';
supportBuild.onclick=async()=>{supportBuild.disabled=true;supportDownload.disabled=true;try{const report=await api('support');if(report?.format!=='pupsinator-support-v1')throw Error('Не удалось собрать отчёт');supportText=JSON.stringify(report,null,2);supportPreview.value=supportText;supportPreview.hidden=false;supportDownload.disabled=false;notify('Отчёт готов. Просмотри содержимое и скачай файл для поддержки.')}catch(e){notify(e.message,true)}finally{supportBuild.disabled=false}};
supportDownload.onclick=()=>{if(!supportText)return;const url=URL.createObjectURL(new Blob([supportText],{type:'application/json'})),link=node('a',{href:url,download:'pupsinator-support-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json'});document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000)};
const latencyPanel=node('details',{class:'article'});latencyPanel.open=true;latencyPanel.append(node('summary',{},'Задержка серверов'),node('small',{id:'latencyChecked'}),node('div',{id:'latencyServers'}));document.querySelector('.overview-grid').after(latencyPanel);
const emojiAssets=new Set(window.PUPS_EMOJI||[]);
const segmenter=typeof Intl.Segmenter==='function'?new Intl.Segmenter('ru',{granularity:'grapheme'}):null;
function richName(text){
 const fragment=document.createDocumentFragment();
 let plain='';const flush=()=>{if(plain){fragment.append(document.createTextNode(plain));plain=''}};
 for(const part of segmenter?[...segmenter.segment(text)].map(x=>x.segment):Array.from(text)){
  const key=Array.from(part).map(x=>x.codePointAt(0).toString(16)).filter(x=>x!=='fe0f').join('-');
  if(emojiAssets.has(key)){flush();const img=node('img',{class:'server-emoji',src:'assets/emoji/'+key+'.svg',alt:part,loading:'lazy'});fragment.append(img)}else plain+=part;
 }flush();return fragment;
}
const originalDrawServers=drawServers;
drawServers=function(){originalDrawServers();for(const row of $$('.server-row')){const n=nodeById(row.dataset.node);if(n)row.querySelector('.name').replaceChildren(richName(n.name))}};
const originalDrawCatalog=drawCatalog;
drawCatalog=function(){originalDrawCatalog();for(const category of $$('.category')){const scroll=node('div',{class:'category-options'});for(const row of [...category.children].filter(x=>x.classList.contains('catalog-row')))scroll.append(row);category.append(scroll);category.addEventListener('toggle',()=>{if(category.open)$$('.category').filter(x=>x!==category).forEach(x=>x.open=false)});}drawCustomLists();updateChosen();};
function updateChosen(){
 if(!draft)return;const selected=[...catalog,...(draft.customLists||[]).map(l=>({id:l.id,title:l.name}))].filter(l=>listAction(l.id)!=='off');
 const box=$('chosenLists');box.replaceChildren(node('b',{},'Выбрано: '+selected.length));
 if(!selected.length)box.append(node('small',{},'Пока ничего не выбрано. Открой категорию ниже или воспользуйся поиском.'));
 const chips=node('div',{class:'selection-chips'});
 for(const l of selected){const action=listAction(l.id),b=node('button',{class:'selection-chip '+action,title:(managedList(l.id)?'Управляется режимом белых списков': 'Убрать из выбранных')},title(l)+' · '+({proxy:'VPN',direct:'напрямую',block:'блок'})[action]);b.disabled=managedList(l.id);b.onclick=()=>{delete draft.lists[l.id];dirtyRules=true;drawCatalog();updateFormVisibility()};chips.append(b)}box.append(chips);
}
const originalVisibility=updateFormVisibility;
updateFormVisibility=function(){originalVisibility();updateChosen();const lists=[...catalog,...(draft?.customLists||[])];$('listCount').textContent=lists.filter(l=>listAction(l.id)!=='off').length+' включено · '+lists.length+' всего'};
$('searchLists').oninput=drawCatalog;$('listFilter').onchange=drawCatalog;
const customBox=node('details',{class:'article custom-sources'}),customHeading=node('summary',{},'Свои списки по ссылке');customBox.append(customHeading);$('catalog').before(customBox);
customBox.append(node('p',{class:'subtle'},'Добавь прямую HTTPS-ссылку на файл. Обновляется вместе с остальными списками, сначала через VPN. При ошибке остаётся рабочая копия. До 10 источников, до 2 МБ каждый.'));
const customRows=node('div',{class:'custom-source-rows'}),customForm=node('form',{class:'custom-source-form'}),customName=node('input',{placeholder:'Название списка',maxlength:'80',required:'', 'aria-label':'Название своего списка'}),customUrl=node('input',{placeholder:'https://…/domains.txt',type:'url',required:'', 'aria-label':'Ссылка на список'}),customFormat=node('select',{'aria-label':'Формат списка'}),customSubmit=node('button',{type:'submit'},'Добавить список');
for(const [value,label] of [['domains','Домены: TXT'],['cidrs','IP-подсети: TXT'],['json','Правила sing-box: JSON']])customFormat.append(node('option',{value},label));
customForm.append(customName,customUrl,customFormat,customSubmit);customBox.append(customRows,customForm,node('small',{},'TXT: по одному домену или CIDR в строке; # — комментарий. Домены включают поддомены. JSON: исходный rule-set версии 3 с domain, domain_suffix, domain_keyword, domain_regex и ip_cidr. Скомпилированные SRS, ссылки подписок и произвольные конфиги не подходят. Изменения сохраняются кнопкой «Применить» ниже.'));
let editingCustomId=null;
customForm.onsubmit=e=>{e.preventDefault();const name=customName.value.trim(),url=customUrl.value.trim();if(!name||!/^https:\/\/[^\s"\\#]+$/.test(url)||url.length>2048)return notify('Нужна прямая HTTPS-ссылка на файл и название.',true);draft.customLists??=[];if(!editingCustomId&&draft.customLists.length>=10)return notify('Можно добавить до 10 своих источников.',true);const id=editingCustomId||'user_'+Array.from(crypto.getRandomValues(new Uint8Array(8)),x=>x.toString(16).padStart(2,'0')).join(''),entry={id,name,url,format:customFormat.value};const index=draft.customLists.findIndex(l=>l.id===id);if(index>=0)draft.customLists[index]=entry;else {draft.customLists.push(entry);draft.lists[id]='proxy';}editingCustomId=null;customSubmit.textContent='Добавить список';customForm.reset();dirtyRules=true;drawCatalog();updateFormVisibility();};
function drawCustomLists(){if(!draft)return;customHeading.textContent='Свои списки по ссылке · '+(draft.customLists||[]).length;customRows.replaceChildren();for(const l of draft.customLists||[]){const row=node('div',{class:'custom-source-row'}),info=node('div');info.append(node('b',{},l.name),node('small',{},new URL(l.url).hostname+' · '+(cached.has(l.id)?'Сохранён на роутере':'Загрузится при применении')));const select=node('select',{'aria-label':'Маршрут своего списка '+l.name});for(const [value,text] of [['off','Выключено'],['proxy','Через VPN'],['direct','Напрямую'],['block','Блокировать']])select.append(node('option',{value},text));select.value=draft.lists[l.id]||'off';select.onchange=()=>{if(select.value==='off')delete draft.lists[l.id];else draft.lists[l.id]=select.value;dirtyRules=true;updateFormVisibility()};const edit=node('button',{type:'button'},'Изменить');edit.onclick=()=>{editingCustomId=l.id;customName.value=l.name;customUrl.value=l.url;customFormat.value=l.format;customSubmit.textContent='Сохранить список';};const remove=node('button',{type:'button','aria-label':'Удалить список '+l.name},'Удалить');remove.onclick=()=>{draft.customLists=draft.customLists.filter(x=>x.id!==l.id);delete draft.lists[l.id];if(editingCustomId===l.id){editingCustomId=null;customForm.reset();customSubmit.textContent='Добавить список';}dirtyRules=true;drawCatalog();updateFormVisibility()};row.append(info,select,edit,remove);customRows.append(row)}}
function bytes(value){if(value==null)return 'Не передано';let n=Number(value);for(const u of ['Б','КБ','МБ','ГБ','ТБ']){if(n<1024||u==='ТБ')return n.toLocaleString('ru-RU',{maximumFractionDigits:1})+' '+u;n/=1024}}
const originalRender=render;
const wholeRouter=node('button',{id:'wholeRouterToggle',type:'button','aria-pressed':'false'},'Весь роутер: по спискам');$('power').parentElement.append(wholeRouter);
wholeRouter.onclick=()=>{const s=state.settings,enabled=s.routeMode==='all';return run('save',enabled?{routeMode:s.previousRouteMode||'selective'}:{routeMode:'all',previousRouteMode:s.routeMode==='whitelist'?'whitelist':'selective'},enabled?'Возвращаем прежние правила сайтов…':'Направляем интернет всего роутера через VPN…')};
const currentSubscription=node('input',{id:'currentSubscription',type:'url',readonly:'','aria-label':'Текущая ссылка подписки'}),subscriptionLabel=node('label',{for:'currentSubscription'},'Текущая ссылка подписки');$('subscriptionSummary').after(subscriptionLabel,currentSubscription);
render=function(){
 originalRender();if(!state)return;
 currentSubscription.value=state.settings.subscription||'';wholeRouter.classList.toggle('full-on',state.active&&state.settings.routeMode==='all');wholeRouter.classList.toggle('full-off',!state.active||state.settings.routeMode!=='all');wholeRouter.setAttribute('aria-pressed',String(state.active&&state.settings.routeMode==='all'));wholeRouter.textContent=state.settings.routeMode==='all'?'Весь роутер: VPN включён':'Весь роутер: по спискам';wholeRouter.disabled=operation||state.busy||!state.active;
 for(const id of ['activeServer','vpnDetail'])$(id).replaceChildren(richName($(id).textContent));
 for(const option of $('quickServer').options)option.textContent=option.textContent.replace(/[\u{1F1E6}-\u{1F1FF}]{2}/gu,'').trim();
 const info=state.subscriptionInfo||{},versions=state.versions||{};
 $('installedVersions').textContent='Оболочка Pupsinator '+(versions.app||'0.6.0')+' · '+(versions.engine||'Xray: версия не определена');
 const box=$('subscriptionDetails');box.replaceChildren();
 const item=(label,value)=>{const el=node('div');el.append(node('small',{},label),node('b',{},value));box.append(el)};
 item('Сервис',info.name||'Название не передано провайдером');
 item('Срок подписки',info.expire==null?'Не передан':Number(info.expire)===0?'Без срока':new Date(info.expire*1000).toLocaleString('ru-RU'));
 const used=info.upload==null&&info.download==null?null:(info.upload||0)+(info.download||0);
 item('Использовано',bytes(used));item('Лимит трафика',info.total==null?'Не передан':Number(info.total)===0?'Без лимита':bytes(info.total));
 if(info.total>0&&used!=null){const progress=node('progress',{max:String(info.total),value:String(Math.min(used,info.total))});progress.title='Использовано '+bytes(used)+' из '+bytes(info.total);box.append(progress)}
 renderExtras();
};
Object.assign(actionNames,{checkupdates:'Проверка обновлений',upgrade:'Установка обновления','observe-on':'Включение наблюдения','observe-off':'Выключение наблюдения','observe-clear':'Очистка журнала'});
Object.assign(successMessages,{checkupdates:'Версия проверена.',upgrade:'Обновление установлено. Если соединение с интерфейсом прервалось, обнови страницу LuCI.','observe-on':'Наблюдение включено. Новые DNS-запросы появятся в журнале.','observe-off':'Наблюдение выключено.','observe-clear':'Журнал очищен.',check:'Задержка серверов измерена.'});
let scheduleDirty=false,monitorMode='domains',observations={records:[],services:{}},lastMonitorPoll=0,monitorLoading=false;
$('checkUpdates').onclick=()=>run('action','checkupdates','Проверяем последний опубликованный релиз…');
$('installUpdate').onclick=()=>run('action','upgrade','Создаём резервную копию и устанавливаем обновление…');
for(const id of ['autoUpgrade','upgradeTime'])$(id).onchange=()=>scheduleDirty=true;
$('saveUpgradeSchedule').onclick=async()=>{if(await run('save',{autoUpgrade:$('autoUpgrade').checked,upgradeTime:$('upgradeTime').value},'Сохраняем расписание по МСК…'))scheduleDirty=false};
function renderExtras(){
 const update=state.update,busy=operation||state.busy;
 $('updateStatus').textContent=update?(update.available?'Доступна версия '+update.latest+' · установлена '+update.current:'Установлена актуальная версия '+update.current)+' · проверено '+date(update.checked):'Последняя опубликованная версия ещё не проверялась.';
 $('installUpdate').hidden=!update?.available;for(const id of ['checkUpdates','installUpdate','saveUpgradeSchedule'])$(id).disabled=busy;
 if(!scheduleDirty){$('autoUpgrade').checked=!!state.settings.autoUpgrade;$('upgradeTime').value=state.settings.upgradeTime||'04:00'}
 $('monitorToggle').textContent=state.settings.monitorEnabled?'Выключить наблюдение':'Включить наблюдение';$('monitorToggle').disabled=busy;$('monitorClear').disabled=busy;
 $('favoriteDevices').replaceChildren();for(const favorite of state.settings.favorites||[]){const device=(state.settings.devices||[]).find(d=>d.mac===favorite.mac),row=node('div',{class:'favorite-row'}),label=node('div');label.append(node('b',{},favorite.label||device?.name||favorite.mac),node('small',{},device?device.ip:'Сейчас не обнаружено'));const button=node('button',{class:favorite.enabled?'primary':''},favorite.enabled?'Весь интернет через VPN':'Обычные правила');button.disabled=busy;button.onclick=()=>run('save',{favorites:(state.settings.favorites||[]).map(d=>d.mac===favorite.mac?{...d,enabled:!d.enabled}:d)},'Меняем маршрут устройства…');row.append(label,button);$('favoriteDevices').append(row)}
 if(!(state.settings.favorites||[]).length)$('favoriteDevices').append(node('p',{class:'subtle'},'Пока нет избранных. Выбери устройства — здесь появятся их переключатели.'));
 renderLatency();
}
$('manageFavorites').onclick=()=>{
 const box=$('favoritePicker');box.hidden=!box.hidden;if(box.hidden)return;box.replaceChildren();
 const devices=[...(state.settings.devices||[])];for(const f of state.settings.favorites||[])if(!devices.some(d=>d.mac===f.mac))devices.push({mac:f.mac,name:f.label,ip:'не в сети'});
 for(const d of devices){const label=node('label',{class:'check'}),input=node('input',{type:'checkbox',value:d.mac});input.checked=(state.settings.favorites||[]).some(f=>f.mac===d.mac);label.append(input,document.createTextNode((d.name||d.ip)+' · '+d.ip));box.append(label)}
 const save=node('button',{class:'primary'},'Сохранить избранные');save.onclick=async()=>{const selected=[...box.querySelectorAll('input:checked')].map(x=>{const d=devices.find(n=>n.mac===x.value),old=(state.settings.favorites||[]).find(f=>f.mac===d.mac);return old||{mac:d.mac,label:d.name||d.ip,enabled:false}});if(await run('save',{favorites:selected},'Сохраняем избранные устройства…'))box.hidden=true};box.append(save);
};
$('monitorToggle').onclick=()=>run('action',state.settings.monitorEnabled?'observe-off':'observe-on');
$('monitorClear').onclick=async()=>{if(window.confirm('Очистить временный журнал доменов?')){if(await run('action','observe-clear')){observations={records:[],services:{}};drawMonitor()}}};
$$('[data-monitor]').forEach(b=>b.onclick=()=>{monitorMode=b.dataset.monitor;drawMonitor()});$('monitorSearch').oninput=()=>drawMonitor();
async function pollMonitor(){if(monitorLoading||!$('monitor').classList.contains('active')||!state?.settings.monitorEnabled||Date.now()-lastMonitorPoll<12000)return;monitorLoading=true;try{observations=await api('monitor');lastMonitorPoll=Date.now();drawMonitor()}catch(e){$('monitorStatus').textContent=e.message}finally{monitorLoading=false}}
setInterval(pollMonitor,3000);
function deviceName(ip){const d=(state?.settings.devices||[]).find(x=>x.ip===ip);return d?d.name+' · '+ip:ip}
function drawMonitor(){
 const query=$('monitorSearch').value.trim().toLowerCase(),all=observations.records||[],rows=all.filter(r=>`${r.domain} ${deviceName(r.device)} ${observations.services?.[r.service]?.name||''}`.toLowerCase().includes(query));
 $('monitorStatus').textContent=(state?.settings.monitorEnabled?'Наблюдение включено':'Наблюдение выключено')+' · '+all.length+' записей'+(observations.checked?' · обновлено '+date(observations.checked):' · ожидание DNS-запросов');
 $$('[data-monitor]').forEach(b=>b.classList.toggle('primary',b.dataset.monitor===monitorMode));const box=$('monitorResults');box.replaceChildren();
 if(monitorMode==='domains')for(const r of rows.slice(0,100)){const row=node('div',{class:'domain-row'}),text=node('div');text.append(node('b',{},r.domain),node('small',{},deviceName(r.device)+' · '+(observations.services?.[r.service]?.name||'Сервис не определён')+' · '+date(r.seen)));const b=node('button',{},'Через VPN');b.onclick=()=>related(r);row.append(text,b);box.append(row)}
 else {const grouped=new Map();for(const r of rows){const key=monitorMode==='devices'?r.device:r.service||'unknown';if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(r)}for(const [key,items] of grouped){const details=node('details',{class:'monitor-group'}),summary=node('summary',{},(monitorMode==='devices'?deviceName(key):observations.services?.[key]?.name||'Сервис не определён')+' · '+new Set(items.map(x=>x.domain)).size+' доменов');details.append(summary);const scroll=node('div',{class:'monitor-scroll'});for(const r of items.slice(0,100)){const row=node('div',{class:'domain-row'});row.append(node('span',{},r.domain));const b=node('button',{},'Через VPN');b.onclick=()=>related(r);row.append(b);scroll.append(row)}details.append(scroll);box.append(details)}}
 if(!rows.length)box.append(node('p',{},'Записей пока нет. Открой сайт на устройстве, использующем DNS роутера.'));
 if(rows.length>100&&monitorMode==='domains')box.append(node('small',{},'Показаны последние 100. Уточни поиск или открой вкладку устройства.'));
}
function related(target){
 const box=$('relatedDomains');box.hidden=false;box.replaceChildren(node('h2',{},'Направить через VPN: '+target.domain),node('p',{},'Первым выбран только этот домен. Остальные — подсказки по списку сервиса или похожим именам. Проверь их перед добавлением.'));
 const token=target.domain.split('.').find(x=>x.length>=4&&!['cloud','www','static'].includes(x)),others=(observations.records||[]).filter(r=>r.domain!==target.domain&&((target.service&&r.service===target.service)||(token&&r.domain.includes(token))));
 const unique=new Map([[target.domain,target]]);for(const r of others)if(unique.size<40)unique.set(r.domain,r);
 for(const [domain,r] of unique){const label=node('label',{class:'check'}),input=node('input',{type:'checkbox',value:domain});input.checked=domain===target.domain;label.append(input,document.createTextNode(domain+(domain===target.domain?'':target.service&&r.service===target.service?' · тот же сервис':' · похожее имя')));box.append(label)}
 const apply=node('button',{class:'primary'},'Добавить выбранные домены');apply.onclick=async()=>{const chosen=[...box.querySelectorAll('input:checked')].map(x=>x.value),direct=state.settings.direct||[];const conflict=chosen.find(d=>direct.some(rule=>!rule.includes('/')&&(d===rule||d.endsWith('.'+rule))));if(conflict)return notify('Домен '+conflict+' перекрыт прямым исключением. Сначала измени его в разделе «Сайты и списки».',true);if(await run('save',{proxy:[...new Set([...(state.settings.proxy||[]),...chosen])]},'Добавляем подтверждённые домены в VPN…'))box.hidden=true};box.append(apply);box.scrollIntoView({behavior:'smooth',block:'start'});
}
function renderLatency(){const box=$('latencyServers');if(!box)return;box.replaceChildren();for(const n of state.nodes){const row=node('div',{class:'latency-row'}),name=node('span');name.append(richName(n.name));const h=state.health?.results?.[n.id];row.append(name,node('b',{},h?h.ok?h.ms+' мс':'Нет ответа':'Не измерено'));box.append(row)}$('latencyChecked').textContent=state.health?.checked?'Измерено '+date(state.health.checked):'Измерения ещё не выполнялись';$('dashCheck').disabled=operation||state.busy||!state.running;$('dashRefreshSub').disabled=operation||state.busy;}
$('dashCheck').onclick=()=>run('action','check','Измеряем HTTPS-задержку серверов через их туннели…');$('dashRefreshSub').onclick=()=>run('action','refresh','Обновляем подписку…');
