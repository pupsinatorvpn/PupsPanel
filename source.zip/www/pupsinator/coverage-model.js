(function(root){'use strict';
 const domain=s=>{if(/[:/@?#\s]/.test(s))throw Error('Invalid domain');const name=new URL('http://'+s.replace(/\.$/,'')).hostname.toLowerCase();if(name.split('.').some(x=>!x))throw Error('Invalid domain');return name;};
 function ip(s){let [address,prefix]=s.split('/'),parts,bits;
  if(address.includes(':')){bits=128;if(address.includes('.')){const cut=address.lastIndexOf(':'),v=ip(address.slice(cut+1));if(!v||v.bits!==32)return null;address=address.slice(0,cut+1)+(v.network>>16n).toString(16)+':'+(v.network&65535n).toString(16)}const pair=address.split('::');if(pair.length>2)return null;const l=pair[0]?pair[0].split(':'):[],r=pair[1]?pair[1].split(':'):[];parts=pair.length===2?[...l,...Array(8-l.length-r.length).fill('0'),...r]:l;if(parts.length!==8||parts.some(x=>!/^\p{ASCII_Hex_Digit}{1,4}$/u.test(x)))return null;address=parts.reduce((a,x)=>(a<<16n)+BigInt(parseInt(x,16)),0n)}
  else{bits=32;parts=address.split('.');if(parts.length!==4||parts.some(x=>!/^\d{1,3}$/.test(x)||+x>255))return null;address=parts.reduce((a,x)=>(a<<8n)+BigInt(+x),0n)}
  prefix=prefix===undefined?bits:Number(prefix);if(!Number.isInteger(prefix)||prefix<0||prefix>bits)return null;const network=address>>BigInt(bits-prefix)<<BigInt(bits-prefix);return {bits,prefix,network};
 }
 function normalize(item){const scope=item.scope||'{}';try{
  if(item.kind==='ip'){const value=ip(item.value);if(value)return {...item,...value,scope,type:'ip',key:`${scope}|ip${value.bits}|${value.network}/${value.prefix}`}}
  if(item.kind==='domain'){const [type,...rest]=item.value.split(':'),value=rest.join(':');if(type==='full'||type==='domain'){const host=domain(value);if(host.includes('*')||!host||host.includes(':'))throw Error();return {...item,scope,type,host,key:scope+'|'+type+'|'+host}}if(type==='keyword'||type==='regexp')return {...item,scope,type,text:value,key:scope+'|'+type+'|'+value};}
 }catch(e){}return {...item,scope,type:'opaque',key:scope+'|opaque|'+item.value};}
 const fresh=()=>({children:new Map(),term:[],samples:[]});
 function sample(list,r,limit=24){if(list.some(x=>x.source===r.source&&x.action===r.action))return;if(list.length<limit)list.push(r);else list.truncated=true;}
 class Index{
  constructor(sources=[]){this.exact=new Map();this.tries=new Map();this.keywords=[];this.opaque=[];this.sources=sources;this.scopes=new Set();for(const source of sources)for(const item of source.items){const n=normalize(item),r={...n,source:source.id,action:source.action,name:source.name||source.id};this.scopes.add(n.scope);if(!this.exact.has(n.key))this.exact.set(n.key,[]);sample(this.exact.get(n.key),r,Infinity);if(n.type==='keyword')this.keywords.push(r);if(['regexp','opaque','keyword'].includes(n.type))this.opaque.push(r);const path=this.path(n);if(!path)continue;const key=n.scope+'|'+(n.type==='ip'?'ip'+n.bits:'domain');if(!this.tries.has(key))this.tries.set(key,fresh());let t=this.tries.get(key);sample(t.samples,r);for(const part of path){if(!t.children.has(part))t.children.set(part,fresh());t=t.children.get(part);sample(t.samples,r)}sample(t.term,r,Infinity);}}
  path(n){if(n.type==='full'||n.type==='domain')return n.host.split('.').reverse();if(n.type==='ip')return Array.from({length:n.prefix},(_,i)=>Number(n.network>>BigInt(n.bits-i-1)&1n));return null;}
  matches(n,exclude){let found=[...(this.exact.get(n.key)||[])],truncated=false;const path=this.path(n);if(path){let t=this.tries.get(n.scope+'|'+(n.type==='ip'?'ip'+n.bits:'domain'));if(t){for(const part of path){found.push(...t.term.filter(r=>r.type==='domain'||r.type==='ip'));t=t.children.get(part);if(!t)break}if(t){found.push(...t.term,...(n.type==='domain'||n.type==='ip'?t.samples:[]));truncated=(n.type==='domain'||n.type==='ip')&&!!t.samples.truncated;}}}
   if(n.type==='full'||n.type==='domain')found.push(...this.keywords.filter(r=>r.scope===n.scope&&n.host.includes(r.text)));
   const result=found.filter(r=>r.source!==exclude&&r.scope===n.scope);result.truncated=truncated;return result;
  }
  covers(a,b){if(a.key===b.key)return true;if(a.type==='domain'&&['full','domain'].includes(b.type))return b.host===a.host||b.host.endsWith('.'+a.host);if(a.type==='keyword'&&['full','domain'].includes(b.type))return b.host.includes(a.text);return a.type==='ip'&&b.type==='ip'&&a.bits===b.bits&&a.prefix<=b.prefix&&(b.network>>BigInt(b.bits-a.prefix))===(a.network>>BigInt(a.bits-a.prefix));}
  analyze(items,action,exclude){const unique=new Map(items.map(v=>{const n=normalize(v);return [n.key,n]})),rows=[];let covered=0,conflicts=0,unknown=0;
   for(const n of unique.values()){const matches=this.matches(n,exclude),same=matches.filter(r=>r.action===action&&this.covers(r,n)),opposite=matches.filter(r=>r.action!==action);const bad=opposite.length>0,opaque=!!matches.truncated||[...this.scopes].some(s=>s!==n.scope)||this.opaque.some(r=>r.source!==exclude&&r.scope===n.scope&&r.action!==action)||(!same.length&&!bad&&(['regexp','opaque','keyword'].includes(n.type)||this.opaque.some(r=>r.source!==exclude&&r.scope===n.scope))),yes=same.length>0&&!bad&&!opaque;if(yes)covered++;if(bad)conflicts++;if(opaque)unknown++;rows.push({value:n.value,kind:n.type,scope:n.scope,covered:yes,shared:same.length>0,conflict:bad,unknown:opaque,reason:matches.truncated?'Часть пересечений за пределами безопасного анализа':opaque?'Нельзя доказать одинаковое действие при всех условиях':'',sources:[...new Map([...opposite,...same].map(r=>[r.source+'|'+r.action,{id:r.source,name:r.name,action:r.action,kind:r.type,scope:r.scope}])).values()]});}
   return {total:unique.size,covered,conflicts,unknown,newRules:rows.filter(r=>!r.covered&&!r.conflict&&!r.unknown).length,full:unique.size>0&&covered===unique.size&&!conflicts&&!unknown,rows};
  }
 }
 function activeStats(sources,index=new Index(sources)){
  const unique=new Set(),duplicates=new Set(),conflicts=new Set(),bySource={};
  const installed=new Set(sources.filter(source=>!source.manual).map(source=>source.id));
  let incomplete=false;
  for(const source of sources){
   const seen=new Set(), counts={covered:0,conflicts:0,total:0,sources:[],disableWith:[]};
   const partners=new Map(), coverCounts=new Map(), witnesses=new Set();
   let proven=0;
   for(const item of source.items){
    const n=normalize(item),key=source.action+'|'+n.key;
    if(seen.has(n.key))continue;
    seen.add(n.key);unique.add(key);counts.total++;
    const matches=index.matches(n,source.id);
    if(matches.truncated)incomplete=true;
    const same=new Map(matches.filter(r=>r.action===source.action&&index.covers(r,n)).map(r=>[r.source,r]));
    const opposite=matches.filter(r=>r.action!==source.action);
    if(same.size){duplicates.add(key);counts.covered++;}
    if(opposite.length){conflicts.add(n.key);counts.conflicts++;}
    for(const r of [...same.values(),...opposite])partners.set(r.source,r.name);
    // A disable suggestion needs another enabled list with equivalent matchers
    // and the same action. Manual rules have a different device scope.
    const safe=[...same.values()].filter(r=>installed.has(r.source)&&
     (r.key===n.key||r.type==='domain'||r.type==='ip')&&n.type!=='opaque');
    if(safe.length){
     proven++;
     witnesses.add(safe[0].name);
     for(const r of safe){
      const value=coverCounts.get(r.source)||{name:r.name,count:0};
      value.count++;coverCounts.set(r.source,value);
     }
    }
   }
   counts.sources=[...partners.values()];
   if(!source.manual&&counts.total&&proven===counts.total&&!counts.conflicts){
    const single=[...coverCounts.values()].find(r=>r.count===counts.total);
    counts.disableWith=single?[single.name]:[...witnesses];
   }
   bySource[source.id]=counts;
  }
  return {active:sources.length,unique:unique.size,overlap:duplicates.size,conflicts:conflicts.size,incomplete,bySource};
 }
 const api={normalize,ip,Index,activeStats};root.PupsCoverage=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
