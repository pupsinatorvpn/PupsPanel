'use strict';
'require view';
'require rpc';
const getStatus=rpc.declare({object:'pupsinator',method:'status',expect:{}});
const saveSettings=rpc.declare({object:'pupsinator',method:'save',params:['config'],expect:{}});
const runAction=rpc.declare({object:'pupsinator',method:'action',params:['action'],expect:{}});
const getMonitor=rpc.declare({object:'pupsinator',method:'monitor',expect:{}});
const getRules=rpc.declare({object:'pupsinator',method:'rules',params:['id','cursor','version'],expect:{}});
const getSupport=rpc.declare({object:'pupsinator',method:'support',expect:{}});
const addLink=rpc.declare({object:'pupsinator',method:'link',params:['link'],expect:{}});
return view.extend({
 render:function(){
  const frame=E('iframe',{src:'/pupsinator/console.html?v=0.8.1',title:'PupsPanel',class:'pupsinator-full-frame',style:'position:fixed;inset:0;width:100%;height:100dvh;min-height:0;border:0;z-index:10000;background:#080e17'});
  const style=E('style',{},'body:has(.pupsinator-full-frame){overflow:hidden!important}body:has(.pupsinator-full-frame)>#menubar{display:none!important}');
  window.addEventListener('message',async function(event){
   if(event.origin!==location.origin||event.source!==frame.contentWindow)return;
   if(event.data?.channel==='pupsinator-size')return;
   if(event.data?.channel!=='pupsinator')return;
   const {id,method,payload}=event.data;
   try{let result;if(method==='rules')result=await getRules(payload.id,payload.cursor||0,payload.version||'');else if(method==='support')result=await getSupport();else if(method==='monitor')result=await getMonitor();else if(method==='status')result=await getStatus();else if(method==='save')result=await saveSettings(JSON.stringify(payload));else if(method==='action')result=await runAction(payload);else if(method==='link')result=await addLink(payload);else throw Error('Unknown method');frame.contentWindow.postMessage({channel:'pupsinator-reply',id,result},location.origin);}
   catch(error){frame.contentWindow.postMessage({channel:'pupsinator-reply',id,error:String(error)},location.origin);}
  });return E('div',{},[style,frame]);
 },handleSaveApply:null,handleSave:null,handleReset:null
});
